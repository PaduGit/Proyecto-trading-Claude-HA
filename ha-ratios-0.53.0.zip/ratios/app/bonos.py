"""Tabla de bonos: TIR en cada punta, con conversión de pesos según el MEP.

El MEP no es un número único. Si comprás dólares pagás uno y si los vendés
cobrás otro, porque el spread del bono queda adentro. Para que la TIR sea
la que realmente conseguís, cada punta se convierte con el MEP que le toca.
"""

import logging
import os
from datetime import date, datetime, timedelta

import yaml

import cer as CER
import renta_fija as RF

log = logging.getLogger("bonos")

RUTA = os.path.join(os.path.dirname(__file__), "datos", "bonos.yaml")

_cache = {"bonos": None, "equiv": None}


def cargar():
    if _cache["bonos"] is None:
        try:
            with open(RUTA) as f:
                d = yaml.safe_load(f) or {}
            _cache["bonos"] = d.get("bonos") or {}
            _cache["equiv"] = d.get("equivalencias") or {}
        except Exception as e:
            log.error("no se pudo leer bonos.yaml: %s", e)
            _cache["bonos"], _cache["equiv"] = {}, {}
    return _cache["bonos"], _cache["equiv"]


def especies():
    """Todas las especies con cronograma conocido: en pesos y dolarizadas."""
    bonos, equiv = cargar()
    out = {}
    for tk, cfg in bonos.items():
        out[tk] = {"cronograma": tk,
                   "moneda": "CER" if (cfg.get("ajuste") or "") == "cer" else "ARS"}
    for esp, base in equiv.items():
        if base in bonos:
            out[esp] = {"cronograma": base,
                        "moneda": "USD" if esp.endswith(("D", "C")) else "ARS"}
    return out


# -- MEP ---------------------------------------------------------------

def calcular_mep(cot, par_pesos="AL30", par_usd="AL30D"):
    """Devuelve los dos tipos de cambio implícitos y el punto medio.

    - comprar_usd: pesos que te cuesta cada dólar (comprás el bono en pesos
      al ask y vendés la especie D al bid).
    - vender_usd: pesos que recibís por cada dólar (vendés en pesos al bid
      y recomprás la D al ask).
    """
    a = cot.get(par_pesos) or {}
    b = cot.get(par_usd) or {}
    ask_p, bid_p = a.get("venta") or 0, a.get("compra") or 0
    ask_d, bid_d = b.get("venta") or 0, b.get("compra") or 0

    comprar = (ask_p / bid_d) if (ask_p and bid_d) else 0
    vender = (bid_p / ask_d) if (bid_p and ask_d) else 0

    medio = 0
    if a.get("ref") and b.get("ref"):
        medio = a["ref"] / b["ref"]

    return {
        "par": "%s/%s" % (par_pesos, par_usd),
        "comprar_usd": comprar or medio,
        "vender_usd": vender or medio,
        "medio": medio,
        "completo": bool(comprar and vender),
    }


# -- tabla -------------------------------------------------------------

def _tipo(cfg):
    """hard_dollar | cer | tasa_fija | dual. Se puede fijar en el YAML."""
    t = (cfg.get("tipo") or "").strip().lower()
    if t:
        return t
    a = (cfg.get("ajuste") or "").lower()
    if a == "cer":
        return "cer"
    if a in ("dolar_linked", "dolarlinked", "dl"):
        return "dolar_linked"
    if (cfg.get("moneda") or "").upper() == "USD":
        return "hard_dollar"
    return "tasa_fija"


def etiqueta(cfg, fila=None):
    """Etiqueta corta del tipo, para el chip de la tabla.

    La tasa variable muestra su fuente, y el dual la pata que paga en la
    proyeccion. Devuelve (etiqueta, ayuda).
    """
    if not cfg:
        return None, None
    t = _tipo(cfg)
    if t == "dual":
        gana = ((fila or {}).get("dual") or {}).get("gana")
        return (("DUAL·" + gana) if gana else "DUAL",
                "Dual CER/TAMAR" + (": paga " + gana + " en la proyeccion"
                                    if gana else ""))
    var = ((cfg.get("interes") or {}).get("variable") or {})
    if var:
        f = (var.get("fuente") or "variable").upper()
        return f, "Tasa variable " + f
    if t == "hard_dollar":
        ley = "AR" if (cfg.get("ley") or "").startswith("arg") else "NY"
        return "HD·" + ley, "Hard dollar, ley " + (
            "argentina" if ley == "AR" else "Nueva York")
    return {"cer": ("CER", "Ajusta por CER"),
            "dolar_linked": ("DL", "Dolar linked"),
            "tasa_fija": ("FIJA", "Tasa fija en pesos"),
            "tasa_variable": ("VAR", "Tasa variable")}.get(t, (t.upper(), t))


def _moneda_cotiza(info, simbolo):
    """En qué moneda liquida la especie: ARS, MEP o CABLE."""
    if simbolo.endswith("D"):
        return "MEP"
    if simbolo.endswith("C"):
        return "CABLE"
    return "ARS"


EMISORES = {"nacion": "Nación", "provincia": "Provincia",
            "bcra": "BCRA", "corporativo": "Corporativo"}


def emisor_de(cfg):
    """Quien emite, para agrupar la curva.

    Va en `emisor_tipo` y no en `emisor`, que ya existia con el nombre
    largo del emisor y se muestra en pantalla.
    """
    e = (cfg.get("emisor_tipo") or "nacion").strip().lower()
    return e if e in EMISORES else "nacion"


def _familia(cfg, info, simbolo=""):
    """Agrupa para la curva.

    Ley argentina y ley NY van separadas: la diferencia entre ambas es
    riesgo legal, no pendiente de curva.

    Las especies C también van aparte: liquidan en dólar cable, que es
    otra moneda que el MEP de las D. Mezclarlas desplaza la curva.

    Y el emisor separa: un provincial rinde por encima de la curva
    nacional por su propio riesgo de crédito. Mezclarlos hace dos daños a
    la vez, porque el provincial se muestra barato cuando solo refleja su
    spread, y de paso empuja la curva y deja a los nacionales caros.
    """
    emisor = emisor_de(cfg)
    sufijo = "" if emisor == "nacion" else "-" + emisor.upper()
    # Los duales rinden en pesos nominales, pero su TIR depende de una
    # tasa proyectada: no se comparan ni con la curva a tasa fija ni con
    # la CER, que es real.
    if _tipo(cfg) == "dual":
        return "DUAL" + sufijo
    ajuste = (cfg.get("ajuste") or "").lower()
    if ajuste == "cer":
        return "CER" + sufijo
    if ajuste in ("dolar_linked", "dolarlinked", "dl"):
        # paga al oficial, no al MEP: su TIR no se compara con la de un
        # hard dollar aunque las dos esten en dolares
        return "DL" + sufijo
    # Un bono en pesos sin ajuste rinde en pesos. La moneda que se usa
    # abajo es la de cotizacion, y por ella terminaria agrupado con los
    # hard dollar que cotizan en pesos: su TIR en dolares contra una en
    # pesos no se compara ni de casualidad.
    if (cfg.get("moneda") or "").upper() == "ARS":
        return "TASA$" + sufijo
    ley = "AR" if (cfg.get("ley") or "").startswith("arg") else "NY"
    moneda = info["moneda"]
    if moneda == "USD" and simbolo.endswith("C"):
        moneda = "CABLE"
    return "%s-%s%s" % (moneda, ley, sufijo)


def _tir(esp_cfg, precio, liq, filas):
    if not precio:
        return None
    r = RF.tir(precio, esp_cfg, liq, filas)
    return r * 100 if r is not None else None


def factor_cer(cfg, cer_actual=0):
    """Cuánto se ajustó el capital desde la emisión.

    El precio en pesos dividido por este factor queda expresado en
    unidades CER, que es donde vive el flujo. Descontando ahí, la TIR
    que sale es real: la X de "CER + X%".

    La base sale del BCRA con la fecha de emisión. Si el YAML trae
    cer_base cargado a mano, ese manda.
    """
    if (cfg.get("ajuste") or "").lower() != "cer":
        return 1.0
    base = float(cfg.get("cer_base") or 0)
    if not base:
        try:
            base = CER.base_de(cfg.get("emision")) or 0
        except Exception as e:
            log.debug("CER base: %s", e)
            base = 0
    if not cer_actual:
        try:
            cer_actual = CER.vigente() or 0
        except Exception:
            cer_actual = 0
    if not base or not cer_actual:
        return 0.0
    return float(cer_actual) / base


def liquidacion(d=None):
    """Fecha de liquidacion de un precio de 24 horas: el habil siguiente.

    Antes se liquidaba el mismo dia y el flujo seguia contando el pago
    del dia ex. El 08/07/2026 AL30D ya cotizaba sin el pago del 09/07 y
    la TIR daba 16,24% en vez de ~7,6%. Con T+1 el pago sale del flujo
    justo desde la fecha ex (el flujo toma los pagos posteriores a la
    liquidacion). Los feriados salen de `cer.FERIADOS`.
    """
    import cer as CER
    d = (d or date.today()) + timedelta(days=1)
    while not CER.es_habil(d):
        d += timedelta(days=1)
    return d


def fila(simbolo, info, cot, mep, liq=None, cer_actual=0):
    """Una fila de la tabla, con TIR en cada punta."""
    liq = liq or liquidacion()
    bonos, _ = cargar()
    cfg = bonos.get(info["cronograma"])
    if not cfg:
        return None

    bid = cot.get("compra") or 0
    ask = cot.get("venta") or 0
    last = cot.get("ultimo") or 0

    tasa_var = None
    if (cfg.get("interes") or {}).get("variable"):
        tasa_var = RF.tasa_variable(cfg, liq)
        if tasa_var is None:
            return {
                "simbolo": simbolo, "moneda": (cfg.get("moneda") or "ARS"),
                "cronograma": info["cronograma"],
                "bid": bid, "ask": ask, "last": last,
                "bid_usd": 0, "ask_usd": 0,
                "q_bid": cot.get("vol_compra") or 0,
                "q_ask": cot.get("vol_venta") or 0,
                "tir_bid": None, "tir_ask": None, "tir_last": None,
                "md": None, "last_viejo": False,
                "ley": cfg.get("ley"),
                "familia": _familia(cfg, info, simbolo),
                "emisor": emisor_de(cfg),
                "tipo": _tipo(cfg),
                "moneda_cotiza": _moneda_cotiza(info, simbolo),
                "ley_cod": "AR" if (cfg.get("ley") or "").startswith("arg") else "NY",
                "falta_tasa": True,
                "vencimiento": str(cfg["vencimiento"])[:10],
            }

    ajuste = (cfg.get("ajuste") or "").lower()
    es_cer = ajuste == "cer"
    es_dl = ajuste in ("dolar_linked", "dolarlinked", "dl")
    # Bono en pesos sin ajuste: la TIR que importa es en pesos. Pasarlo
    # por el MEP daria un rendimiento en dolares sobre flujos en pesos,
    # que no significa nada. Es el caso de los Bocon a BADLAR.
    es_ars = (not es_cer and not es_dl
              and (cfg.get("moneda") or "").upper() == "ARS")

    if es_dl:
        # Denominado en dolares, cotiza y paga en pesos al A3500. El
        # precio se lleva a dolares con ese tipo de cambio y de ahi en
        # mas se trata como cualquier bono en dolares.
        import dolar as DL
        tc = DL.vigente() or 0
        if not tc:
            return {
                "simbolo": simbolo, "moneda": "DL",
                "cronograma": info["cronograma"],
                "bid": bid, "ask": ask, "last": last,
                "bid_usd": 0, "ask_usd": 0,
                "q_bid": cot.get("vol_compra") or 0,
                "q_ask": cot.get("vol_venta") or 0,
                "tir_bid": None, "tir_ask": None, "tir_last": None,
                "md": None, "last_viejo": False,
                "ley": cfg.get("ley"),
                "familia": _familia(cfg, info, simbolo),
                "emisor": emisor_de(cfg),
                "tipo": _tipo(cfg),
                "moneda_cotiza": "ARS",
                "ley_cod": "AR" if (cfg.get("ley") or "").startswith("arg") else "NY",
                "falta_tc": True,
                "vencimiento": str(cfg["vencimiento"])[:10],
            }
        tc_bid = tc_ask = tc_med = tc
        bid_usd, ask_usd, last_usd = bid / tc, ask / tc, last / tc
    elif es_cer:
        f = factor_cer(cfg, cer_actual) * float(cfg.get("nominal_base") or 100) / 100
        if not f:
            return {
                "simbolo": simbolo, "moneda": "CER", "cronograma": info["cronograma"],
                "bid": bid, "ask": ask, "last": last,
                "bid_usd": 0, "ask_usd": 0,
                "q_bid": cot.get("vol_compra") or 0,
                "q_ask": cot.get("vol_venta") or 0,
                "tir_bid": None, "tir_ask": None, "tir_last": None,
                "md": None, "last_viejo": False,
                "ley": cfg.get("ley"),
                "familia": _familia(cfg, info, simbolo),
                "emisor": emisor_de(cfg),
                "tipo": _tipo(cfg),
                "moneda_cotiza": _moneda_cotiza(info, simbolo),
                "ley_cod": "AR" if (cfg.get("ley") or "").startswith("arg") else "NY",
                "falta_cer": True,
                "vencimiento": str(cfg["vencimiento"])[:10],
            }
        bid_usd, ask_usd, last_usd = bid / f, ask / f, last / f
    elif es_ars:
        # sin conversion: precio y flujo viven en la misma moneda
        bid_usd, ask_usd, last_usd = bid, ask, last
        tc_bid = tc_ask = tc_med = 1.0
    elif info["moneda"] == "USD":
        bid_usd, ask_usd, last_usd = bid, ask, last
        tc_bid = tc_ask = 1.0
    else:
        # el bid lo cobrás en pesos: para llevarlo a dólares tenés que comprarlos
        tc_bid = mep.get("comprar_usd") or 0
        # el ask lo pagás en pesos: los conseguiste vendiendo dólares
        tc_ask = mep.get("vender_usd") or 0
        tc_med = mep.get("medio") or 0
        bid_usd = bid / tc_bid if tc_bid else 0
        ask_usd = ask / tc_ask if tc_ask else 0
        last_usd = last / tc_med if tc_med else 0

    # El flujo va siempre por 100 de nominal. Cuando la lamina arranca de
    # un capital distinto -los del canje 2005, los Bocon que
    # capitalizaron- hay que llevar el precio a esa base antes de sacar
    # la TIR. En CER ya viene incluido en el factor.
    if not es_cer:
        nb = float(cfg.get("nominal_base") or 100) / 100.0
        if nb and nb != 1.0:
            bid_usd, ask_usd, last_usd = bid_usd / nb, ask_usd / nb, last_usd / nb

    filas_flujo = RF.flujo(cfg, liq, tasa_var=tasa_var)
    tir_bid = _tir(cfg, bid_usd, liq, filas_flujo)
    tir_ask = _tir(cfg, ask_usd, liq, filas_flujo)
    tir_last = _tir(cfg, last_usd, liq, filas_flujo)

    # la MD ordena la tabla: se calcula con el last, que es mas estable
    ref = tir_last if tir_last is not None else (
        tir_ask if tir_ask is not None else tir_bid)
    md = None
    if ref is not None:
        precio_ref = last_usd or ask_usd or bid_usd
        _, md = RF.duration(precio_ref, cfg, liq, ref / 100.0, filas_flujo)

    return {
        "simbolo": simbolo,
        "moneda": ("CER" if es_cer else "DL" if es_dl
                   else "ARS" if es_ars else info["moneda"]),
        "tir_moneda": "ARS" if es_ars else "USD",
        "ley": cfg.get("ley"),
        "familia": _familia(cfg, info, simbolo),
        "emisor": emisor_de(cfg),
        "tipo": _tipo(cfg),
        "moneda_cotiza": "ARS" if (es_dl or es_ars) else _moneda_cotiza(info, simbolo),
        "ley_cod": "AR" if (cfg.get("ley") or "").startswith("arg") else "NY",
        "falta_cer": False,
        "falta_tasa": False,
        "cronograma": info["cronograma"],
        "bid": bid, "ask": ask, "last": last,
        "bid_usd": bid_usd, "ask_usd": ask_usd,
        "q_bid": cot.get("vol_compra") or 0,
        "q_ask": cot.get("vol_venta") or 0,
        "tir_bid": tir_bid,
        "tir_ask": tir_ask,
        "tir_last": tir_last,
        "last_viejo": bool(cot.get("fecha") and str(cot["fecha"])[:10] <
                           liq.isoformat()),
        "md": md,
        "vencimiento": str(cfg["vencimiento"])[:10],
        "dual": _dual_resumen(cfg, liq, last or ask or bid),
    }


def _dual_resumen(cfg, liq, precio):
    """Lo que la tabla y el detalle muestran de un dual: que pata gana,
    el pago proyectado y la inflacion de equilibrio."""
    import dual as DU
    if not DU.es_dual(cfg):
        return None
    try:
        r = DU.calcular(cfg, liq)
    except Exception as e:
        log.warning("dual %s: %s", cfg.get("nombre"), e)
        return None
    if r is None:
        return {"falta_tamar": True}
    return r


def tabla(cot, liq=None, par_mep=("AL30", "AL30D"), cer_actual=0):
    """Todas las especies conocidas que tengan precio, ordenadas por MD."""
    liq = liq or liquidacion()
    mep = calcular_mep(cot, *par_mep)
    filas = []
    for sim, info in especies().items():
        c = cot.get(sim)
        if not c or not (c.get("compra") or c.get("venta") or c.get("ultimo")):
            continue
        try:
            f = fila(sim, info, c, mep, liq, cer_actual)
        except Exception as e:
            log.warning("%s: %s", sim, e)
            continue
        if f:
            filas.append(f)

    _brechas(filas)
    filas.sort(key=lambda f: (f["md"] is None, f["md"] or 0, f["simbolo"]))
    return {"mep": mep, "filas": filas,
            "cer_actual": cer_actual,
            "liquidacion": liq.isoformat(),
            "sin_precio": [s for s in especies() if s not in cot]}


def _brechas(filas):
    """Diferencia de TIR entre la especie D y la C del mismo bono.

    D liquida en dólar MEP y C en cable, así que cada TIR está medida en
    una moneda distinta y no son directamente comparables. Lo que sí
    significa algo es cuánto se separan: es el spread MEP-cable visto
    desde el rendimiento. Cuando un bono se despega del resto, ahí hay algo.
    """
    por_bono = {}
    for f in filas:
        s = f["simbolo"]
        if s.endswith("D") or s.endswith("C"):
            por_bono.setdefault(s[:-1], {})[s[-1]] = f

    for base, par in por_bono.items():
        d, c = par.get("D"), par.get("C")
        if not d or not c:
            continue
        for a, b in ((d, c), (c, d)):
            a["par_dolarizado"] = b["simbolo"]
        # se compara punta contra punta del mismo lado
        if d.get("tir_ask") is not None and c.get("tir_ask") is not None:
            br = c["tir_ask"] - d["tir_ask"]
            d["brecha_cable"] = br
            c["brecha_cable"] = br
        if d.get("ask_usd") and c.get("ask_usd"):
            impl = (d["ask_usd"] / c["ask_usd"] - 1) * 100
            d["cable_pct"] = impl
            c["cable_pct"] = impl


def detalle(simbolo, cot, liq=None, par_mep=("AL30", "AL30D"), cer_actual=0):
    """Lo que se muestra al tocar el ticker."""
    liq = liq or liquidacion()
    esps = especies()
    info = esps.get(simbolo)
    if not info:
        return None
    bonos, _ = cargar()
    cfg = bonos[info["cronograma"]]

    mep = calcular_mep(cot, *par_mep)
    f = fila(simbolo, info, cot.get(simbolo) or {}, mep, liq, cer_actual)
    if not f:
        return None

    # la brecha necesita la especie hermana (D contra C)
    if simbolo.endswith(("D", "C")):
        otra = simbolo[:-1] + ("C" if simbolo.endswith("D") else "D")
        if otra in esps and cot.get(otra):
            g = fila(otra, esps[otra], cot[otra], mep, liq, cer_actual)
            if g:
                _brechas([f, g])

    precio_usd = f["ask_usd"] or f["bid_usd"] or 0
    m = RF.metricas(cfg, precio_usd, liq) if precio_usd else {}
    tv = RF.tasa_variable(cfg, liq)
    flujo = RF.flujo(cfg, liq, tasa_var=tv)

    residual = m.get("residual") or RF.residual(cfg, liq)
    corrido = m.get("interes_corrido") or RF.interes_corrido(cfg, liq, tasa_var=tv)
    tecnico = residual + corrido
    import dual as DU
    if DU.es_dual(cfg):
        # sin cupones: lo devengado es el maximo de las dos patas a hoy
        vt = DU.tecnico(cfg, liq)
        residual = 100.0
        corrido = (vt - 100.0) if vt is not None else 0.0
        tecnico = vt if vt is not None else 0.0
    # en un bono CER el valor tecnico va ajustado por el coeficiente
    fcer = factor_cer(cfg, cer_actual)
    if fcer and fcer != 1.0:
        # el nominal de partida no siempre es 100: los del canje 2005
        # arrancan de un capital distinto al de la lámina
        tecnico *= fcer * float(cfg.get("nominal_base") or 100) / 100
    cupon = m.get("cupon_vigente") or 0

    return {
        "simbolo": simbolo,
        "nombre": cfg.get("nombre"),
        "ley": cfg.get("ley"),
        "ajuste": cfg.get("ajuste"),
        "cer_base": cfg.get("cer_base"),
        "factor_cer": factor_cer(cfg, cer_actual) or None,
        "moneda_flujo": cfg.get("moneda"),
        "emisor": emisor_de(cfg),
        "aviso": cfg.get("verificar"),
        "nota": cfg.get("derivacion"),
        "fila": f,
        "vencimiento": str(cfg["vencimiento"])[:10],
        "proximo_pago": m.get("proximo_pago"),
        "residual": residual,
        "interes_corrido": corrido,
        "valor_tecnico": tecnico,
        "paridad": ((f["last"] if fcer != 1.0 else precio_usd) / tecnico * 100)
                   if tecnico else None,
        "cer_factor": fcer if fcer != 1.0 else None,
        "cer_base_fecha": (CER._restar_habiles(
            RF._fecha(cfg["emision"]), CER.REZAGO_HABILES).isoformat()
            if (cfg.get("ajuste") or "").lower() == "cer" else None),
        "cupon_vigente": cupon,
        "current_yield": (residual * cupon / 100.0 / precio_usd * 100)
                         if precio_usd else None,
        "duration": m.get("duration"),
        "md": f["md"],
        "años_al_vto": m.get("años_al_vto"),
        "spread_tir": (f["tir_bid"] - f["tir_ask"])
                      if (f["tir_bid"] is not None and f["tir_ask"] is not None)
                      else None,
        "flujo": [{
            "fecha": x["fecha"].isoformat(),
            "renta": x["renta"],
            "amortizacion": x["amortizacion"],
            "total": x["total"],
            "residual": x["residual_previo"],
        } for x in flujo],
    }


# =====================================================================
#  Rulo: tipos de cambio implícitos en cada bono
# =====================================================================

def _tc(pesos, dolarizada):
    """Los dos tipos de cambio que salen de un bono contra su especie D o C.

    - comprar: pesos por dólar si comprás el bono en pesos (ask) y vendés
      la especie dolarizada (bid).
    - vender: pesos que recibís por dólar si hacés el camino inverso.
    """
    ask_p = (pesos or {}).get("venta") or 0
    bid_p = (pesos or {}).get("compra") or 0
    ask_d = (dolarizada or {}).get("venta") or 0
    bid_d = (dolarizada or {}).get("compra") or 0
    return {
        "comprar": (ask_p / bid_d) if (ask_p and bid_d) else None,
        "vender": (bid_p / ask_d) if (bid_p and ask_d) else None,
        "q_comprar": min((pesos or {}).get("vol_venta") or 0,
                         (dolarizada or {}).get("vol_compra") or 0),
        "q_vender": min((pesos or {}).get("vol_compra") or 0,
                        (dolarizada or {}).get("vol_venta") or 0),
    }


def rulo(cot, umbral_pct=0.6):
    """Tipos de cambio implícitos por bono y el ciclo más conveniente.

    Si el bono más barato para comprar dólares está por debajo del más caro
    para venderlos, hay un rulo: comprás por uno y vendés por el otro.
    """
    bonos, _ = cargar()
    filas = []
    for base in bonos:
        p = cot.get(base)
        if not p:
            continue
        f = {"bono": base}
        for letra, clave in (("D", "mep"), ("C", "cable")):
            esp = base + letra
            if cot.get(esp):
                f[clave] = _tc(p, cot[esp])
                f[clave]["especie"] = esp
        if "mep" in f or "cable" in f:
            # brecha cable/mep del propio bono, con la punta de compra
            m = (f.get("mep") or {}).get("comprar")
            c = (f.get("cable") or {}).get("comprar")
            f["brecha_pct"] = ((c / m - 1) * 100) if (m and c) else None
            filas.append(f)

    def _mejor(clave, direccion, peor=False):
        cand = [(f[clave][direccion], f["bono"]) for f in filas
                if f.get(clave) and f[clave].get(direccion)]
        if not cand:
            return None, None
        return (max(cand) if peor else min(cand))

    ciclos = {}
    for clave in ("mep", "cable"):
        barato, b_bono = _mejor(clave, "comprar")
        caro, c_bono = _mejor(clave, "vender", peor=True)
        if barato and caro:
            ciclos[clave] = {
                "comprar_en": b_bono, "precio_compra": barato,
                "vender_en": c_bono, "precio_venta": caro,
                "diferencia_pct": (caro / barato - 1) * 100,
                "umbral_pct": umbral_pct,
                "hay_rulo": (caro / barato - 1) * 100 >= umbral_pct,
                "mismo_bono": b_bono == c_bono,
            }

    filas.sort(key=lambda f: ((f.get("mep") or {}).get("comprar") or 9e9))
    return {"filas": filas, "ciclos": ciclos}


def mep_al(fecha, par_pesos="AL30", par_usd="AL30D", tolerancia=7):
    """El MEP de una fecha pasada, reconstruido de la serie guardada.

    Las dos puntas del par estan en `bono_hist` con precio diario, y las
    dos cotizan por cada 100 nominales, asi que el cociente sale limpio.

    Si ese dia no hay dato -feriado, o la serie arranca despues- se busca
    hacia atras hasta `tolerancia` dias. Mas atras no: un tipo de cambio
    de hace dos semanas aplicado a una compra no mide nada, y devolver
    None deja el resultado en guion, que avisa.
    """
    import historico as H
    try:
        f = fecha if isinstance(fecha, str) else fecha.isoformat()
        desde = (datetime.fromisoformat(f).date()
                 - timedelta(days=tolerancia)).isoformat()
        pesos = {r["fecha"]: r["precio"] for r in H.serie(par_pesos, desde, f)}
        usd = {r["fecha"]: r["precio"] for r in H.serie(par_usd, desde, f)}
        for d in sorted(set(pesos) & set(usd), reverse=True):
            if pesos[d] and usd[d]:
                return pesos[d] / usd[d]
    except Exception as e:
        # Sin serie, con la tabla todavia sin crear o con una fecha mal
        # formada, esto devuelve None y el resultado en dolares queda en
        # guion. Que reviente aca cortaria la confirmacion de un
        # movimiento, que es una operacion que no tiene nada que ver.
        log.debug("mep al %s: %s", fecha, e)
    return None
