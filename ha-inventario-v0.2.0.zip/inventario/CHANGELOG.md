# Changelog

## 0.2.0

- Actualizar desde la app subiendo un zip (solo como app local en /local_apps). Revisa el zip, muestra los cambios, respalda el código en /config y pide la instalación a Home Assistant.
- Aviso al celular cuando termina una actualización, o si no termina. Nueva opción `ha_notify_service`.
- Los sensores de batería se incluyen siempre, aunque sean de diagnóstico.
- "Configuración" viene destildada por defecto.
- La sección "Sin registro (YAML sin unique_id)" pasa a "Sin registro".

## 0.1.0

- Primera versión.
- Lee áreas, pisos, dispositivos, entidades, estados y configuración por la API websocket local.
- Genera el inventario en markdown: por área y dispositivo, sin área, sin registro, automatizaciones y scripts.
- Filtros: diagnóstico, configuración, deshabilitadas u ocultas, y dominios excluidos por opción.
- Botones Copiar (portapapeles con respaldo para Ingress sin HTTPS) y Descargar (blob .md).
- Conexión con token de larga duración y, si falla, con el token del Supervisor.
