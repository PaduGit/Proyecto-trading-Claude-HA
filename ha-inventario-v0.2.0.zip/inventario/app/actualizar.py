"""Actualizar la app desde la propia app subiendo un zip.

Adaptado del actualizador de Ratios 0.77.0, sin la parte de la base.
Funciona solo como app local (código en /local_apps). Pasos:

1. Revisar el zip: raíz `inventario/`, archivos obligatorios, sin rutas
   raras, slug correcto y versión mayor a la instalada.
2. Respaldar el código actual en /config (`inventario-addon-<versión>.zip`).
3. Dejar la carpeta de la app igual al zip: copiar y borrar lo que no trae.
4. Recargar la tienda y pedirle a Home Assistant `update.install` sobre la
   entidad update.* de la app. El Supervisor no deja que una app se
   actualice a sí misma.
5. Al arrancar con la versión nueva, avisar al celular una sola vez.
"""
import io
import json
import logging
import os
import re
import shutil
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from datetime import datetime

import ha

log = logging.getLogger("actualizar")

CARPETAS_LOCALES = ("/local_apps", "/addons")
SUPERVISOR = "http://supervisor"
SLUG_CONFIG = "inventario_ha"
PREFIJO = "inventario/"
CARPETA_RESPALDO = "/config"
RUTA_ESTADO = os.environ.get("INVENTARIO_ESTADO", "/data/estado.json")
OBLIGATORIOS = ("inventario/config.yaml", "inventario/Dockerfile", "inventario/run.sh",
                "inventario/app/main.py", "inventario/app/static/index.html")
MAX_ZIP = 10 * 1024 * 1024
RAIZ_LOCAL = None  # para pruebas

# Quién avisa: lo fija main.py al arrancar.
avisar = None


# -- estado persistido en /data ------------------------------------------

def _leer_estado():
    try:
        with open(RUTA_ESTADO, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def get_estado(clave):
    return _leer_estado().get(clave)


def set_estado(clave, valor):
    d = _leer_estado()
    d[clave] = valor
    tmp = RUTA_ESTADO + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, RUTA_ESTADO)
    except OSError as e:
        log.warning("no se pudo guardar el estado: %s", e)


# -- utilidades ----------------------------------------------------------

def _token():
    return ha.token_supervisor()


def _http(metodo, url, cuerpo=None, timeout=30):
    datos = json.dumps(cuerpo).encode("utf-8") if cuerpo is not None else None
    req = urllib.request.Request(url, data=datos, method=metodo, headers={
        "Authorization": "Bearer " + _token(), "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            texto = r.read().decode("utf-8", "replace")
            codigo = r.status
    except urllib.error.HTTPError as e:
        texto = e.read().decode("utf-8", "replace")
        codigo = e.code
    try:
        d = json.loads(texto) if texto else None
    except ValueError:
        d = None
    if codigo >= 300:
        msg = (d or {}).get("message") if isinstance(d, dict) else None
        raise RuntimeError("%s %s: HTTP %s %s" % (metodo, url.replace(SUPERVISOR, ""), codigo,
                                                   (msg or texto)[:160]))
    return d


def _sup(metodo, ruta, timeout=30):
    d = _http(metodo, SUPERVISOR + ruta, timeout=timeout) or {}
    if d.get("result") == "error":
        raise RuntimeError("Supervisor %s: %s" % (ruta, d.get("message")))
    return d.get("data") or {}


def _core(metodo, ruta, cuerpo=None, timeout=30):
    return _http(metodo, SUPERVISOR + "/core/api" + ruta, cuerpo, timeout)


def _ver(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def _version_de(texto):
    for linea in texto.splitlines():
        if linea.startswith("version:"):
            return linea.split(":", 1)[1].strip().strip("\"'")
    return None


def _es_slug(texto):
    return re.search(r"^slug:\s*\"?%s\"?\s*$" % SLUG_CONFIG, texto, re.M) is not None


def carpeta_app():
    """La carpeta de /local_apps cuyo config.yaml tiene el slug de la app.
    None si la app no corre como local."""
    raiz = RAIZ_LOCAL or next((c for c in CARPETAS_LOCALES if os.path.isdir(c)), None)
    if not raiz or not os.path.isdir(raiz):
        return None
    for nombre in sorted(os.listdir(raiz)):
        try:
            with open(os.path.join(raiz, nombre, "config.yaml"), encoding="utf-8") as f:
                if _es_slug(f.read()):
                    return os.path.join(raiz, nombre)
        except OSError:
            continue
    return None


def _avisar(titulo, texto):
    try:
        if avisar:
            avisar(titulo, texto)
    except Exception as e:
        log.warning("aviso: %s", e)


# -- estado y aviso al arrancar ------------------------------------------

def avisar_si_actualizada(version_actual):
    destino = get_estado("destino")
    if not destino or get_estado("avisado") == destino:
        return False
    if _ver(version_actual) < _ver(destino):
        return False
    set_estado("avisado", destino)
    set_estado("error", "")
    _avisar("Inventario HA actualizada a %s" % version_actual,
            "La app ya se instaló y está corriendo con la versión <b>%s</b>." % version_actual)
    return True


def estado(version_actual=None):
    err = get_estado("error") or None
    destino = get_estado("destino")
    # Al detener la app para actualizarla, el pedido se corta y puede quedar
    # anotado como error: si la versión ya llegó, no lo es.
    if err and destino and version_actual and _ver(version_actual) >= _ver(destino):
        set_estado("error", "")
        err = None
    car = carpeta_app()
    return {"local": bool(car), "carpeta": car, "supervisor": bool(_token()),
            "ultimo": get_estado("ultimo"), "error": err}


# -- revisar el zip ------------------------------------------------------

def revisar_zip(datos, version_actual):
    if len(datos) > MAX_ZIP:
        raise ValueError("El archivo es demasiado grande para ser la app.")
    try:
        z = zipfile.ZipFile(io.BytesIO(datos))
    except zipfile.BadZipFile:
        raise ValueError("No es un zip.")
    nombres = z.namelist()
    for n in nombres:
        if n.startswith("/") or "\\" in n or ".." in n.split("/") or not n.startswith(PREFIJO):
            raise ValueError("El zip tiene una ruta inesperada: %s" % n)
    falta = [n for n in OBLIGATORIOS if n not in nombres]
    if falta:
        raise ValueError("No parece un zip de Inventario HA: falta %s." % ", ".join(falta))
    cfg = z.read(PREFIJO + "config.yaml").decode("utf-8", "replace")
    if not _es_slug(cfg):
        raise ValueError("El zip es de otra app.")
    nueva = _version_de(cfg)
    if not nueva:
        raise ValueError("El config.yaml del zip no tiene versión.")
    if version_actual and _ver(nueva) <= _ver(version_actual):
        raise ValueError("El zip es la versión %s y la instalada es %s: tiene que ser mayor."
                         % (nueva, version_actual))
    return z, nueva


def cambios(z, version_actual):
    try:
        texto = z.read(PREFIJO + "CHANGELOG.md").decode("utf-8", "replace")
    except KeyError:
        return []
    out, actual = [], None
    for linea in texto.splitlines():
        m = re.match(r"^##\s+(\d+\.\d+\.\d+)", linea)
        if m:
            if version_actual and _ver(m.group(1)) <= _ver(version_actual):
                break
            actual = {"version": m.group(1), "texto": []}
            out.append(actual)
            continue
        if actual is not None:
            actual["texto"].append(linea)
    for c in out:
        c["texto"] = "\n".join(c["texto"]).strip()
    return out


def revisar(datos, version_actual):
    z, nueva = revisar_zip(datos, version_actual)
    return {"de": version_actual, "a": nueva, "cambios": cambios(z, version_actual),
            "local": bool(carpeta_app()), "supervisor": bool(_token())}


# -- copiar --------------------------------------------------------------

def _respaldar_codigo(carpeta, version_actual):
    destino = os.path.join(CARPETA_RESPALDO, "inventario-addon-%s.zip" % (version_actual or "anterior"))
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for raiz, _dirs, archivos in os.walk(carpeta):
            for a in archivos:
                ruta = os.path.join(raiz, a)
                z.write(ruta, os.path.join("inventario", os.path.relpath(ruta, carpeta)))
    return destino


def _copiar(z, carpeta):
    """Deja la carpeta igual al zip. Devuelve (copiados, borrados)."""
    tmp = tempfile.mkdtemp(prefix=".inventario-nuevo-", dir=os.path.dirname(carpeta))
    try:
        z.extractall(tmp)
        origen = os.path.join(tmp, "inventario")
        n, nuevos = 0, set()
        for raiz, _dirs, archivos in os.walk(origen):
            rel = os.path.relpath(raiz, origen)
            dst = os.path.join(carpeta, rel) if rel != "." else carpeta
            os.makedirs(dst, exist_ok=True)
            for a in archivos:
                shutil.copy2(os.path.join(raiz, a), os.path.join(dst, a))
                nuevos.add(os.path.normpath(os.path.join(rel, a)))
                n += 1
        borrados = []
        for raiz, _dirs, archivos in os.walk(carpeta, topdown=False):
            rel = os.path.relpath(raiz, carpeta)
            for a in archivos:
                r = os.path.normpath(os.path.join(rel, a))
                if r not in nuevos:
                    try:
                        os.remove(os.path.join(raiz, a))
                        borrados.append(r)
                    except OSError as e:
                        log.warning("no se pudo borrar %s: %s", r, e)
            if raiz != carpeta and not os.listdir(raiz):
                try:
                    os.rmdir(raiz)
                except OSError:
                    pass
        if borrados:
            log.info("borrados %d archivos que el zip no trae: %s",
                     len(borrados), ", ".join(sorted(borrados)[:20]))
        return n, borrados
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# -- pedir la actualización ----------------------------------------------

def _entidad_update(slug):
    for e in _core("GET", "/states") or []:
        eid = e.get("entity_id") or ""
        if not eid.startswith("update."):
            continue
        a = e.get("attributes") or {}
        if slug in (a.get("entity_picture") or "") or slug.replace("local_", "") in eid \
                or (a.get("title") or a.get("friendly_name") or "").lower().startswith("inventario"):
            return eid
    return None


def _pedir_actualizacion(nueva, espera=10, intentos=18):
    time.sleep(2)
    try:
        slug = _sup("GET", "/addons/self/info").get("slug") or "local_" + SLUG_CONFIG
        _sup("POST", "/store/reload", timeout=120)
        set_estado("error", "")
        eid, listo = None, False
        for _ in range(intentos):
            eid = eid or _entidad_update(slug)
            if eid:
                try:
                    _core("POST", "/services/homeassistant/update_entity", {"entity_id": eid})
                except RuntimeError:
                    pass
                st = _core("GET", "/states/" + eid) or {}
                lat = (st.get("attributes") or {}).get("latest_version")
                if st.get("state") == "on" and lat == nueva:
                    listo = True
                    break
            time.sleep(espera)
        if not eid:
            raise RuntimeError("no encontré la entidad de actualización de la app en Home Assistant")
        if not listo:
            raise RuntimeError("Home Assistant no vio la versión %s en 3 minutos" % nueva)
        log.warning("actualizando %s con %s", slug, eid)
    except Exception as e:
        log.warning("actualizar: %s", e)
        set_estado("error", "%s · terminala con Ajustes → Apps → Inventario HA → Actualizar" % str(e)[:250])
        _avisar("Inventario HA: la actualización no terminó",
                "No se pudo instalar la versión %s desde la app: %s. Terminala con Ajustes → Apps → "
                "Inventario HA → Actualizar." % (nueva, str(e)[:200]))
        return
    # HA detiene la app para instalar y el pedido se corta: no es un error.
    try:
        _core("POST", "/services/update/install", {"entity_id": eid}, timeout=900)
    except Exception as e:
        log.info("pedido de instalación cortado (la app se detiene para actualizarse): %s", e)


def actualizar(datos, version_actual):
    carpeta = carpeta_app()
    if not carpeta:
        raise RuntimeError("La app no corre como app local (/local_apps): no se puede actualizar "
                           "desde acá. Instalada desde GitHub se actualiza con git push.")
    z, nueva = revisar_zip(datos, version_actual)
    try:
        resp = _respaldar_codigo(carpeta, version_actual)
    except OSError as e:
        log.warning("respaldo del código: %s", e)
        resp = None
    n, borrados = _copiar(z, carpeta)
    set_estado("destino", nueva)
    set_estado("ultimo", "%s → %s · %s" % (version_actual, nueva,
                                           datetime.now().isoformat(timespec="seconds")))
    if not _token():
        set_estado("error", "sin acceso al Supervisor: falta actualizar a mano")
        return {"de": version_actual, "a": nueva, "archivos": n, "borrados": len(borrados),
                "respaldo_codigo": resp, "manual": True}
    threading.Thread(target=_pedir_actualizacion, args=(nueva,), daemon=True,
                     name="actualizar").start()
    return {"de": version_actual, "a": nueva, "archivos": n, "borrados": len(borrados),
            "respaldo_codigo": resp, "manual": False}
