"""Aviso al celular por el servicio notify de Home Assistant.

Primero con el token propio y ha_url; si no hay token o falla, por el
proxy del Supervisor.
"""
import json
import logging
import urllib.request

import ha

log = logging.getLogger("notificar")


class Notificador:
    def __init__(self, cfg):
        self.servicio = (cfg.get("ha_notify_service") or "").strip().replace("notify.", "", 1)
        self.token = (cfg.get("ha_token") or "").strip()
        self.url = (cfg.get("ha_url") or ha.URL_POR_DEFECTO).strip().rstrip("/")

    def _destinos(self):
        out = []
        if self.token:
            out.append((self.url + "/api", self.token))
        sup = ha.token_supervisor()
        if sup:
            out.append(("http://supervisor/core/api", sup))
        return out

    def enviar(self, titulo, mensaje):
        if not self.servicio:
            log.info("sin ha_notify_service: no se avisa")
            return False
        cuerpo = json.dumps({"title": titulo, "message": mensaje}).encode("utf-8")
        for base, token in self._destinos():
            req = urllib.request.Request(
                "%s/services/notify/%s" % (base, self.servicio), data=cuerpo, method="POST",
                headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=10) as r:
                    if r.status < 300:
                        return True
            except Exception as e:
                log.warning("aviso por %s: %s", base, e)
        return False
