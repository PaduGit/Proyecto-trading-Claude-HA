"""Actualizar la app desde la propia app, sin GitHub ni SSH.

Ratios corre como add-on local: su codigo vive en la carpeta `/addons` de
Home Assistant (mapeada con `addons:rw`). Actualizar es:

1. Subir el zip desde el menu.
2. Revisarlo: que sea un zip de Ratios (raiz `ratios/`, con `config.yaml`,
   `Dockerfile` y `app/main.py`), sin rutas raras, con una version mayor a
   la instalada.
3. Copia de la base en `/config` y del codigo actual en `/config`
   (`ratios-addon-<version>.zip`), para volver atras a mano.
4. Copiar los archivos sobre la carpeta del add-on (como `unzip -o`: lo
   que el zip no trae, como `uplot.min.js`, queda).
5. Pedirle al Supervisor que recargue la tienda y actualice el add-on, que
   se reconstruye en la Dell y vuelve a arrancar solo.

Restaurar la base (por ejemplo, la bajada del add-on anterior al migrar):
se sube el archivo, se deja como `/data/ratios-restaurar.db` y se pide un
reinicio; al arrancar, antes de abrir la base, se pone en su lugar y la
anterior queda como `/data/ratios-antes-de-restaurar.db`.
"""

import io
import logging
import os
import re
import shutil
import sqlite3
import tempfile
import threading
import time
import zipfile
from datetime import datetime

import requests

import db

log = logging.getLogger("ratios.actualizar")

# Desde la 2026.06 del Supervisor las apps locales viven en /local_apps
# (antes /addons). Se usa la que exista.
CARPETAS_LOCALES = ("/local_apps", "/addons")
ADDONS = None
SUPERVISOR = "http://supervisor"
SLUG_CONFIG = "ratios_iol"
CARPETA_RESPALDO = "/config"
OBLIGATORIOS = ("ratios/config.yaml", "ratios/Dockerfile", "ratios/app/main.py")
MAX_ZIP = 30 * 1024 * 1024


def _token():
    return os.environ.get("SUPERVISOR_TOKEN") or os.environ.get("HASSIO_TOKEN") or ""


def _sup(metodo, ruta, timeout=30):
    r = requests.request(metodo, SUPERVISOR + ruta, timeout=timeout,
                         headers={"Authorization": "Bearer " + _token()})
    try:
        d = r.json()
    except ValueError:
        d = {}
    if r.status_code >= 300 or d.get("result") == "error":
        raise RuntimeError("Supervisor %s %s: HTTP %s %s" % (metodo, ruta, r.status_code,
                                                              (d.get("message") or r.text)[:160]))
    return d.get("data") or {}


def _ver(v):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0"))


def _version_de(texto):
    for linea in texto.splitlines():
        if linea.startswith("version:"):
            return linea.split(":", 1)[1].strip().strip("\"'")
    return None


def carpeta_addon():
    """La carpeta del add-on local: la de /addons cuyo config.yaml tiene
    `slug: ratios_iol`. None si la app no corre como add-on local."""
    raiz = ADDONS or next((c for c in CARPETAS_LOCALES if os.path.isdir(c)), None)
    if not raiz or not os.path.isdir(raiz):
        return None
    for nombre in sorted(os.listdir(raiz)):
        cfg = os.path.join(raiz, nombre, "config.yaml")
        try:
            with open(cfg, encoding="utf-8") as f:
                if re.search(r"^slug:\s*\"?%s\"?\s*$" % SLUG_CONFIG, f.read(), re.M):
                    return os.path.join(raiz, nombre)
        except OSError:
            continue
    return None


def estado():
    car = carpeta_addon()
    return {"local": bool(car), "carpeta": car, "supervisor": bool(_token()),
            "ultimo": db.get_estado("actualizar_ultimo"),
            "error": db.get_estado("actualizar_error") or None}


def revisar_zip(datos, version_actual):
    """Valida el zip. Devuelve (ZipFile, version nueva)."""
    if len(datos) > MAX_ZIP:
        raise ValueError("El archivo es demasiado grande para ser la app.")
    try:
        z = zipfile.ZipFile(io.BytesIO(datos))
    except zipfile.BadZipFile:
        raise ValueError("No es un zip.")
    nombres = z.namelist()
    for n in nombres:
        if n.startswith("/") or ".." in n.split("/") or not n.startswith("ratios/"):
            raise ValueError("El zip tiene una ruta inesperada: %s" % n)
    falta = [n for n in OBLIGATORIOS if n not in nombres]
    if falta:
        raise ValueError("No parece un zip de Ratios: falta %s." % ", ".join(falta))
    nueva = _version_de(z.read("ratios/config.yaml").decode("utf-8", "replace"))
    if not nueva:
        raise ValueError("El config.yaml del zip no tiene versión.")
    if re.search(r"^slug:\s*\"?%s\"?\s*$" % SLUG_CONFIG,
                 z.read("ratios/config.yaml").decode("utf-8", "replace"), re.M) is None:
        raise ValueError("El zip es de otro add-on.")
    if version_actual and _ver(nueva) <= _ver(version_actual):
        raise ValueError("El zip es la versión %s y la instalada es %s: tiene que ser mayor."
                         % (nueva, version_actual))
    return z, nueva


def _respaldar_codigo(carpeta, version_actual):
    destino = os.path.join(CARPETA_RESPALDO, "ratios-addon-%s.zip" % (version_actual or "anterior"))
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
        for raiz, _dirs, archivos in os.walk(carpeta):
            for a in archivos:
                ruta = os.path.join(raiz, a)
                z.write(ruta, os.path.join("ratios", os.path.relpath(ruta, carpeta)))
    return destino


def _copiar(z, carpeta):
    """Extrae a una carpeta temporal al lado y copia encima, archivo por
    archivo. Lo que el zip no trae queda."""
    tmp = tempfile.mkdtemp(prefix=".ratios-nuevo-", dir=os.path.dirname(carpeta))
    try:
        z.extractall(tmp)
        origen = os.path.join(tmp, "ratios")
        n = 0
        for raiz, _dirs, archivos in os.walk(origen):
            rel = os.path.relpath(raiz, origen)
            dst = os.path.join(carpeta, rel) if rel != "." else carpeta
            os.makedirs(dst, exist_ok=True)
            for a in archivos:
                shutil.copy2(os.path.join(raiz, a), os.path.join(dst, a))
                n += 1
        return n
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _pedir_actualizacion():
    """Recarga la tienda y actualiza el add-on. Corre en un hilo aparte y un
    poco despues de responder: cuando el Supervisor detiene el contenedor
    esta respuesta ya salio."""
    time.sleep(2)
    try:
        slug = (_sup("GET", "/addons/self/info").get("slug")) or "local_" + SLUG_CONFIG
        _sup("POST", "/store/reload", timeout=120)
        db.set_estado("actualizar_error", "")
        log.warning("actualizando %s: el Supervisor reconstruye y reinicia la app", slug)
        try:
            _sup("POST", "/store/addons/%s/update" % slug, timeout=900)
        except RuntimeError as e:
            # Un add-on local que el Supervisor no da por desactualizado se
            # reconstruye directamente con el codigo nuevo.
            log.warning("update: %s; se reconstruye", e)
            _sup("POST", "/addons/%s/rebuild" % slug, timeout=900)
    except Exception as e:
        log.warning("actualizar: %s", e)
        db.set_estado("actualizar_error", str(e)[:300])


def actualizar(datos, version_actual):
    """Todo el proceso. Devuelve {de, a, archivos, respaldo_codigo}."""
    carpeta = carpeta_addon()
    if not carpeta:
        raise RuntimeError("La app no corre como add-on local (carpeta /addons): no se puede "
                           "actualizar desde acá.")
    if not _token():
        raise RuntimeError("La app no tiene acceso al Supervisor de Home Assistant.")
    z, nueva = revisar_zip(datos, version_actual)
    db.copia_de_seguridad()
    resp = _respaldar_codigo(carpeta, version_actual)
    n = _copiar(z, carpeta)
    db.set_estado("actualizar_ultimo", "%s → %s · %s" % (
        version_actual, nueva, datetime.now().isoformat(timespec="seconds")))
    threading.Thread(target=_pedir_actualizacion, daemon=True, name="actualizar").start()
    return {"de": version_actual, "a": nueva, "archivos": n, "respaldo_codigo": resp}


# -- restaurar la base ----------------------------------------------------

def _pendiente():
    return os.path.join(os.path.dirname(db.RUTA), "ratios-restaurar.db")


def preparar_restauracion(datos):
    """Valida la base subida y la deja para el proximo arranque."""
    if not datos.startswith(b"SQLite format 3\x00"):
        raise ValueError("No es una base de SQLite.")
    fd, tmp = tempfile.mkstemp(suffix=".db", dir=os.path.dirname(db.RUTA))
    with os.fdopen(fd, "wb") as f:
        f.write(datos)
    try:
        c = sqlite3.connect(tmp)
        tablas = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        ok = c.execute("PRAGMA integrity_check").fetchone()[0]
        c.close()
    except sqlite3.DatabaseError as e:
        os.remove(tmp)
        raise ValueError("La base no se puede leer: %s" % e)
    if ok != "ok" or not {"tenencia", "estado"} <= tablas:
        os.remove(tmp)
        raise ValueError("No es una base de Ratios o está dañada.")
    os.replace(tmp, _pendiente())
    return {"tablas": len(tablas)}


def reiniciar():
    """Pide al Supervisor reiniciar la app, un poco despues de responder."""
    def _r():
        time.sleep(2)
        try:
            _sup("POST", "/addons/self/restart", timeout=60)
        except Exception as e:
            log.warning("reiniciar: %s", e)
    threading.Thread(target=_r, daemon=True, name="reiniciar").start()


def aplicar_restauracion_pendiente():
    """Al arrancar, antes de abrir la base."""
    p = _pendiente()
    if not os.path.exists(p):
        return False
    if os.path.exists(db.RUTA):
        os.replace(db.RUTA, os.path.join(os.path.dirname(db.RUTA), "ratios-antes-de-restaurar.db"))
    for sufijo in ("-wal", "-shm"):
        try:
            os.remove(db.RUTA + sufijo)
        except OSError:
            pass
    os.replace(p, db.RUTA)
    log.warning("base restaurada desde el archivo subido; la anterior quedó como "
                "ratios-antes-de-restaurar.db")
    return True
