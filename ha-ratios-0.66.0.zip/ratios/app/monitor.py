"""Motor de monitoreo: paneles, ratios, niveles y alertas."""

import logging
import statistics
import threading
import time
from datetime import date, datetime, timedelta

import db
from iol import IOLError

log = logging.getLogger("monitor")

# Simbolos que en tenencias representan efectivo, no un titulo.
MONEDAS_TENENCIA = {"ARS", "$", "MEP", "D", "CABLE", "C", "USD"}

VENTANA_DIAS = 90
MIN_MUESTRA_Z = 20
MIN_MUESTRA_PROPIA = 15
BACKFILL_DIAS = 400


# Pares por diferencial de TIR (0.58.0)
MARGEN_TIR_PB = 5.0     # histeresis de soporte y resistencia, en pb
MIN_DIAS_TIR = 60       # mas cerca del vencimiento se avisa en la tarjeta


def _zona_curva(z, umbral, h, previa):
    """Zona de un bono contra su curva, con histeresis.

    Entra con |z| >= umbral; una vez adentro sale recien cuando |z| baja
    de umbral - h. Sin eso, un z que oscilaba entre 2,49 y 2,51 rearmaba
    y volvia a avisar cada dos ciclos: el 30/09/2026 TZX27 aviso cinco
    veces y TZXD8 cuatro.
    """
    if previa == "barato" and z >= umbral - h:
        return "barato"
    if previa == "caro" and z <= -(umbral - h):
        return "caro"
    if z >= umbral:
        return "barato"
    if z <= -umbral:
        return "caro"
    return None


def _bono_base(sim, conocidos):
    """GD46C y GD46D son el mismo bono que GD46 en otra moneda: un aviso
    por bono y no por moneda. Solo se recorta la C o la D final si la
    version en pesos existe entre los `conocidos`."""
    if len(sim) >= 5 and sim[-1] in "CD" and sim[:-1] in conocidos:
        return sim[:-1]
    return sim


class Monitor:
    def __init__(self, cfg, iol, notif):
        self.cfg = cfg
        self.iol = iol
        self.notif = notif
        # Los pares viven en la base, no en la configuracion: se crean y
        # editan desde la app y sobreviven a una reinstalacion via el
        # respaldo. La lista de cfg solo sirvio para migrarlos.
        self._pares_cache = []
        # Cotizaciones descartadas por no operar hace dias: no sirven
        # para operar, si para valuar.
        self._viejas = {}
        # La cuotaparte de los fondos se publica una vez por dia.
        self._fci_dia, self._fci_cache = None, {}
        self._pares_ts = None

        self.snapshot = {}
        self.plazos = {}
        self.lock = threading.Lock()
        self.ultimo_ciclo = None
        self.ultimo_error = None
        self.hay_rueda = None
        self.cotizaciones = {}      # simbolo -> dict, del ultimo ciclo
        self.origen = {}            # simbolo -> "panel" | "individual"

        self._zona_actual = self._cargar_zonas()
        self._zonas_curva = self._cargar_zonas_curva()
        # Cuantos ciclos seguidos lleva cada bono en una zona nueva sin
        # avisar todavia. En memoria: un reinicio solo demora el aviso.
        self._curva_racha = {}
        self._canjes_avisado = self._cargar_canjes()
        self._cursor_especie = 0
        self.fuente = "iol"
        self.byma_fallas = []
        self.cot_t0 = {}
        self.canjes = []
        self._pidiendo = threading.Lock()
        self._ultimo_manual = datetime.min
        self._opc_estado = None     # persistencia del cruce, por combinacion
        self._opc_desarme = set()   # posiciones ya avisadas
        self._rulo_avisado = set()   # circuitos ya avisados
        self.orleans_fallas = []
        self.orleans_descartados = []
        self.sin_cotizacion = []
        self._orleans_opciones = None
        self._plazos_avisado = set()
        self._precio_avisado = set()
        self.plazos = []
        self.circuitos = {}         # ultimo resultado del Rulo
        self.snapshot_desde = None

    # -- estado persistente -------------------------------------------

    def _cargar_zonas(self):
        """La zona vive en la base: si no, cada reinicio repite las alertas."""
        import json
        try:
            return json.loads(db.get_estado("zonas") or "{}")
        except (ValueError, TypeError):
            return {}

    def _cargar_zonas_curva(self):
        import json
        try:
            return json.loads(db.get_estado("zonas_curva") or "{}")
        except (ValueError, TypeError):
            return {}

    def _curva_dia(self, nuevo=None):
        """Bonos y zonas ya avisados hoy. Vive en la base: un reinicio a
        mitad de rueda no tiene que volver a avisar lo mismo."""
        import json
        try:
            if nuevo is not None:
                db.set_estado("curva_dia", json.dumps(nuevo))
                return nuevo
            d = json.loads(db.get_estado("curva_dia") or "{}")
            return d if isinstance(d, dict) else {}
        except Exception as e:
            log.debug("curva del dia: %s", e)
            return nuevo or {}

    def _guardar_zonas_curva(self):
        import json
        try:
            db.set_estado("zonas_curva", json.dumps(self._zonas_curva))
        except Exception as e:
            log.debug("zonas de curva: %s", e)

    def _cargar_canjes(self):
        """Canjes ya avisados, por especie que sale. Vive en la base: en
        memoria, cada reinicio volvia a avisar todo lo vigente."""
        import json
        try:
            d = json.loads(db.get_estado("canjes_avisado") or "{}")
            return d if isinstance(d, dict) else {}
        except (ValueError, TypeError):
            return {}

    def _guardar_canjes(self):
        import json
        try:
            db.set_estado("canjes_avisado", json.dumps(self._canjes_avisado))
        except Exception as e:
            log.debug("canjes avisados: %s", e)

    def _guardar_zonas(self):
        import json
        try:
            db.set_estado("zonas", json.dumps(self._zona_actual))
        except Exception as e:
            log.debug("no se pudo guardar el estado de zonas: %s", e)

    # -- helpers ------------------------------------------------------

    def _factor(self, par, num, den):
        """Normaliza pares con láminas distintas.

        Si el par declara 'factor', manda ese. Si no, se deduce de los
        nominales por lámina que informa la API, cuando ambos los traen.
        """
        f = par.get("factor")
        if f:
            try:
                return float(f)
            except (TypeError, ValueError):
                return 1.0
        ln, ld = num.get("lote") or 0, den.get("lote") or 0
        if ln and ld and ln != ld:
            return ld / ln
        return 1.0

    def par_por_alias(self, alias):
        for p in self.pares:
            if p["alias"] == alias:
                return p
        return None

    def _en_horario(self):
        """Si hay rueda ahora mismo, por calendario.

        Usa el calendario de rueda, no el de liquidacion: en un puente o
        el 6/11 BYMA negocia aunque no liquide. Sin esto, un feriado se
        trataba como dia habil y se le seguia pidiendo datos a IOL toda
        la jornada.
        """
        try:
            ini = datetime.strptime(self.cfg["market_open"], "%H:%M").time()
            fin = datetime.strptime(self.cfg["market_close"], "%H:%M").time()
        except ValueError:
            return True
        ahora = datetime.now()
        try:
            import calendario as CAL
            if not CAL.hay_rueda(ahora.date()):
                return False
        except Exception:
            if ahora.weekday() >= 5:
                return False
        return ini <= ahora.time() <= fin

    def horario(self):
        """("10:30", "17:00") de la configuracion, o None si no parsea."""
        try:
            ini = datetime.strptime(self.cfg["market_open"], "%H:%M")
            fin = datetime.strptime(self.cfg["market_close"], "%H:%M")
        except (KeyError, TypeError, ValueError):
            return None
        return ini.strftime("%H:%M"), fin.strftime("%H:%M")

    def segundos_desde_ciclo(self):
        if not self.ultimo_ciclo:
            return None
        return int((datetime.now() - self.ultimo_ciclo).total_seconds())

    # -- obtencion de precios ----------------------------------------

    @property
    def pares(self):
        """Se relee de la base cada pocos segundos: se editan en vivo."""
        ahora = datetime.now()
        if (self._pares_ts is None
                or (ahora - self._pares_ts).total_seconds() > 5):
            try:
                self._pares_cache = db.pares_guardados()
                self._pares_ts = ahora
            except Exception as e:
                log.debug("pares: %s", e)
        return self._pares_cache

    def simbolos_necesarios(self):
        """Todo lo que el ciclo tiene que traer.

        Incluye las especies con cronograma: antes las pedian las
        pestanias de Bonos y Rulo al abrirlas, asi que el mismo dato se
        bajaba una y otra vez. Pidiendolo una vez por ciclo, navegar no
        consume nada.
        """
        s = set()
        for p in self.pares:
            s.add(p["num"])
            s.add(p["den"])
        for t in self.cfg.get("arbitraje_tickers") or []:
            s.add((t.get("ticker") or "").upper())
        try:
            import bonos as BO
            s |= set(BO.especies())
        except Exception as e:
            log.debug("especies de bonos: %s", e)
        # los simbolos de las alertas de precio: sin cotizacion no hay
        # forma de evaluarlas
        try:
            for a in db.alertas_precio(solo_activas=True):
                for c in a.get("condiciones") or []:
                    s.add(c["simbolo"])
        except Exception as e:
            log.debug("simbolos de alertas: %s", e)
        s.discard("")
        return s


    def cotizaciones_del_ciclo(self):
        """Un request por instrumento, y nada mas.

        Antes eran cinco paneles mas un pedido suelto por cada especie
        que no estuviera en ninguno. Orleans cubre mas y trae puntas, asi
        que lo que falte es porque no cotiza: se avisa en pantalla en vez
        de pedirlo de a uno sin que se note.
        """
        mapa = self.bajar_orleans()
        for sim in mapa:
            self.origen[sim] = "orleans"
        self.sin_cotizacion = sorted(self.simbolos_necesarios() - set(mapa))
        if self.sin_cotizacion:
            log.info("sin cotizacion: %s", ", ".join(self.sin_cotizacion))
        return self.rellenar_puntas(mapa)

    def repuesto_por_especie(self):
        """Pide especie por especie cuando el panel entero falla.

        Avanza hasta que la API contesta 429 y retoma en el ciclo
        siguiente desde donde quedo: el limite real lo pone la API y no
        un numero adivinado. Los pares van primero, que son los que
        generan senal de Rulo y no toleran precios viejos; la cartera
        despues, rotando.

        Es un respaldo, no un reemplazo: con la lista rotando, el
        screening trabaja con datos desparejos y algunas senales van a
        ser peores. Sirve para seguir viendo la cartera y los pares
        mientras Orleans este caido.
        """
        pares, cartera = [], []
        for p in db.pares_guardados():
            for s in (p.get("num"), p.get("den")):
                s = (s or "").strip().upper()
                if s and s not in pares:
                    pares.append(s)
        for t in db.tenencias():
            s = t["simbolo"]
            if (t.get("tipo") or "") != "moneda" and s not in pares \
                    and s not in cartera:
                cartera.append(s)
        lista = pares + cartera
        if not lista:
            return 0

        # El cursor solo recorre la cartera: los pares se piden siempre.
        pedidos, nuevos, frenado = 0, 0, False
        orden = pares + cartera[self._cursor_especie:] + \
            cartera[:self._cursor_especie]
        for sim in orden:
            try:
                cot = self.iol.cotizacion("bCBA", sim, "t1")
            except IOLError as e:
                if e.status == 429:
                    frenado = True
                    break
                continue
            finally:
                pedidos += 1
            if cot:
                with self.lock:
                    self.cotizaciones[sim] = cot
                    self.origen[sim] = "especie"
                nuevos += 1
                self.fuente = "especie"
        if cartera:
            avance = max(0, pedidos - len(pares))
            self._cursor_especie = (self._cursor_especie + avance) % len(cartera)
        log.info("respaldo por especie: %d precios%s", nuevos,
                 ", frenado por 429" if frenado else "")
        return nuevos

    # -- panel orleans ------------------------------------------------

    # Un instrumento por request, con puntas. Reemplaza a los paneles
    # viejos y a los pedidos sueltos.
    INSTRUMENTOS = ("titulosPublicos", "letras", "obligacionesNegociables",
                    "acciones", "cedears", "opciones", "cauciones")

    def instrumentos_orleans(self):
        txt = self.cfg.get("instrumentos_orleans")
        if txt is None:
            return list(self.INSTRUMENTOS)
        return [i.strip() for i in str(txt).split(",") if i.strip()]

    def _vencido(self, fecha_txt, dias_habiles):
        """True si la ultima operacion es demasiado vieja.

        La API deja pasar especies muertas aunque se le pida Operables:
        una letra vencida en abril seguia apareciendo. Se descartan por
        fecha de ultima operacion, que es lo unico confiable.
        """
        if not dias_habiles:
            return False
        try:
            f = date.fromisoformat(str(fecha_txt)[:10])
        except Exception:
            return True         # sin fecha no se puede confiar
        import calendario as CAL
        habiles, d = 0, date.today()
        while d > f and habiles <= dias_habiles:
            d -= timedelta(days=1)
            if CAL.hay_rueda(d):
                habiles += 1
        return habiles > dias_habiles

    def fuente_elegida(self):
        """auto, iol o byma. Se puede cambiar sin reiniciar."""
        f = getattr(self, "_fuente_forzada", None)
        if f:
            return f
        v = (self.cfg.get("fuente_precios") or "auto").strip().lower()
        return v if v in ("auto", "iol", "byma") else "auto"

    def bajar_orleans(self):
        """Todos los instrumentos configurados. Devuelve simbolo -> cotizacion."""
        from iol import normalizar
        # Forzar BYMA sirve para cuando Orleans responde pero con datos
        # malos: como no falla, el respaldo automatico no se dispara.
        if self.fuente_elegida() == "byma":
            try:
                m = self.bajar_byma()
                if m:
                    return m
            except Exception as e:
                log.warning("byma forzado: %s", e)
        mapa, planos, total, fallas = {}, 0, 0, []
        self._viejas = {}
        dias = self.cfg.get("dias_sin_operar")
        dias = 7 if dias is None else int(dias)
        descartados = []

        for inst in self.instrumentos_orleans():
            try:
                d = self.iol.panel_orleans(inst)
            except IOLError as e:
                log.warning("panel orleans %s: %s", inst, e)
                fallas.append(inst)
                continue
            titulos = (d or {}).get("titulos") or []
            if inst == "opciones":
                # se guardan crudos: el modulo de opciones los necesita
                # con la descripcion y el strike, que normalizar descarta
                self._orleans_opciones = titulos
            for t in titulos:
                sim = str((t or {}).get("simbolo") or "").strip().upper()
                if not sim:
                    continue
                vieja = self._vencido(t.get("fecha"), dias)
                c = normalizar(t, sim)
                if vieja:
                    # No se tira: descartar para operar no es lo mismo
                    # que descartar para valuar. Una ON que no opera hace
                    # diez dias no sirve para una señal, pero su ultimo
                    # precio vale mucho mas que no valuarla.
                    descartados.append(sim)
                    c["vieja"] = True
                    c["ultima_operacion"] = str(t.get("fecha") or "")[:10]
                    self._viejas[sim] = c
                    continue
                c["instrumento"] = inst
                c["descripcion"] = t.get("descripcion") or ""
                c["plazo_panel"] = t.get("plazo")
                c["lote"] = t.get("lote")
                total += 1
                if not (c.get("compra") or c.get("venta")):
                    planos += 1
                mapa[sim] = c
        # Los fondos van aparte: no estan en ningun panel y no tienen
        # puntas. Solo se piden si hay alguno en la tenencia.
        try:
            mapa.update(self._bajar_fci())
        except Exception as e:
            log.debug("fci: %s", e)
        if total:
            self.hay_rueda = planos < total
        self.orleans_fallas = fallas
        self.orleans_descartados = sorted(set(descartados))
        # Si no vino ni un precio, el panel esta caido. Primero BYMA, que
        # trae paneles enteros en una llamada y no gasta cupo de IOL;
        # recien si eso tampoco anda, especie por especie.
        if not mapa and fallas:
            # Solo BYMA: trae todo en una llamada y no gasta cupo de IOL.
            # El pedido especie por especie queda a mano, desde el menu,
            # porque consume el cupo de la cuenta que hace el ciclo y
            # para valuar no hace falta.
            if self.fuente_elegida() != "iol":
                try:
                    mapa = self.bajar_byma()
                except Exception as e:
                    log.warning("byma: %s", e)
                    self.byma_fallas = [str(e)]
            if not mapa:
                # Sin esto quedaba "iol" del ciclo anterior y la pantalla
                # decia que la fuente andaba cuando no habia precios.
                self.fuente = "ninguna"
        else:
            self.fuente = "iol"
        return mapa

    def _bajar_fci(self):
        """Cuotapartes de los fondos que tengas, por simbolo.

        Un FCI existe como tipo de tenencia y no cotiza en ningun panel:
        hasta ahora quedaba sin precio y su posicion no entraba en el
        total de la cartera.
        """
        from iol import normalizar_fci
        fondos = [t for t in db.tenencias()
                  if (t.get("tipo") or "").lower() == "fci"]
        if not fondos:
            return {}
        # Una vez por dia: la cuotaparte se publica una sola vez y pedirla
        # cada ciclo gasta cupo para el mismo numero.
        hoy = date.today().isoformat()
        if self._fci_dia == hoy:
            return dict(self._fci_cache)

        out = {}
        quiero = {t["simbolo"] for t in fondos}
        try:
            for f in (self.iol.fci() or []):
                c = normalizar_fci(f)
                if c and c["simbolo"] in quiero:
                    out[c["simbolo"]] = c
        except Exception as e:
            log.debug("fci de iol: %s", e)

        # Los que IOL no comercializa no estan en su listado. Para esos,
        # el nombre del fondo en CAFCI, que se carga a mano una vez.
        faltan = [t for t in fondos
                  if t["simbolo"] not in out and t.get("fci_nombre")]
        if faltan:
            import cafci
            catalogo = cafci.bajar()
            for t in faltan:
                c = cafci.cotizacion(catalogo.get(
                    (t["fci_nombre"] or "").strip().lower()), hoy)
                if c:
                    c["simbolo"] = t["simbolo"]
                    out[t["simbolo"]] = c

        self._fci_dia, self._fci_cache = hoy, dict(out)
        return out

    def bajar_byma(self):
        """Paneles de Open BYMA Data, con veinte minutos de retraso.

        Alcanza para valuar y para la curva, que necesita todos los bonos
        de la misma tanda. No para un rulo: veinte minutos es una
        eternidad para un ratio.
        """
        import byma as BY
        por_plazo, fallas = BY.mapa(
            [i for i in self.instrumentos_orleans() if i in BY.PANELES],
            verificar_ssl=bool(self.cfg.get("byma_verificar_ssl")))
        principal = self.cfg.get("byma_plazo") or "t1"
        cot = por_plazo.get(principal) or {}
        if not cot:
            self.byma_fallas = fallas
            return {}
        # El contado inmediato viene en la misma respuesta: la pantalla
        # de plazos lo necesita y asi no hay que pedirlo aparte.
        self.cot_t0 = por_plazo.get("t0") or {}
        with self.lock:
            for sim, c in cot.items():
                self.cotizaciones[sim] = c
                self.origen[sim] = "byma"
            mapa = dict(self.cotizaciones)
        self.fuente = "byma"
        self.byma_fallas = fallas
        log.info("byma: %d precios en %s, %d en t0%s", len(cot), principal,
                 len(self.cot_t0),
                 " (%d paneles fallaron)" % len(fallas) if fallas else "")
        return mapa

    def tasa_caucion(self, mapa=None):
        """Tasa colocadora del dia, de la punta compradora.

        Reemplaza al numero fijo de la configuracion cuando hay dato en
        vivo; si no lo hay, se usa el configurado.
        """
        mapa = mapa if mapa is not None else self.cotizaciones
        for sim, c in mapa.items():
            if c.get("instrumento") != "cauciones":
                continue
            # la de pesos: el simbolo es descriptivo, no un ticker
            texto = ("%s %s" % (sim, c.get("descripcion") or "")).lower()
            if "peso" in texto and c.get("compra"):
                return float(c["compra"]), "mercado"
        return float(self.cfg.get("tasa_caucion_anual") or 0), "configurada"


    # -- ultima punta conocida ----------------------------------------

    def _cargar_puntas(self):
        try:
            return db.puntas()
        except Exception:
            return {}

    def rellenar_puntas(self, mapa):
        """Conserva la ultima punta valida de cada simbolo.

        Fuera de rueda IOL manda el ultimo precio pero no las puntas, y
        sin puntas no se puede valuar nada. Se guarda la ultima buena por
        simbolo, no por ciclo: las especies iliquidas pierden punta
        mucho antes del cierre, asi que un unico snapshot del ultimo
        ciclo "bueno" dejaria a las liquidas al dia y a las demas con
        datos de horas antes sin que se note.

        Lo que se rellena queda marcado como viejo. Ningun modulo debe
        alertar sobre esto.
        """
        guardadas = self._cargar_puntas()
        ahora = datetime.now().isoformat(timespec="seconds")
        cambios = {}
        # Fuera de rueda las puntas que manda IOL son ordenes sueltas: el
        # 28/09 a las 22:18 AL30D tenia 47,99 / 54,50 y el MEP salio 1.632.
        # No se guardan ni se usan; se sigue con la ultima de la rueda.
        en_rueda = self._en_horario()

        for sim, c in mapa.items():
            guardado = guardadas.get(sim) or {}
            if en_rueda and c.get("compra") and c.get("venta"):
                guardadas[sim] = {
                    "compra": c["compra"], "venta": c["venta"],
                    "vol_compra": c.get("vol_compra") or 0,
                    "vol_venta": c.get("vol_venta") or 0,
                    "ultimo": c.get("ultimo") or guardado.get("ultimo") or 0,
                    "moneda": c.get("moneda") or guardado.get("moneda") or "",
                    "ts": ahora}
                c["punta_vieja"] = False
                c["punta_ts"] = ahora
                cambios[sim] = guardadas[sim]
                continue

            # Sin puntas igual se guarda el ultimo operado: hay especies
            # que cierran sin punta y solo con ultimo, y si no se guardan
            # desaparecen de la tabla en vez de mostrarse atenuadas.
            if c.get("ultimo"):
                g = dict(guardado)
                g.update({"ultimo": c["ultimo"], "ts_ultimo": ahora,
                          "moneda": c.get("moneda") or g.get("moneda") or ""})
                guardadas[sim] = g
                cambios[sim] = g

            if not guardado.get("compra"):
                c["punta_vieja"] = False    # nunca hubo, no hay que marcar
                continue
            c["compra"] = guardado["compra"]
            c["venta"] = guardado["venta"]
            c["vol_compra"] = guardado.get("vol_compra") or 0
            c["vol_venta"] = guardado.get("vol_venta") or 0
            c["medio"] = (c["compra"] + c["venta"]) / 2
            c["ref"] = c["medio"] or c.get("ultimo") or 0
            c["punta_vieja"] = True
            c["punta_ts"] = guardado.get("ts")

        if cambios:
            db.guardar_puntas(cambios)
        return mapa

    def mapa_guardado(self):
        """Cotizaciones armadas con la ultima punta conocida de cada
        simbolo. Sirve para responder con la rueda cerrada sin tocar la
        API: los datos ya los tenemos, pedirlos de nuevo no cambia nada
        y consume cupo."""
        out = {}
        for sim, v in self._cargar_puntas().items():
            compra = v.get("compra") or 0
            venta = v.get("venta") or 0
            ultimo = v.get("ultimo") or 0
            medio = (compra + venta) / 2 if compra and venta else 0
            if not (medio or ultimo):
                continue
            out[sim] = {"simbolo": sim, "compra": compra, "venta": venta,
                        "vol_compra": v.get("vol_compra") or 0,
                        "vol_venta": v.get("vol_venta") or 0,
                        "medio": medio, "ref": medio or ultimo,
                        "ultimo": ultimo or medio,
                        "moneda": v.get("moneda") or "",
                        "punta_vieja": bool(medio),
                        "punta_ts": v.get("ts")}
        return out

    def cotizaciones_vigentes(self):
        """Lo que hay que mostrar ahora: en rueda, lo del ciclo; fuera,
        lo ultimo guardado. Nunca dispara un request."""
        with self.lock:
            mapa = dict(self.cotizaciones)
        if mapa:
            return mapa
        return self.mapa_guardado()

    def cotizaciones_para_valuar(self):
        """Las vigentes mas las que no operan hace dias, marcadas.

        Para una señal -un ratio, un canje, un rulo- una punta suelta de
        hace una semana es ruido y queda afuera. Para valuar la cartera
        es lo contrario: sin ese precio la posicion no aparece y el total
        miente mas que el precio viejo. Las viejas vienen con `vieja` y
        con la fecha de su ultima operacion, para que se pueda avisar.
        """
        mapa = dict(self.cotizaciones_vigentes())
        for sim, c in (getattr(self, "_viejas", None) or {}).items():
            mapa.setdefault(sim, c)
        return mapa



    def estadistica(self, par):
        """Prefiere nuestras propias lecturas; el historico de IOL es respaldo."""
        desde = (datetime.now().date() - timedelta(days=VENTANA_DIAS)).isoformat()
        hoy = date.today().isoformat()

        def con_ayer(st, serie):
            # El cierre de la rueda anterior, para la variacion del dia.
            prev = [v for f, v in serie if f < hoy]
            st["ayer"] = prev[-1] if prev else None
            return st

        if par.get("modo") == "tir":
            # La historia diaria ya esta en bono_hist: el par arranca con
            # la ventana completa, sin esperar lecturas propias.
            serie = db.serie_tir_diaria(par["num"], par["den"], desde)
            return con_ayer(_stats([v for _, v in serie], "bono_hist"), serie)
        propia = db.serie_propia_diaria(par["alias"], desde, self.horario())
        if len(propia) >= MIN_MUESTRA_PROPIA:
            return con_ayer(_stats([v for _, v in propia], "propia"), propia)

        serie = db.serie_ratio_diaria(par["num"], par["den"], desde)
        st = con_ayer(_stats([v for _, v in serie], "iol"), serie)
        st["aviso"] = ("El histórico viene de IOL y puede mezclar plazos. "
                       "Se reemplaza solo cuando junte %d días propios."
                       % MIN_MUESTRA_PROPIA)
        return st

    # -- zonas y alertas ---------------------------------------------

    def _zona(self, par, ratio, est):
        """Zona con histeresis: salir cuesta mas que entrar."""
        res = par.get("resistencia") or 0
        sop = par.get("soporte") or 0
        margen = float(self.cfg.get("histeresis_pct", 0.5)) / 100.0
        actual = self._zona_actual.get(par["alias"], "normal")

        if par.get("modo") == "tir" and (res or sop):
            # En pb el margen es una suma: un nivel puede ser cero o
            # negativo y el porcentaje no tiene sentido.
            m = MARGEN_TIR_PB
            if actual == "alta" and res and ratio >= res - m:
                return "alta", res
            if actual == "baja" and sop and ratio <= sop + m:
                return "baja", sop
            if res and ratio >= res:
                return "alta", res
            if sop and ratio <= sop:
                return "baja", sop
            return "normal", None

        if res > 0 or sop > 0:
            if actual == "alta":
                # sigue en alta hasta que baje del nivel menos el margen
                if res and ratio >= res * (1 - margen):
                    return "alta", res
            elif actual == "baja":
                if sop and ratio <= sop * (1 + margen):
                    return "baja", sop
            if res > 0 and ratio >= res:
                return "alta", res
            if sop > 0 and ratio <= sop:
                return "baja", sop
            return "normal", None

        # sin niveles: z-score
        if est.get("n", 0) >= MIN_MUESTRA_Z and est.get("desvio"):
            z = (ratio - est["media"]) / est["desvio"]
            umbral = 2.0 if actual == "normal" else 1.6
            if z >= umbral:
                return "alta", est["media"] + 2 * est["desvio"]
            if z <= -umbral:
                return "baja", est["media"] - 2 * est["desvio"]
        return "normal", None

    def _mensaje(self, par, ratio, zona, nivel, est, num, den, tir=None):
        icono = "🔴" if zona == "alta" else "🟢"
        que = "tocó resistencia" if zona == "alta" else "tocó soporte"
        if tir:
            L = ["%s <b>%s</b> %s" % (icono, par["alias"], que),
                 "Diferencial <b>%+.0f pb</b>  (nivel %+.0f)" % (ratio, nivel or 0),
                 "TIR %s %.2f%% · %s %.2f%%" % (par["num"], tir["tir_num"],
                                                par["den"], tir["tir_den"]),
                 ""]
            if tir.get("aviso"):
                L += ["⚠ " + tir["aviso"], ""]
            if est.get("n", 0) >= MIN_MUESTRA_Z and est.get("desvio"):
                z = (ratio - est["media"]) / est["desvio"]
                L += ["Media: %+.0f pb   z: %+.2f" % (est["media"], z), ""]
            ten = self._tenencia_del_par(par, num["ref"] / den["ref"])
            if ten:
                L += ten + [""]
            L += ["<i>%s</i>" % datetime.now().strftime("%H:%M:%S")]
            return "\n".join(L)
        L = [
            "%s <b>%s</b> %s" % (icono, par["alias"], que),
            "Ratio <b>%.4f</b>  (nivel %.4f)" % (ratio, nivel or 0),
            "",
        ]
        for etq, sim, c in (("", par["num"], num), ("", par["den"], den)):
            linea = "%s: %s" % (sim, _n(c["ref"]))
            if c["compra"] or c["venta"]:
                linea += "   %s / %s" % (_n(c["compra"]), _n(c["venta"]))
            if c.get("vol_compra") or c.get("vol_venta"):
                linea += "   [%s / %s]" % (
                    _e(c.get("vol_compra")), _e(c.get("vol_venta")))
            L.append(linea)

        if est.get("n", 0) >= MIN_MUESTRA_Z and est.get("desvio"):
            z = (ratio - est["media"]) / est["desvio"]
            L += ["",
                  "Media: %.4f   z: %+.2f" % (est["media"], z),
                  "Rango: %.4f – %.4f  (n=%d, %s)" % (
                      est["min"], est["max"], est["n"], est.get("fuente", ""))]
        ten = self._tenencia_del_par(par, ratio)
        if ten:
            L += [""] + ten
        L += ["", "<i>%s</i>" % datetime.now().strftime("%H:%M:%S")]
        return "\n".join(L)

    def _tenencia_del_par(self, par, ratio):
        """Cuanto tenes de cada punta y cuanto obtendrias si rotas.

        El saldo sale de `tenencia`, sumando los brokers. Antes salia de
        los movimientos cargados del grupo, que quedaban viejos en cuanto
        se operaba sin registrarlo.
        """
        try:
            saldos = {}
            for t in db.tenencias():
                if t["simbolo"] in (par["num"], par["den"]):
                    saldos[t["simbolo"]] = (saldos.get(t["simbolo"], 0)
                                            + (t["cantidad"] or 0))
            lineas = []
            cn = saldos.get(par["num"], 0)
            cd = saldos.get(par["den"], 0)
            if cn > 0:
                lineas.append("Tenés %s %s → %s %s si rotás"
                              % (_e(cn), par["num"],
                                 _e(cn * ratio), par["den"]))
            if cd > 0:
                lineas.append("Tenés %s %s → %s %s si rotás"
                              % (_e(cd), par["den"],
                                 _e(cd / ratio if ratio else 0), par["num"]))
            return lineas
        except Exception as e:
            log.debug("tenencia en alerta: %s", e)
        return []

    # -- evaluacion ---------------------------------------------------

    def evaluar_par(self, par, mapa, registrar=True):
        """Ratio, zona y estado de la tarjeta de un par.

        Con `registrar=False` no deja rastro: no guarda la lectura, no
        mueve la zona recordada, no alerta ni publica el sensor. Es para
        dibujar la tarjeta de un par recien creado o editado con precios
        que pueden ser del ultimo cierre; si movia la zona, el primer
        ciclo real ya no avisaba al entrar.
        """
        num = mapa.get(par["num"])
        den = mapa.get(par["den"])
        if not num or not den or not num["ref"] or not den["ref"]:
            raise IOLError("sin precio para %s o %s" % (par["num"], par["den"]))

        tir = None
        if par.get("modo") == "tir":
            tir = self._tir_del_par(par, mapa)
            ratio = tir["valor"]
        else:
            ratio = num["ref"] / den["ref"] * self._factor(par, num, den)
        est = self.estadistica(par)
        previa = self._zona_actual.get(par["alias"], "normal")
        zona, nivel = self._zona(par, ratio, est)
        if registrar and zona != previa:
            self._zona_actual[par["alias"]] = zona
            self._guardar_zonas()

        if registrar:
            db.guardar_lectura(par["alias"], ratio, num, den)

        z = None
        if est.get("n", 0) >= MIN_MUESTRA_Z and est.get("desvio"):
            z = (ratio - est["media"]) / est["desvio"]

        alerta_id = None
        # con punta repuesta de antes del cierre el ratio no es ejecutable
        viejas = any((mapa.get(par[lado]) or {}).get("punta_vieja")
                     for lado in ("num", "den"))
        # avisa solo al ENTRAR en zona, no mientras se queda
        if registrar and par.get("alertas") and zona != "normal" \
                and previa != zona and not viejas:
            msg = self._mensaje(par, ratio, zona, nivel, est, num, den, tir)
            alerta_id = db.registrar_alerta(
                par["alias"], zona, ratio, nivel, msg, num, den)
            import senales as SE
            SE.registrar("par", par["alias"], direccion=zona, z=z,
                         valor0=ratio)
            self.notif.enviar(
                "%s %s" % (par["alias"], "▲" if zona == "alta" else "▼"),
                msg, urgente=True)
            log.info("alerta %s %s @ %.4f", par["alias"], zona, ratio)

        estado = {
            # El id del grupo: la tarjeta lo usa para encontrar la
            # estrategia del par y para el boton de editar, que antes lo
            # sacaba de la posicion que ya no viaja en /api/estado.
            "id": par.get("id"),
            "alias": par["alias"], "num": par["num"], "den": par["den"],
            "cerca": _cerca_del_borde(par, ratio, est),
            "factor": self._factor(par, num, den),
            "ratio": ratio, "zona": zona, "zona_previa": previa,
            "resistencia": par.get("resistencia") or 0,
            "soporte": par.get("soporte") or 0,
            "z": z, "est": est, "p_num": num, "p_den": den,
            "modo": par.get("modo") or "precio", "tir": tir,
            "ts": datetime.now().isoformat(timespec="seconds"),
            "alertas": bool(par.get("alertas")),
            "alerta_id": alerta_id,
            "origen": self.origen.get(par["num"], "?"),
            "error": None,
        }

        if tir and z is not None and est.get("media") is not None:
            # Lo que se gana si el diferencial vuelve a su media, en % del
            # capital: duration por el movimiento de tasa.
            md = tir.get("md_num") if ratio >= est["media"] else tir.get("md_den")
            if md:
                estado["recorrido_pct"] = md * abs(ratio - est["media"]) / 100.0
        if registrar and self.cfg.get("publicar_sensores"):
            self.notif.publicar_sensor(par["alias"], ratio, {
                "friendly_name": "Ratio " + par["alias"],
                "zona": zona,
                "resistencia": par.get("resistencia") or 0,
                "soporte": par.get("soporte") or 0,
                "z_score": round(z, 3) if z is not None else None,
                "numerador": par["num"], "denominador": par["den"],
                "precio_numerador": num["ref"], "precio_denominador": den["ref"],
                "unit_of_measurement": "pb" if tir else "ratio",
                "icon": "mdi:swap-horizontal",
            })
        return estado

    def _tir_del_par(self, par, mapa):
        """TIR de las dos puntas con los precios del ciclo.

        La tabla de BONOS se calcula una vez por mapa de cotizaciones: un
        ciclo con varios pares por TIR no la repite. Con un bono a menos
        de `MIN_DIAS_TIR` dias del vencimiento se sigue calculando, con un
        aviso: anualizar pocos dias de precio exagera la TIR.
        """
        import bonos as BO
        cache = getattr(self, "_tir_cache", None)
        if not cache or cache[0] is not mapa:
            filas = {}
            try:
                cer_act = float(self.cfg.get("cer_actual") or 0)
                for f in (BO.tabla(mapa, cer_actual=cer_act) or {}).get("filas") or []:
                    filas[f["simbolo"]] = f
            except Exception as e:
                log.debug("tabla para pares por TIR: %s", e)
            cache = self._tir_cache = (mapa, filas)
        fn, fd = cache[1].get(par["num"]), cache[1].get(par["den"])
        cortos = []
        for sim, f in ((par["num"], fn), (par["den"], fd)):
            if not f or f.get("tir_last") is None:
                raise IOLError("sin TIR para %s" % sim)
            try:
                dias = (date.fromisoformat(f["vencimiento"]) - date.today()).days
            except (KeyError, TypeError, ValueError):
                dias = None
            if dias is not None and dias < MIN_DIAS_TIR:
                cortos.append("%s vence en %d días" % (sim, dias))
        # Se sigue calculando: el aviso queda en la tarjeta y en el mensaje.
        aviso = ("%s: cerca del vencimiento la TIR anualiza pocos días de "
                 "precio y el diferencial exagera." % " y ".join(cortos)) \
            if cortos else None
        return {"tir_num": fn["tir_last"], "tir_den": fd["tir_last"],
                "md_num": fn.get("md"), "md_den": fd.get("md"),
                "valor": (fd["tir_last"] - fn["tir_last"]) * 100.0,
                "familias": [fn.get("familia"), fd.get("familia")],
                "aviso": aviso}

    def _min_monto(self):
        """Plata minima que tiene que haber en una punta para creerle.

        Cero apaga el filtro. En pesos: las especies en dolares se pasan
        por el MEP antes de comparar.
        """
        try:
            return float(self.cfg.get("monto_min_punta") or 0)
        except (TypeError, ValueError):
            return 0.0

    def _mep(self, cot):
        """MEP del ciclo, para llevar a pesos las puntas en dolares."""
        import bonos as BO
        try:
            return (BO.calcular_mep(cot).get("medio") or 0) or None
        except Exception:
            return None

    def canjes_curva(self, cot=None):
        """Los canjes que convienen hoy sobre lo que se tiene.

        Se calcula aparte de revisar_curva porque responde otra cosa: no
        que bono se despego, sino contra cual conviene rotar el que ya
        esta en cartera para terminar con mas nominales.
        """
        import bonos as BO
        import curva as CU
        import costos as CO_COSTOS

        with self.lock:
            cot = cot or dict(self.cotizaciones)
        if not cot:
            return []
        tenidos = {t["simbolo"] for t in db.tenencias()
                   if (t.get("tipo") or "") in ("bonos", "letras", "on")}
        if not tenidos:
            return []
        t = BO.tabla(cot, cer_actual=float(self.cfg.get("cer_actual") or 0))
        an = CU.analizar(t["filas"])
        mep = self._mep(cot)
        # Ida y vuelta: se vende una especie y se compra otra. `pct`
        # devuelve tanto por uno y canjes() trabaja en puntos
        # porcentuales, igual que el recorrido de cada punta: sin el x100
        # el costo entraba como 0,003 en vez de 0,32 y todos los canjes
        # salian sobreestimados en su propia comision.
        una = CO_COSTOS.pct(self.cfg.get("comisiones") or {}, "bonos",
                            self.cfg.get("derechos_mercado"),
                            self.cfg.get("iva_pct") or 0)
        dz = self.cfg.get("canje_min_dz")
        return CU.canjes(
            t["filas"], an, tenidos, costo_pct=una * 2 * 100,
            min_ganancia=float(self.cfg.get("canje_min_pct") or 1.0),
            min_monto=self._min_monto(), mep=mep,
            # Campo nuevo en 0.53.0: sin cargar vale 1. Cero se respeta.
            min_dz=1.0 if dz in (None, "") else float(dz))

    def _orden_rotacion(self, sale, entra, cot):
        """"1.000 AO29 → 1.068 AO28D": toda la tenencia, al bid y al ask,
        con comisiones. Sale del mismo modulo que la tarjeta de canje;
        si no se puede armar la orden, el aviso va sin esta linea."""
        import rotacion as RO
        try:
            r = RO.calcular(sale, entra, None, cot or dict(self.cotizaciones),
                            db.tenencias(), self.cfg.get("comisiones") or {},
                            self.cfg.get("derechos_mercado") or {},
                            self.cfg.get("iva_pct") or 0, mep=self._mep(cot))
        except Exception as e:
            log.debug("orden de rotacion: %s", e)
            return ""
        if r.get("error"):
            return ""
        f = lambda v: ("{:,.0f}".format(v)).replace(",", ".")
        return "%s %s → %s %s" % (f(r["cantidad_sale"]), sale,
                                  f(r["cantidad_entra"]), entra)

    def oportunidades(self):
        """Lo que esta vigente ahora, en un solo lugar y por prioridad.

        1. Sobre lo que ya tenes: canjes, pares donde estas del lado que
           no conviene, bonos tuyos caros contra su curva.
        2. Sin tenencia: bonos baratos, pares sin posicion.
        3. Informativas: bonos caros que no tenes.

        Dentro de cada prioridad, por lo que se espera ganar (canje y
        curva, en %) o por |z| (pares). `desde` es el ultimo aviso de esa
        señal: con la persistencia y la histeresis, es cuando entro.
        """
        saldos = saldos_tenencia()
        tenidos = {k for k, v in saldos.items() if v}
        with self.lock:
            canjes = list(getattr(self, "canjes", []) or [])
            curva = dict(getattr(self, "curva_vigentes", {}) or {})
            pares = list(self.snapshot.values())
            opc = list(getattr(self, "opc_vigentes", []) or [])
        c = db.conn()

        def desde(alias, tipo):
            r = c.execute("SELECT MAX(ts) t FROM alertas WHERE alias=? AND "
                          "tipo=?", (alias, tipo)).fetchone()
            return r["t"] if r else None

        out = []
        # Stop y objetivo de Gestion que siguen tocados: primero de todo.
        # El aviso sale una sola vez al tocarse; si no se lo vio, el
        # resumen de las 12 y las 16:30 lo vuelve a poner adelante.
        try:
            import gestion as GE
            niv = GE.config()["niveles"]
            for sim, que in sorted(GE.tocados().items()):
                n = niv.get(sim) or {}
                modo = n.get("modo") or "precio"
                nivel = n.get("stop") if que == "stop" else n.get("obj")
                fn = (lambda v: "%.2f%% de TIR" % v) if modo == "tir" else \
                    (lambda v: "US$ %s en NY" % _n(v)) if modo == "ny" else _n
                out.append({
                    "tipo": "nivel", "prioridad": 1, "clave": sim,
                    "titulo": "%s %s %s" % ("🛑" if que == "stop" else "🎯", sim,
                                            "en el stop" if que == "stop" else "en el objetivo"),
                    "detalle": ("nivel %s · " % fn(nivel) if nivel is not None else "") +
                               "cargado en Gestión",
                    # arriba de todo dentro de la prioridad 1
                    "valor": 1e9 if que == "stop" else 1e8,
                    "desde": desde(sim, "nivel_" + que)})
        except Exception as e:
            log.debug("oportunidades, niveles: %s", e)
        for f in canjes:
            out.append({
                "tipo": "canje", "prioridad": 1,
                "clave": "%s>%s" % (f["desde"], f["hacia"]),
                "titulo": "Rotar %s → %s" % (f["desde"], f["hacia"]),
                "detalle": "%+.2f%% esperado · z %+.2f → %+.2f" % (
                    f["ganancia_pct"], f.get("z_desde") or 0,
                    f.get("z_hacia") or 0),
                "valor": f["ganancia_pct"], "desde": desde(f["desde"], "canje"),
                "sale": f["desde"], "entra": f["hacia"]})
        for sim, v in curva.items():
            barato = v["zona"] == "barato"
            tengo = sim in tenidos
            pr = 2 if barato else (1 if tengo else 3)
            out.append({
                "tipo": "curva", "prioridad": pr, "clave": sim,
                "titulo": "%s %s contra su curva%s" % (
                    sim, "barato" if barato else "caro",
                    " · lo tenés" if tengo else ""),
                "detalle": "desvío %+.0f pb · z %+.2f%s" % (
                    v["residuo"], v["z"],
                    (" · recorrido %.2f%%" % abs(v["recorrido"]))
                    if v.get("recorrido") is not None else ""),
                "valor": abs(v["recorrido"] or 0),
                "desde": desde(sim, "curva_" + v["zona"])})
        for p in pares:
            if p.get("zona") not in ("alta", "baja") or not p.get("num"):
                continue
            sg = sugerencia_par(p["num"], p["den"], p["zona"], {
                s_: saldos[s_] for s_ in (p["num"], p["den"]) if s_ in saldos})
            estar = sg.get("estar_en")
            otra = p["den"] if estar == p["num"] else p["num"]
            # En los pares de moneda la tenencia no dice la moneda: no se
            # cruza, igual que en la tarjeta.
            rotar = (not sg.get("moneda")) and bool(saldos.get(otra))
            posicionado = (not sg.get("moneda")) and bool(saldos.get(estar))
            out.append({
                "tipo": "par", "prioridad": 1 if rotar else 2,
                "clave": p["alias"],
                "titulo": "%s: estar en %s" % (p["alias"], estar),
                "detalle": "%s%s%s" % (
                    sg.get("lectura") or "",
                    (" · z %+.2f" % p["z"]) if p.get("z") is not None else "",
                    " · tenés %s → rotar" % otra if rotar else
                    " · posicionado" if posicionado else ""),
                "valor": abs(p.get("z") or 0),
                "desde": desde(p["alias"], p["zona"])})
        if opc:
            m = opc[0]
            out.append({
                "tipo": "opciones", "prioridad": 3, "clave": "opciones",
                "titulo": "Opciones: %d combinación%s bajo el umbral" % (
                    len(opc), "" if len(opc) == 1 else "es"),
                "detalle": "mejor %s %s/%s al %.1f%% de riesgo" % (
                    self.NOMBRE_ESTRUCTURA.get(m["estructura"],
                                               m["estructura"]),
                    _n(m.get("base_compra") or 0),
                    _n(m.get("base_venta") or 0),
                    m["riesgo_pct"]) if m.get("estructura") else "",
                "valor": -m["riesgo_pct"], "desde": None})
        out.sort(key=lambda o: (o["prioridad"], -(o["valor"] or 0)))
        return out

    def enviar_resumen(self, ahora=None):
        """El resumen de oportunidades a las horas de `resumen_horas`.

        Una vez por hora configurada y por dia, solo en dia de rueda. No
        reemplaza a los avisos en el momento: es la lista para quien no
        pudo mirar cuando llegaron.
        """
        import calendario as CAL
        ahora = ahora or datetime.now()
        horas = [h.strip() for h in str(self.cfg.get("resumen_horas") or "")
                 .replace(";", ",").split(",") if h.strip()]
        if not horas or not CAL.hay_rueda(ahora.date()):
            return False
        hhmm = ahora.strftime("%H:%M")
        toca = [h for h in horas if h <= hhmm]
        if not toca:
            return False
        marca = "%s %s" % (ahora.date().isoformat(), max(toca))
        if db.get_estado("resumen_enviado") == marca:
            return False
        db.set_estado("resumen_enviado", marca)
        ops = self.oportunidades()
        if not ops:
            return False
        lineas = []
        for pr, nombre in ((1, "Sobre lo que tenés"), (2, "Oportunidades"),
                           (3, "Para mirar")):
            grupo = [o for o in ops if o["prioridad"] == pr]
            if not grupo:
                continue
            lineas.append("<b>%s</b>" % nombre)
            for o in grupo[:8]:
                lineas.append("• %s — %s" % (o["titulo"], o["detalle"]))
            if len(grupo) > 8:
                lineas.append("  y %d más" % (len(grupo) - 8))
            lineas.append("")
        self.notif.enviar("Resumen %s · %d oportunidades" % (
            max(toca), len(ops)), "\n".join(lineas).strip(), urgente=False)
        return True

    def medir_senales(self, reconstruir=False):
        """Completa los resultados de las señales a 5, 20 y 60 ruedas.

        Con `reconstruir`, ademas arma las simuladas de curva y canje con
        la historia guardada y los parametros de hoy. Se hace sola la
        primera vez y despues de cada recalculo del historico.
        """
        import senales as SE
        try:
            if reconstruir or not db.get_estado("senales_simuladas"):
                import costos as CO_COSTOS
                una = CO_COSTOS.pct(self.cfg.get("comisiones") or {}, "bonos",
                                    self.cfg.get("derechos_mercado"),
                                    self.cfg.get("iva_pct") or 0)
                h = self.cfg.get("curva_histeresis_z")
                dz = self.cfg.get("canje_min_dz")
                n = SE.reconstruir(
                    umbral_z=float(self.cfg.get("curva_umbral_z") or 2.5),
                    histeresis=0.5 if h is None else float(h),
                    canje_min_pct=float(self.cfg.get("canje_min_pct") or 1.0),
                    canje_min_dz=1.0 if dz is None else float(dz),
                    costo_pct=una * 2 * 100)
                db.set_estado("senales_simuladas",
                              datetime.now().isoformat(timespec="seconds"))
                log.info("señales: %d simuladas", n)
            return SE.medir(self.horario())
        except Exception as e:
            log.warning("señales: %s", e)
            return 0

    def _canjes_nuevos(self, filas, hoy):
        """Los canjes que hay que avisar en este ciclo.

        **La clave es la especie que sale, no el par.** `curva.canjes`
        devuelve solo el mejor destino de cada tenencia; si el mejor
        alterna entre dos (DICP → TX31 y DICP → TZXM9), con la clave por
        par cada cambio era un canje "nuevo" y volvia a avisar.

        **Ausente no es afuera.** Un canje que se cae un ciclo porque la
        ganancia o el margen de z quedaron justo debajo del minimo no se
        rearma: se rearma recien cuando estuvo ausente una rueda entera,
        es decir, cuando no se lo vio ni hoy ni el habil anterior. El
        mismo bug que tenian las alertas de opciones hasta la 0.46.0:
        DICP → TX31 aviso 16 veces el 29/09/2026.
        """
        import calendario as CAL
        previo = self._canjes_avisado
        anterior = hoy - timedelta(days=1)
        while not CAL.hay_rueda(anterior):
            anterior -= timedelta(days=1)
        corte = anterior.isoformat()
        nuevos, estado = [], {}
        for f in filas:
            p = previo.get(f["desde"]) or {}
            if not p or (p.get("visto") or "") < corte:
                nuevos.append(f)
                p = {"avisado": hoy.isoformat()}
            estado[f["desde"]] = dict(p, hacia=f["hacia"],
                                      visto=hoy.isoformat())
        # Los ausentes se arrastran con su ultima fecha vista; se olvidan
        # a los 30 dias para que el estado no crezca sin fin.
        olvido = (hoy - timedelta(days=30)).isoformat()
        for desde, p in previo.items():
            if desde not in estado and (p.get("visto") or "") >= olvido:
                estado[desde] = p
        self._canjes_avisado = estado
        self._guardar_canjes()
        return nuevos

    def revisar_niveles(self, cot):
        """Stop y objetivo de cada especie, cargados en Gestion (pendiente 50).

        Avisa una vez al tocarse; se rearma recien cuando el precio (o la
        TIR) vuelve adentro del rango. Solo en rueda: fuera de horario
        nada es dato. El stop de la app es un aviso, no una orden.
        """
        import gestion as GE
        if getattr(self, "_silencio", False):
            return 0
        precios = {k: (v or {}).get("ref") for k, v in (cot or {}).items()}
        tir_md = {}
        fn = getattr(self, "tir_md_bonos", None)
        if fn and any(n.get("modo") == "tir" for n in GE.config()["niveles"].values()):
            tir_md = fn()
        n = 0
        for sim, que, nivel, actual, modo in GE.cruces(precios, tir_md):
            tir = modo == "tir"
            fmt = (lambda v: "%.2f%%" % v) if tir else \
                (lambda v: "US$ %s" % _n(v)) if modo == "ny" else (lambda v: _n(v))
            titulo = "%s %s: %s" % ("🛑" if que == "stop" else "🎯", sim,
                                    "tocó el stop" if que == "stop" else "llegó al objetivo")
            msg = "%s %s <b>%s</b> (nivel %s)\n\n<i>Cargado en Gestión. Es un aviso: " \
                  "si no hay orden en el broker, no se ejecuta nada.</i>" % (
                      "TIR" if tir else "Precio en NY de" if modo == "ny" else "Precio",
                      sim, fmt(actual), fmt(nivel))
            self.notif.enviar(titulo, msg)
            db.registrar_alerta(sim, "nivel_" + que, actual, nivel, msg)
            n += 1
        return n

    def revisar_canjes(self, cot=None):
        """Avisa cuando aparece un canje que antes no estaba."""
        if not float(self.cfg.get("canje_min_pct") or 0):
            return 0
        try:
            filas = self.canjes_curva(cot)
        except Exception as e:
            log.debug("canjes: %s", e)
            return 0
        with self.lock:
            self.canjes = filas
        if getattr(self, "_silencio", False):
            return 0
        nuevos = self._canjes_nuevos(filas, date.today())
        if not nuevos:
            return 0
        lineas, planas = [], []
        for f in nuevos:
            orden = self._orden_rotacion(f["desde"], f["hacia"], cot)
            lineas.append(
                "<b>%s → %s</b>: +%.2f%% neto<br>"
                "%s z %+.2f · MD %.2f · TIR %.2f%%<br>"
                "%s z %+.2f · MD %.2f · TIR %.2f%%%s" % (
                    f["desde"], f["hacia"], f["ganancia_pct"],
                    f["desde"], f["z_desde"] or 0, f["md_desde"],
                    f["tir_desde"] or 0,
                    f["hacia"], f["z_hacia"], f["md_hacia"],
                    f["tir_hacia"] or 0,
                    ("<br>" + orden) if orden else ""))
            # En el celular la notificacion se lee de un vistazo: una
            # linea por canje con lo que hace falta para decidir mirar.
            planas.append("%s → %s: +%.2f%% neto (z %+.2f → %+.2f)%s" % (
                f["desde"], f["hacia"], f["ganancia_pct"],
                f["z_desde"] or 0, f["z_hacia"],
                (" · " + orden) if orden else ""))
        titulo = ("Rotar %s → %s" % (nuevos[0]["desde"], nuevos[0]["hacia"])
                  if len(nuevos) == 1 else "%d rotaciones convenientes"
                  % len(nuevos))
        self.notif.enviar(titulo, "<br><br>".join(lineas), "\n".join(planas))
        texto = "<b>%s</b><br>%s" % (titulo, "<br><br>".join(lineas))
        for f in nuevos:
            db.registrar_alerta(f["desde"], "canje", f["ganancia_pct"], None,
                                texto)
            import senales as SE
            SE.registrar("canje", "%s>%s" % (f["desde"], f["hacia"]),
                         sale=f["desde"], entra=f["hacia"],
                         z=f.get("z_hacia"), dz=f.get("dz"),
                         esperado=f.get("ganancia_pct"),
                         costo=f.get("costo_pct"),
                         md_sale=f.get("md_desde"), md_entra=f.get("md_hacia"),
                         r_sale=f.get("residuo_desde"),
                         r_entra=f.get("residuo_hacia"))
        return len(nuevos)

    # -- desvíos de curva ---------------------------------------------

    def revisar_curva(self, cot=None):
        """Avisa cuando un bono se despega de su curva más de lo habitual.

        El umbral por defecto sale del backtest: 2,5 desvíos sobre
        especies líquidas dio 77% de acierto a 42 días. Por debajo de 2
        los costos se comen la ganancia, así que no vale avisar.
        """
        import bonos as BO
        import curva as CU

        umbral = float(self.cfg.get("curva_umbral_z") or 2.5)
        if not umbral:
            return 0
        # Sin cargar el campo, 0,5. HA no aplica defaults nuevos.
        h = self.cfg.get("curva_histeresis_z")
        h = 0.5 if h is None else max(0.0, min(float(h), umbral))
        # Persistencia: la zona tiene que verse N ciclos seguidos antes de
        # avisar. Los primeros precios de la rueda dan z de 7 u 8 que al
        # rato vuelven, y un z que se va y vuelve rearmaba el aviso: el
        # 05/10 TZXA7 aviso tres veces. Sin cargar el campo, 2.
        n_pers = self.cfg.get("curva_persistencia")
        n_pers = 2 if n_pers is None else max(1, int(n_pers))

        with self.lock:
            cot = cot or dict(self.cotizaciones)
        if not cot:
            return 0

        cer_act = float(self.cfg.get("cer_actual") or 0)
        t = BO.tabla(cot, cer_actual=cer_act)
        an = CU.analizar(t["filas"])
        por_sim = {f["simbolo"]: f for f in t["filas"]}

        avisadas = self._zonas_curva
        enviadas = 0
        vigentes = {}
        racha = self._curva_racha
        hoy = date.today().isoformat()
        # Una vez por dia por bono y zona, contando C/D/pesos como uno.
        dia = self._curva_dia()
        if dia.get("fecha") != hoy:
            dia = {"fecha": hoy, "claves": []}

        minimo = self._min_monto()
        mep = self._mep(cot)

        for sim, d in an.items():
            z = d.get("z")
            if z is None:
                continue
            previa = avisadas.get(sim)
            zona = _zona_curva(z, umbral, h, previa)
            # Un desvio calculado sobre una punta suelta no se puede
            # operar. El ajuste de la curva sigue usando a todos, que es
            # lo que hace comparable el z-score contra su historia; lo
            # que se filtra es a quien se le avisa. Barato se compra
            # contra el ask y caro se vende contra el bid.
            if zona and minimo:
                m = CU.monto_punta(por_sim.get(sim) or {},
                                   "ask" if zona == "barato" else "bid", mep)
                if m is not None and m < minimo:
                    continue
            if zona:
                fz = por_sim.get(sim) or {}
                rec = None
                if fz.get("md") is not None and d.get("media_hist") is not None:
                    rec = fz["md"] * (d["residuo"] - d["media_hist"]) / 100.0
                vigentes[sim] = {"zona": zona, "z": z, "residuo": d["residuo"],
                                 "recorrido": rec, "familia": fz.get("familia")}
            if zona == previa:
                racha.pop(sim, None)
                continue
            if not zona:
                # Salio de la zona: se rearma enseguida.
                avisadas[sim] = None
                racha.pop(sim, None)
                self._guardar_zonas_curva()
                continue
            r = racha.get(sim)
            n = r[1] + 1 if (r and r[0] == zona) else 1
            if n < n_pers:
                racha[sim] = (zona, n)
                continue
            racha.pop(sim, None)
            avisadas[sim] = zona
            self._guardar_zonas_curva()
            clave = _bono_base(sim, an) + "|" + zona
            if clave in dia["claves"]:
                continue

            f = por_sim.get(sim) or {}
            # sin punta ejecutable la señal no sirve
            if zona == "barato" and not f.get("ask"):
                continue
            if (cot.get(sim) or {}).get("punta_vieja"):
                continue    # punta de antes del cierre: no es operable

            icono = "🟢" if zona == "barato" else "🔴"
            que = "barato" if zona == "barato" else "caro"
            L = ["%s <b>%s</b> %s contra su curva" % (icono, sim, que),
                 "Desvío %+.0f pb  ·  z %+.2f" % (d["residuo"], z),
                 ""]
            if f.get("tir_last") is not None:
                L.append("TIR %.2f%%  ·  curva %.2f%%" % (
                    f["tir_last"], d["curva"]))
            if f.get("ask"):
                L.append("Ask %s  ·  TIR ask %.2f%%" % (
                    _n(f["ask"]), f.get("tir_ask") or 0))
            if d.get("vecino"):
                v = por_sim.get(d["vecino"]) or {}
                L += ["", "Vecino de duration parecida: %s (TIR %.2f%%)" % (
                    d["vecino"], v.get("tir_last") or 0)]
            L += ["", "<i>%s · %d bonos en la familia</i>" % (
                datetime.now().strftime("%H:%M"), d["n_familia"])]

            msg = "\n".join(L)
            self.notif.enviar("%s %s contra su curva" % (sim, que), msg,
                              urgente=(zona == "barato"))
            dia["claves"].append(clave)
            self._curva_dia(dia)
            db.registrar_alerta(sim, "curva_" + zona, d["residuo"], umbral, msg)
            import senales as SE
            barato = zona == "barato"
            SE.registrar("curva", sim, direccion=zona, z=z,
                         entra=sim if barato else None,
                         sale=None if barato else sim,
                         md_entra=f.get("md") if barato else None,
                         md_sale=None if barato else f.get("md"),
                         r_entra=d["residuo"] if barato else None,
                         r_sale=None if barato else d["residuo"])
            log.info("curva: %s %s z=%+.2f", sim, zona, z)
            enviadas += 1

        with self.lock:
            self.curva_vigentes = vigentes
        return enviadas

    # -- arbitraje de plazos t0 / t1 ---------------------------------

    def comision(self, tipo):
        tabla = self.cfg.get("comisiones") or {}
        try:
            return float(tabla.get(tipo, tabla.get("acciones", 0.15))) / 100.0
        except (TypeError, ValueError):
            return 0.0015

    def dias_liquidacion(self, hoy=None):
        """Dias corridos entre la liquidacion de t0 y la de t1.

        Un viernes son tres: t0 liquida el viernes y t1 el lunes. Tomar
        siempre uno triplicaba la TNA implicita de los viernes.
        """
        import cer as CER
        d = hoy or date.today()
        prox = d + timedelta(days=1)
        while not CER.es_habil(prox):
            prox += timedelta(days=1)
        return max(1, (prox - d).days)

    def evaluar_arbitraje(self, cot=None):
        """Vender en t0 y recomprar en t1.

        Se cobra hoy y se paga manana, asi que la diferencia de precios es
        una tasa implicita. Conviene cuando esa TNA, neta de comisiones,
        le gana a la caucion colocadora.

        El t1 sale del panel del ciclo cuando esta: los paneles cotizan a
        t1, asi que solo hace falta pedir el t0 de cada simbolo. Antes se
        pedian los dos y era el doble de requests.
        """
        filas = []
        cot = cot if cot is not None else dict(self.cotizaciones)
        tasa_anual, origen_tasa = self.tasa_caucion(cot)
        dias = self.dias_liquidacion()
        tasa_dia = tasa_anual / 365.0 / 100.0 * dias
        com_caucion = self.comision("cauciones")

        for t in self.cfg.get("arbitraje_tickers") or []:
            sim = (t.get("ticker") or "").upper()
            if not sim:
                continue
            mercado = t.get("mercado") or "bCBA"
            tipo = t.get("tipo") or "bonos"
            fila = {"ticker": sim, "tipo": tipo, "dias": dias,
                    "tasa_origen": origen_tasa, "tasa_anual": tasa_anual}
            try:
                # Con IOL caido el t0 sale de la misma bajada de BYMA:
                # pedirlo por especie serian dos llamadas por ticker.
                if self.fuente == "byma" and getattr(self, "cot_t0", None):
                    c0 = self.cot_t0.get(sim)
                    if not c0:
                        raise IOLError("%s: sin t0 en BYMA" % sim)
                else:
                    c0 = self.iol.cotizacion(mercado, sim, "t0")
                c1 = cot.get(sim)
                if not c1 or not c1.get("venta"):
                    c1 = self.iol.cotizacion(mercado, sim, "t1")
                elif c1.get("punta_vieja"):
                    fila["punta_vieja"] = True
            except IOLError as e:
                fila["error"] = str(e)
                filas.append(fila)
                continue

            fila.update({
                "compra_t0": c0["compra"], "venta_t0": c0["venta"],
                "q_compra_t0": c0.get("vol_compra"),
                "compra_t1": c1["compra"], "venta_t1": c1["venta"],
                "q_venta_t1": c1.get("vol_venta"),
            })

            if not c0["compra"] or not c1["venta"]:
                fila["error"] = "faltan puntas"
                filas.append(fila)
                continue

            bruto = (c0["compra"] - c1["venta"]) / c1["venta"]
            costo = self.comision(tipo) * 2
            neto = bruto - costo
            referencia = tasa_dia - com_caucion / 365.0 * dias

            fila.update({
                "bruto_pct": bruto * 100,
                "costo_pct": costo * 100,
                "neto_pct": neto * 100,
                "tna_pct": neto * 365.0 / dias * 100,
                "tna_caucion_pct": referencia * 365.0 / dias * 100,
                "caucion_dia_pct": referencia * 100,
                "conviene": bool(c0["compra"] > c1["venta"] and neto > referencia),
                "ejecutable": min(c0.get("vol_compra") or 0,
                                  c1.get("vol_venta") or 0),
            })
            filas.append(fila)

        filas.sort(key=lambda f: f.get("neto_pct") or -999, reverse=True)
        return filas

    # -- ciclo --------------------------------------------------------

    def ciclo(self, manual=False):
        if not self._pidiendo.acquire(blocking=False):
            return False
        try:
            mapa = self.cotizaciones_del_ciclo()
            with self.lock:
                self.cotizaciones = mapa
            # Fuera de rueda (un refresco manual de noche) la tarjeta se
            # actualiza pero no queda registro: las puntas de esa hora son
            # ordenes sueltas y la lectura pisaba el cierre del dia.
            en_rueda = self._en_horario()
            # Tampoco se avisa ni se registra ninguna alerta: las
            # pantallas se actualizan, las marcas de "ya avisado" no se
            # tocan y el primer ciclo en rueda avisa lo que siga vigente.
            self._silencio = not en_rueda
            for par in self.pares:
                try:
                    estado = self.evaluar_par(par, mapa, registrar=en_rueda)
                    with self.lock:
                        self.snapshot[par["alias"]] = estado
                except Exception as e:
                    log.warning("%s: %s", par["alias"], e)
                    with self.lock:
                        prev = self.snapshot.get(par["alias"]) or {
                            "alias": par["alias"], "num": par["num"],
                            "den": par["den"]}
                        prev["error"] = str(e)
                        self.snapshot[par["alias"]] = prev
            try:
                if en_rueda:
                    self.revisar_curva(mapa)
            except Exception as e:
                log.debug("revisar curva: %s", e)
            try:
                if en_rueda:
                    self.revisar_opciones(mapa)
            except Exception as e:
                log.debug("revisar opciones: %s", e)
            try:
                self.revisar_rulo(mapa)
            except Exception as e:
                log.debug("revisar rulo: %s", e)
            try:
                self.revisar_canjes(mapa)
            except Exception as e:
                log.debug("revisar canjes: %s", e)
            try:
                if en_rueda:
                    self.revisar_niveles(mapa)
            except Exception as e:
                log.debug("revisar niveles: %s", e)
            try:
                self.revisar_plazos(mapa)
            except Exception as e:
                log.debug("revisar plazos: %s", e)
            try:
                if en_rueda:
                    self.revisar_alertas_precio(mapa)
            except Exception as e:
                log.debug("revisar alertas de precio: %s", e)
            try:
                if en_rueda:
                    self.revisar_cobros()
            except Exception as e:
                log.debug("revisar cobros: %s", e)
            try:
                if en_rueda:
                    self.revisar_alertas_fecha()
            except Exception as e:
                log.debug("revisar alertas de fecha: %s", e)
            try:
                if en_rueda:
                    self.enviar_resumen()
            except Exception as e:
                log.warning("resumen: %s", e)
            try:
                self._guardar_snapshot()
            except Exception as e:
                log.debug("guardar snapshot: %s", e)
            self.ultimo_ciclo = datetime.now()
            if manual:
                self._ultimo_manual = datetime.now()
            return True
        finally:
            self._pidiendo.release()

    def evaluar_uno(self, gid):
        """La tarjeta de un par recien creado, editado o borrado.

        Las tarjetas salen de `snapshot`, que se arma en el ciclo, y fuera
        de rueda no hay ciclo: un par nuevo no aparecia hasta la apertura
        y uno renombrado desaparecia. Esto lo evalua solo, con las
        cotizaciones que ya hay -las del ultimo ciclo o las ultimas puntas
        guardadas-, sin pedir nada a la API y sin registrar nada.
        """
        self._pares_ts = None          # los pares se releen de la base
        pares = self.pares
        vigentes = {p["alias"] for p in pares}
        par = next((p for p in pares if p.get("id") == gid), None)
        with self.lock:
            # el nombre viejo de un par renombrado, o el de uno borrado
            for alias in [a for a, v in self.snapshot.items()
                          if a not in vigentes
                          or (par and v.get("id") == gid
                              and a != par["alias"])]:
                del self.snapshot[alias]
        if par:
            try:
                estado = self.evaluar_par(par, self.cotizaciones_vigentes(),
                                          registrar=False)
            except Exception as e:
                log.info("%s: %s", par["alias"], e)
                estado = {"id": par.get("id"), "alias": par["alias"],
                          "num": par["num"], "den": par["den"],
                          "error": str(e)}
            with self.lock:
                self.snapshot[par["alias"]] = estado
        try:
            self._guardar_snapshot()
        except Exception as e:
            log.debug("guardar snapshot: %s", e)

    def ciclo_manual(self):
        """Refresco a pedido, con un minimo entre disparos."""
        minimo = int(self.cfg.get("min_segundos_manual", 20))
        falta = minimo - (datetime.now() - self._ultimo_manual).total_seconds()
        if falta > 0:
            return False, int(falta) + 1
        ok = self.ciclo(manual=True)
        return ok, 0

    # -- opciones -----------------------------------------------------

    def parametros_opciones(self):
        c = self.cfg
        return {
            "dias_min": c.get("opc_dias_min", 15),
            "dias_max": c.get("opc_dias_max", 80),
            "saltos": c.get("opc_saltos", 3),
            "limite_base_pct": c.get("opc_limite_base_pct", 5),
            "riesgo_max_tabla_pct": c.get("opc_riesgo_tabla_pct", 45),
            "riesgo_max_alarma_pct": c.get("opc_riesgo_alarma_pct", 33),
            "bear_instrumento": c.get("opc_bear_instrumento", "ambos"),
            "lotes_min": c.get("opc_lotes_min", 2),
            "ciclos_persistencia": c.get("opc_ciclos_persistencia", 1),
            # Banda para rearmar el aviso: una vez avisada, la
            # combinacion no vuelve a avisar hasta superar el umbral mas
            # estos puntos. Es la clave propia de opciones y no la del
            # `histeresis_pct` de las zonas de ratio, que es otra cosa.
            "histeresis_pct": c.get("opc_histeresis_pct", 3),
            "ganancia_min_pct": c.get("opc_ganancia_min_pct", 100),
            "dias_min_desarme": c.get("opc_dias_min_desarme", 10),
            "mov_contrario_pct": c.get("opc_mov_contrario_pct", 4),
        }

    def cadena_opciones(self, cot=None):
        """Cadena con puntas. Fuera de rueda IOL no manda ninguna, asi que
        se guarda la ultima buena y se devuelve marcada."""
        import json
        import opciones as OP
        subs = [s.strip().upper()
                for s in (self.cfg.get("opc_subyacentes") or "GGAL").split(",")
                if s.strip()]

        # Fuera de rueda no se baja la cadena: son dos requests que
        # devuelven series sin puntas, y ya tenemos la ultima buena.
        if not self._en_horario():
            guardado = db.get_estado("opc_ultima_cadena")
            if guardado:
                d = json.loads(guardado)
                series = d.get("series") or []
                hoy = date.today()
                for x in series:
                    try:
                        x["dias"] = (date.fromisoformat(x["vencimiento"])
                                     - hoy).days
                    except Exception:
                        pass
                diag = {"en_panel": 0, "mapeadas": 0,
                        "parseadas": len(series), "con_puntas": 0,
                        "vencimientos": sorted({x["vencimiento"]
                                                for x in series}),
                        "campos": [], "sin_pedir": True}
                return series, d.get("spots") or {}, diag, True, d.get("ts")
            return [], {}, {"en_panel": 0, "mapeadas": 0, "parseadas": 0,
                            "con_puntas": 0, "vencimientos": [],
                            "campos": [], "sin_pedir": True}, False, None

        # el ciclo ya bajo el instrumento de opciones: se reusa en vez
        # de pedirlo de nuevo
        crudos = getattr(self, "_orleans_opciones", None)
        series, diag = OP.cadena(self.iol, subs, crudos=crudos)

        cot = cot if cot is not None else dict(self.cotizaciones)
        spots = {}
        for s in subs:
            c = cot.get(s) or {}
            spots[s] = c.get("ref") or c.get("ultimo") or 0

        viejo, desde = False, None
        if diag["con_puntas"] > 0 and any(spots.values()):
            db.set_estado("opc_ultima_cadena", json.dumps({
                "ts": datetime.now().isoformat(timespec="seconds"),
                "series": series, "spots": spots}))
        else:
            guardado = db.get_estado("opc_ultima_cadena")
            if guardado:
                d = json.loads(guardado)
                series = d.get("series") or []
                spots = {k: v for k, v in (d.get("spots") or spots).items()}
                desde, viejo = d.get("ts"), True
                hoy = date.today()
                for s in series:
                    try:
                        s["dias"] = (date.fromisoformat(s["vencimiento"])
                                     - hoy).days
                    except Exception:
                        pass
        return series, spots, diag, viejo, desde

    def revisar_opciones(self, cot=None):
        """Alertas de armado y de desarme, y el cierre diario."""
        import opciones as OP
        if not (self.cfg.get("opc_subyacentes") or "GGAL").strip():
            return 0

        series, spots, diag, viejo, _ = self.cadena_opciones(cot)
        if viejo or not series:
            return 0        # con puntas de ayer no se avisa nada

        par = self.parametros_opciones()
        r = OP.analizar(series, spots, par, self.cfg.get("comisiones") or {},
                        None, self.cfg.get("derechos_mercado") or {},
                        self.cfg.get("iva_pct") or 0)
        filas = r["filas"]
        marcas = db.opc_marcas()

        # armado: solo el cruce hacia adentro del umbral
        candidatas = [f for f in filas
                      if not (marcas.get(f["id"]) or {}).get("silenciada")]
        avisos, self._opc_estado = OP.cruces(
            candidatas, getattr(self, "_opc_estado", None), par)
        # Avisos de armado: "inmediato" como antes, "resumen" solo en el
        # resumen diario, "apagado" nada. Sin cargar el campo, resumen:
        # casi no se operan y eran la mayor parte de los avisos.
        modo = (self.cfg.get("opc_avisos") or "resumen").strip().lower()
        if avisos and modo == "inmediato":
            self._avisar_opciones(avisos)
        u_ = float(par.get("riesgo_max_alarma_pct") or 33)
        l_ = int(par.get("lotes_min") or 2)
        with self.lock:
            self.opc_vigentes = [] if modo == "apagado" else sorted(
                (f for f in candidatas
                 if f["riesgo_pct"] <= u_ and f["lotes"] >= l_),
                key=lambda f: f["riesgo_pct"])

        # desarme
        salidas = []
        for pos in db.opc_posiciones(abiertas=True):
            val = OP.valuar(pos, series)
            motivos = OP.motivos_desarme(pos, val, spots.get(pos["subyacente"]),
                                         par)
            if not motivos:
                self._opc_desarme.discard(pos["id"])
                continue
            if pos["id"] in self._opc_desarme:
                continue
            if val and val["lotes_salida"] < int(par.get("lotes_min") or 2):
                continue    # avisar sin punta para salir no sirve de nada
            self._opc_desarme.add(pos["id"])
            salidas.append((pos, val, motivos))
        if salidas:
            self._avisar_desarme(salidas)

        # Cierre diario por combinacion, para el grafico. No se guarda
        # todo el panel: con tres vencimientos y treinta bases son miles
        # de filas por dia y la mayoria no las vas a mirar nunca. Se
        # guardan las que tenes abiertas y las que estan en zona de
        # alerta, que son las dos que uno sigue.
        hoy = date.today().isoformat()
        umbral = float(par.get("riesgo_max_alarma_pct") or 33)
        lotes_min = int(par.get("lotes_min") or 2)
        mias = {p["combo"] for p in db.opc_posiciones(abiertas=True)}
        db.opc_guardar_cierres([
            (f["id"], hoy, f["riesgo_pct"], f["riesgo"], f["lotes"],
             f["spot"]) for f in filas
            if f["id"] in mias
            or (f["riesgo_pct"] <= umbral and f["lotes"] >= lotes_min)])
        return len(avisos)

    NOMBRE_ESTRUCTURA = {"BULL_CALL": "Bull con calls",
                         "BEAR_PUT": "Bear con puts",
                         "BEAR_CALL": "Bear con calls"}

    def _avisar_opciones(self, avisos):
        """Un solo aviso por ciclo con todo lo que cruzo el umbral.

        Con tres vencimientos y treinta bases, un mismo movimiento del
        papel puede meter decenas de combinaciones adentro del umbral a la
        vez. Mandar una notificacion por cada una es inservible: llegan
        todas juntas y no se lee ninguna.
        """
        avisos = sorted(avisos, key=lambda f: f["riesgo_pct"])
        n = len(avisos)
        mejor = avisos[0]

        if n == 1:
            titulo = "%s %s %s/%s al %.1f%%" % (
                mejor["subyacente"],
                self.NOMBRE_ESTRUCTURA.get(mejor["estructura"],
                                           mejor["estructura"]),
                _n(mejor["base_compra"]), _n(mejor["base_venta"]),
                mejor["riesgo_pct"])
        else:
            subs = sorted({f["subyacente"] for f in avisos})
            titulo = "%d spreads en %s, el mejor al %.1f%%" % (
                n, ", ".join(subs), mejor["riesgo_pct"])

        TOPE = 8
        lineas = []
        for f in avisos[:TOPE]:
            favor = (" a favor" if f.get("a_favor") is True
                     else " en contra" if f.get("a_favor") is False else "")
            lineas.append(
                "<b>%.1f%%</b> · %s %s/%s · 1 a %.2f · %d dias · %d lotes%s"
                % (f["riesgo_pct"],
                   self.NOMBRE_ESTRUCTURA.get(f["estructura"],
                                              f["estructura"]),
                   _n(f["base_compra"]), _n(f["base_venta"]), f["ratio"],
                   f["dias"], f["lotes"], favor))
        if n > TOPE:
            lineas.append("y %d mas en la pestana." % (n - TOPE))
        lineas.append("Equilibrio del mejor en %s (%+.1f%%)."
                      % (_n(mejor["equilibrio"]), mejor["var_equilibrio_pct"]))

        self.notif.enviar(titulo, "<br>".join(lineas))
        # el registro guarda la notificacion entera, no solo el titulo
        texto = "<b>%s</b><br>%s" % (titulo, "<br>".join(lineas))
        for f in avisos:
            db.registrar_alerta(f["id"], "opcion_armado", f["riesgo_pct"],
                                f["ratio"], texto)

    def _avisar_desarme(self, salidas):
        """Tambien en un solo aviso, por la misma razon que el armado."""
        if len(salidas) == 1:
            pos = salidas[0][0]
            titulo = "Desarmar %s %s/%s" % (
                pos["subyacente"], _n(pos["base_compra"]),
                _n(pos["base_venta"]))
        else:
            titulo = "%d posiciones para desarmar" % len(salidas)

        lineas = []
        for pos, val, motivos in salidas:
            plata = ("vale %s por lote, %s en total"
                     % (_n(val["salida"]), _n(val["ganancia_total"]))
                     if val else "sin puntas para valuar")
            lineas.append("<b>%s %s/%s</b> · %s · %s" % (
                pos["subyacente"], _n(pos["base_compra"]),
                _n(pos["base_venta"]), "; ".join(motivos), plata))
        self.notif.enviar(titulo, "<br>".join(lineas))
        # el registro guarda la notificacion entera, no solo el titulo
        texto = "<b>%s</b><br>%s" % (titulo, "<br>".join(lineas))
        for pos, val, _m in salidas:
            db.registrar_alerta(pos["combo"], "opcion_desarme",
                                (val or {}).get("ganancia_pct"), None, texto)


    def brokers_extranjeros(self):
        return {b.strip().upper()
                for b in (self.cfg.get("brokers_extranjeros") or "").split(",")
                if b.strip()}

    def tengo_actual(self):
        """Que hay para armar circuitos.

        Los bonos salen de las tenencias, y solo las de brokers locales:
        un titulo en una cuenta del exterior no liquida contra el mercado
        local, asi que no puede ser una pata del rulo. Las monedas salen
        de la configuracion, que es donde se elige en cuales se opera.
        """
        fuera = self.brokers_extranjeros()
        monedas = [m.strip().upper()
                   for m in (self.cfg.get("monedas_rulo") or "ARS,MEP").split(",")
                   if m.strip()]
        try:
            import bonos as BO
            con_cronograma = set(BO.cargar()[0])
        except Exception:
            con_cronograma = set()

        # Solo bonos con cronograma cargado: una accion o un CEDEAR no
        # tiene especie D ni C, asi que no puede cruzar de moneda y solo
        # ensuciaria el universo de circuitos.
        bonos = sorted({t["simbolo"] for t in db.tenencias()
                        if t["broker"].upper() not in fuera
                        and t["cantidad"]
                        and t["simbolo"] not in MONEDAS_TENENCIA
                        and (t.get("tipo") or "") in ("bonos", "letras", "")
                        and (not con_cronograma
                             or t["simbolo"] in con_cronograma)})
        return {"monedas": monedas, "bonos": bonos}


    # -- alertas por fecha --------------------------------------------

    def revisar_alertas_fecha(self):
        """Recordatorios sueltos: revisar algo, una fecha limite.

        Se avisan una vez y queda registrado en la base: reiniciar no
        vuelve a dispararlos. Cambiar la fecha los rehabilita.
        """
        hoy = date.today()
        avisos = []
        for a in db.alertas_fecha(solo_activas=True):
            if a["avisada"]:
                continue
            try:
                f = date.fromisoformat(str(a["fecha"])[:10])
            except ValueError:
                continue
            if (f - hoy).days > int(a["dias_antes"] or 0):
                continue
            db.marcar_alerta_fecha(a["id"])
            a["dias"] = (f - hoy).days
            avisos.append(a)
        if avisos:
            self._avisar_fecha(avisos)
        return len(avisos)

    def _avisar_fecha(self, avisos):
        if len(avisos) == 1:
            titulo = avisos[0]["titulo"]
        else:
            titulo = "%d recordatorios" % len(avisos)
        lineas = []
        for a in avisos:
            d = a["dias"]
            cuando = ("hoy" if d == 0 else "manana" if d == 1
                      else "en %d dias" % d if d > 0
                      else "hace %d dias" % -d)
            lineas.append("<b>%s</b> · %s (%s)%s" % (
                a["titulo"], a["fecha"], cuando,
                "<br>&nbsp;&nbsp;%s" % a["nota"] if a["nota"] else ""))
        self.notif.enviar(titulo, "<br>".join(lineas))
        # el registro guarda la notificacion entera, no solo el titulo
        texto = "<b>%s</b><br>%s" % (titulo, "<br>".join(lineas))
        for a in avisos:
            db.registrar_alerta(str(a["id"]), "fecha", None, None, texto)


    # -- cobros -------------------------------------------------------

    def revisar_cobros(self):
        """Avisa unos dias antes de cada pago de lo que hay en cartera.

        No depende de puntas ni de que haya rueda: sale del cronograma y
        de la tenencia, asi que corre igual con el mercado cerrado.
        """
        import cobros as CO_COBROS
        dias = int(self.cfg.get("dias_aviso_cobro") or 2)
        if not dias:
            return 0
        nuevos = CO_COBROS.por_avisar(
            dias_aviso=dias,
            cer_actual=float(self.cfg.get("cer_actual") or 0),
            brokers_fuera=self.brokers_extranjeros())
        if nuevos:
            self._avisar_cobros(nuevos)
        return len(nuevos)

    def _avisar_cobros(self, pagos):
        pagos.sort(key=lambda p: (p["fecha"], p["simbolo"]))
        if len(pagos) == 1:
            p = pagos[0]
            cuando = ("hoy" if p["dias"] == 0 else
                      "manana" if p["dias"] == 1 else
                      "en %d dias" % p["dias"])
            titulo = "Cobras %s %s" % (p["simbolo"], cuando)
        else:
            titulo = "%d cobros proximos" % len(pagos)
        lineas = []
        for p in pagos:
            monto = ("%s %s" % (p["moneda"], _n(p["importe"]))
                     if p["importe"] is not None else "importe no calculable")
            detalle = []
            if p["renta"]:
                detalle.append("renta %s" % _n(p["renta"]))
            if p["amortizacion"]:
                detalle.append("amort %s" % _n(p["amortizacion"]))
            lineas.append("<b>%s</b> el %s · %s%s · %s nominales en %s" % (
                p["simbolo"], p["fecha"], monto,
                " (estimado)" if p["estimado"] else "",
                _n(p["nominales"]), ", ".join(p["brokers"])))
            if detalle:
                lineas.append("&nbsp;&nbsp;%s por cada 100" % " + ".join(detalle))
        self.notif.enviar(titulo, "<br>".join(lineas))
        # el registro guarda la notificacion entera, no solo el titulo
        texto = "<b>%s</b><br>%s" % (titulo, "<br>".join(lineas))
        for p in pagos:
            db.registrar_alerta(p["simbolo"], "cobro", p["importe"], None,
                                texto)


    # -- alertas de precio --------------------------------------------

    def evaluar_alerta(self, alerta, cot):
        """Estado de una alerta y de cada una de sus condiciones.

        Comprar mira la punta vendedora y vender la compradora: es contra
        la que se ejecuta. Con puntas repuestas de antes del cierre no se
        da por cumplida ninguna.
        """
        detalle, cumplen, hay_vieja, falta = [], 0, False, False
        for cond in alerta.get("condiciones") or []:
            c = cot.get(cond["simbolo"]) or {}
            if c.get("punta_vieja"):
                hay_vieja = True
            if cond["operacion"] == "comprar":
                actual = c.get("venta") or 0        # pago el ask
                ok = bool(actual) and actual <= cond["precio"]
            else:
                actual = c.get("compra") or 0       # cobro el bid
                ok = bool(actual) and actual >= cond["precio"]
            if not actual:
                falta = True
            cumplen += 1 if ok else 0
            detalle.append({"simbolo": cond["simbolo"],
                            "operacion": cond["operacion"],
                            "precio": cond["precio"], "actual": actual,
                            "cumple": ok})
        total = len(detalle)
        if not total:
            return {"cumple": False, "detalle": detalle}
        cumple = cumplen == total if alerta["modo"] == "todas" else cumplen > 0
        return {"cumple": cumple and not hay_vieja and not falta,
                "cumplen": cumplen, "total": total,
                "punta_vieja": hay_vieja, "sin_precio": falta,
                "detalle": detalle}

    def revisar_alertas_precio(self, cot=None):
        """Avisa cuando una alerta pasa a cumplirse, no mientras se
        mantiene: vuelve a armarse cuando deja de cumplirse."""
        cot = cot if cot is not None else dict(self.cotizaciones)
        if not cot:
            return 0
        avisos = []
        for a in db.alertas_precio(solo_activas=True):
            r = self.evaluar_alerta(a, cot)
            if not r["cumple"]:
                self._precio_avisado.discard(a["id"])
                continue
            if a["id"] in self._precio_avisado:
                continue
            self._precio_avisado.add(a["id"])
            avisos.append((a, r))
        if avisos:
            self._avisar_precio(avisos)
        return len(avisos)

    def _avisar_precio(self, avisos):
        if len(avisos) == 1:
            titulo = avisos[0][0]["titulo"]
        else:
            titulo = "%d alertas de precio" % len(avisos)
        lineas = []
        for a, r in avisos:
            partes = ["%s %s a %s (esta %s)" % (
                d["operacion"], d["simbolo"], _n(d["precio"]), _n(d["actual"]))
                for d in r["detalle"]]
            union = " y " if a["modo"] == "todas" else " o "
            lineas.append("<b>%s</b>: %s" % (a["titulo"], union.join(partes)))
        self.notif.enviar(titulo, "<br>".join(lineas))
        # el registro guarda la notificacion entera, no solo el titulo
        texto = "<b>%s</b><br>%s" % (titulo, "<br>".join(lineas))
        for a, r in avisos:
            db.registrar_alerta(str(a["id"]), "precio", None, None, texto)


    # -- plazos -------------------------------------------------------

    def revisar_plazos(self, cot=None):
        """Avisa cuando vender en t0 y recomprar en t1 le gana a la
        caucion colocadora, neto de comisiones.

        Antes solo se calculaba al abrir la pestania, asi que una
        oportunidad que duraba media rueda podia no verse nunca.
        """
        if not (self.cfg.get("arbitraje_tickers") or []):
            return 0
        filas = self.evaluar_arbitraje(cot)
        with self.lock:
            self.plazos = filas
        if getattr(self, "_silencio", False):
            return 0

        avisos = []
        for f in filas:
            if f.get("error") or not f.get("conviene"):
                self._plazos_avisado.discard(f["ticker"])
                continue
            if f.get("punta_vieja"):
                continue        # el t1 es de antes del cierre
            if not f.get("ejecutable"):
                continue        # sin punta de los dos lados no se ejecuta
            if f["ticker"] in self._plazos_avisado:
                continue
            self._plazos_avisado.add(f["ticker"])
            avisos.append(f)

        if avisos:
            self._avisar_plazos(avisos)
        return len(avisos)

    def _avisar_plazos(self, avisos):
        """Un solo aviso por ciclo, como en rulo y opciones."""
        avisos.sort(key=lambda f: -(f.get("tna_pct") or 0))
        m = avisos[0]
        if len(avisos) == 1:
            titulo = "%s: t0/t1 al %.1f%% TNA" % (m["ticker"], m["tna_pct"])
        else:
            titulo = "%d plazos, el mejor %s al %.1f%% TNA" % (
                len(avisos), m["ticker"], m["tna_pct"])
        lineas = []
        for f in avisos[:8]:
            lineas.append(
                "<b>%s</b> %.1f%% TNA contra %.1f%% de caucion · vender t0 a "
                "%s, recomprar t1 a %s · %s nominales" % (
                    f["ticker"], f["tna_pct"], f.get("tna_caucion_pct") or 0,
                    _n(f["compra_t0"]), _n(f["venta_t1"]),
                    _n(f.get("ejecutable") or 0)))
        if len(avisos) > 8:
            lineas.append("y %d mas en la pestania." % (len(avisos) - 8))
        lineas.append("Plazo de %d dia%s entre liquidaciones." % (
            m.get("dias") or 1, "" if (m.get("dias") or 1) == 1 else "s"))
        self.notif.enviar(titulo, "<br>".join(lineas))
        # el registro guarda la notificacion entera, no solo el titulo
        texto = "<b>%s</b><br>%s" % (titulo, "<br>".join(lineas))
        for f in avisos:
            db.registrar_alerta(f["ticker"], "plazos", f.get("tna_pct"),
                                None, texto)


    # -- rulo ---------------------------------------------------------

    def revisar_rulo(self, cot=None):
        """Circuitos del ciclo, y aviso cuando alguno supera el umbral.

        Antes solo se calculaban al abrir la pestania, asi que un rulo
        que aparecia y se cerraba entre dos miradas no se veia nunca.
        """
        import json
        import circuitos as CI
        import costos as CO_COSTOS
        cot = cot if cot is not None else dict(self.cotizaciones)
        if not cot:
            return 0
        tengo = self.tengo_actual()

        puentes = [t["ticker"] for t in (self.cfg.get("arbitraje_tickers") or [])
                   if t.get("ticker")]
        universo = sorted(set(puentes) | set(tengo.get("bonos") or []))
        if not universo:
            return 0

        r = CI.analizar(cot, universo, tengo,
                        self.cfg.get("comisiones") or {},
                        float(self.cfg.get("rulo_umbral_pct") or 0),
                        self.cfg.get("derechos_mercado") or {},
                        self.cfg.get("iva_pct") or 0,
                        CO_COSTOS.esquema(self.cfg),
                        min_monto=self._min_monto(),
                        mep=self._mep(cot))
        with self.lock:
            self.circuitos = r
        if getattr(self, "_silencio", False):
            return 0

        umbral = float(self.cfg.get("rulo_umbral_pct") or 0)
        if not umbral:
            return 0
        avisos = []
        for g in r.get("grupos") or []:
            for x in (g.get("circuitos") or [])[:1]:
                if x.get("resultado_pct", 0) < umbral:
                    continue
                # con puntas repuestas de antes del cierre no es ejecutable
                if any((cot.get(p.get("especie")) or {}).get("punta_vieja")
                       for p in x.get("pasos") or []):
                    continue
                clave = "%s|%s" % (g.get("clave"), x.get("clave") or
                                   "->".join(p.get("especie") or ""
                                             for p in x.get("pasos") or []))
                if clave in self._rulo_avisado:
                    continue
                self._rulo_avisado.add(clave)
                avisos.append((g, x))
        vivos = set()
        for g in r.get("grupos") or []:
            for x in (g.get("circuitos") or [])[:1]:
                if x.get("resultado_pct", 0) >= umbral:
                    vivos.add("%s|%s" % (g.get("clave"), x.get("clave") or
                              "->".join(p.get("especie") or ""
                                        for p in x.get("pasos") or [])))
        self._rulo_avisado &= vivos

        if avisos:
            self._avisar_rulo(avisos)
        return len(avisos)

    def _avisar_rulo(self, avisos):
        """Un solo aviso por ciclo, como en opciones."""
        avisos.sort(key=lambda t: -t[1].get("resultado_pct", 0))
        g0, x0 = avisos[0]
        if len(avisos) == 1:
            titulo = "Rulo %+.2f%% desde %s" % (
                x0["resultado_pct"], g0.get("desde") or "")
        else:
            titulo = "%d rulos, el mejor %+.2f%%" % (
                len(avisos), x0["resultado_pct"])
        lineas = []
        for g, x in avisos[:6]:
            ruta = " -> ".join(p.get("especie") or "" for p in x.get("pasos") or [])
            lineas.append("<b>%+.2f%%</b> desde %s · %s" % (
                x["resultado_pct"], g.get("desde") or "", ruta))
        self.notif.enviar(titulo, "<br>".join(lineas))
        # el registro guarda la notificacion entera, no solo el titulo
        texto = "<b>%s</b><br>%s" % (titulo, "<br>".join(lineas))
        for g, x in avisos:
            db.registrar_alerta(str(g.get("clave")), "rulo",
                                x.get("resultado_pct"), None, texto)

    # -- snapshot persistente -----------------------------------------

    def _guardar_snapshot(self):
        """El Panel se alimenta de memoria y quedaba vacio tras cada
        reinicio fuera de rueda. Guardarlo permite mostrar el ultimo
        estado conocido sin pedir nada.

        Se poda antes de guardar: el snapshot se indexa por alias y, al
        renombrar o borrar un par, el alias viejo quedaba adentro para
        siempre y seguia dibujando una tarjeta fantasma.
        """
        import json
        vigentes = {p["alias"] for p in self.pares}
        with self.lock:
            for alias in [a for a in self.snapshot if a not in vigentes]:
                del self.snapshot[alias]
            datos = dict(self.snapshot)
        if datos:
            db.set_estado("snapshot_pares", json.dumps(
                {"ts": datetime.now().isoformat(timespec="seconds"),
                 "pares": datos}))

    def _cargar_snapshot(self):
        import json
        try:
            d = json.loads(db.get_estado("snapshot_pares") or "null") or {}
        except Exception:
            return
        pares = d.get("pares") or {}
        if not pares:
            return
        # El snapshot guardado puede ser de una version anterior y no
        # traer campos que se agregaron despues. El `id` del par es el
        # caso: sin el, la tarjeta no encuentra su estrategia y el panel
        # se ve sin posicion hasta que corra el primer ciclo, que fuera
        # de rueda puede ser al dia siguiente. Se repone por alias, que
        # es la clave con la que se guardo.
        ids = {p["alias"]: p.get("id") for p in self.pares}
        pares = {k: v for k, v in pares.items() if k in ids}
        if not pares:
            return
        for k, v in pares.items():
            v["viejo"] = True
            if not v.get("id"):
                v["id"] = ids[k]
        with self.lock:
            if not self.snapshot:
                self.snapshot = pares
        self.snapshot_desde = d.get("ts")


    # -- historico de bonos -------------------------------------------

    def cerrar_dia_bonos(self):
        """Un punto de TIR y duration por bono, con el cierre de hoy.

        Solo en dia de rueda. Corre todos los dias a las 18 y antes
        grababa los sabados, domingos y feriados con la fecha de hoy y
        las cotizaciones de la ultima rueda: un precio repetido que
        entraba al z como un dia mas (16/08, 12/09, 19/09 y 20/09/2026).
        """
        import calendario as CAL
        if not CAL.hay_rueda(date.today()):
            return 0
        try:
            import historico as H
            import bonos as BO
            with self.lock:
                cot = dict(self.cotizaciones)
            if not cot:
                # Recien arrancado (un despliegue a la tarde): el ciclo no
                # corrio y no hay nada en memoria, pero las ultimas puntas
                # de hoy quedaron guardadas. Solo las de hoy: una de otro
                # dia no es el cierre de esta rueda.
                hoy_s = date.today().isoformat()
                cot = {s_: c for s_, c in self.mapa_guardado().items()
                       if str(c.get("punta_ts") or "")[:10] == hoy_s}
            if not cot:
                return 0
            mep = (BO.calcular_mep(cot).get("medio") or 0) or None
            n = H.agregar_hoy(cot, mep)
            if n:
                log.info("histórico de bonos: +%d puntos", n)
            try:
                import curva as CU
                cer_act = float(self.cfg.get("cer_actual") or 0)
                t = BO.tabla(cot, cer_actual=cer_act)
                CU.guardar(CU.residuos(t["filas"]))
            except Exception as e:
                log.debug("residuos del día: %s", e)
            return n
        except Exception as e:
            log.warning("no se pudo cerrar el día de bonos: %s", e)
            return 0

    def completar_cierres(self, dias_atras=30):
        """Dias de rueda recientes sin cierre en `bono_hist`: se bajan de
        IOL/BYMA y se rearman los residuos desde el primero. Cada dia se
        intenta una sola vez, para no repetir 70 pedidos cada noche si
        la fuente no lo tiene."""
        import calendario as CAL
        import historico as H
        import bonos as BO
        import json
        c = db.conn()
        hoy = date.today()
        tiene = {r["fecha"]: r["n"] for r in c.execute(
            "SELECT fecha, COUNT(*) n FROM bono_hist WHERE fecha >= ? "
            "GROUP BY fecha", ((hoy - timedelta(days=dias_atras)).isoformat(),))}
        normal = max(tiene.values()) if tiene else 0
        try:
            intentados = set(json.loads(db.get_estado("cierres_intentados") or "[]"))
        except (TypeError, ValueError):
            intentados = set()
        faltan = []
        for i in range(1, dias_atras + 1):
            d = hoy - timedelta(days=i)
            k = d.isoformat()
            if k in intentados or not CAL.hay_rueda(d):
                continue
            # Un dia con menos de la mitad de los bonos de siempre tambien
            # cuenta como sin cierre (el 06/10 quedo con uno solo).
            if tiene.get(k, 0) < max(5, normal // 2):
                faltan.append(d)
        if not faltan or not normal:
            return 0
        d0, d1 = min(faltan), max(faltan)
        log.info("cierres faltantes: %s", ", ".join(d.isoformat() for d in faltan))
        # AL30 y AL30D primero: de ellas sale el MEP de cada dia.
        sims = sorted(BO.especies(), key=lambda s_: (s_ not in ("AL30", "AL30D"), s_))
        total = 0
        for sim in sims:
            try:
                total += H.reconstruir(self.iol, sim, desde=d0, hasta=d1,
                                       forzar=True, marcar=False)
            except Exception as e:
                log.debug("cierre faltante %s: %s", sim, e)
        try:
            import curva as CU
            CU.reconstruir(desde=d0)
        except Exception as e:
            log.warning("residuos de los cierres faltantes: %s", e)
        intentados |= {d.isoformat() for d in faltan}
        db.set_estado("cierres_intentados", json.dumps(sorted(intentados)[-60:]))
        log.info("cierres faltantes: %d puntos", total)
        return total

    def reconstruir_historico(self):
        """Completa el histórico de las especies a las que les falta.

        No es global: si agregás un bono nuevo, se reconstruye solo ese
        en el próximo arranque sin rehacer los que ya están. Cuenta
        también el hueco hacia atrás de las que recibieron el punto del
        ciclo diario antes que el backfill.
        """
        try:
            import historico as H
            H.init()
            faltan = H.sin_serie()
            if not faltan:
                return 0
            log.info("completando el histórico de %d especie(s): %s",
                     len(faltan), ", ".join(x[0] for x in faltan[:8]) +
                     (" y otras" if len(faltan) > 8 else ""))
            H.progreso["corriendo"] = True
            try:
                total = H.completar(self.iol, faltan)
            finally:
                H.progreso["corriendo"] = False
                H.progreso["actual"] = None
            log.info("histórico de bonos: %d puntos calculados", total)
            return total
        except Exception as e:
            log.warning("no se pudo reconstruir el histórico: %s", e)
            return 0

    # -- relleno de huecos --------------------------------------------

    def rellenar_huecos(self):
        """Días laborables sin lecturas propias se completan con cierres de IOL.

        Pasa cuando se cae internet o la máquina queda apagada. Corre una vez
        por semana: los cierres de la semana ya están consolidados.
        """
        from datetime import date as _date
        desde = (datetime.now().date() - timedelta(days=180)).isoformat()
        rellenados = 0

        for par in self.pares:
            propios = {f for f, _ in db.serie_propia_diaria(
                par["alias"], desde, self.horario())}
            serie = db.serie_ratio_diaria(par["num"], par["den"], desde)
            for fecha, ratio in serie:
                if fecha in propios:
                    continue
                try:
                    d = _date.fromisoformat(fecha)
                except ValueError:
                    continue
                if d.weekday() >= 5:
                    continue
                vacio = {"ref": 0, "compra": 0, "venta": 0,
                         "vol_compra": 0, "vol_venta": 0}
                db.guardar_lectura(par["alias"], ratio, vacio, vacio,
                                   ts=fecha + "T23:59:00")
                rellenados += 1

        if rellenados:
            log.info("relleno semanal: %d días completados con cierres de IOL",
                     rellenados)
        db.set_estado("ultimo_relleno", datetime.now().date().isoformat())
        return rellenados

    # -- historico ----------------------------------------------------

    def backfill(self):
        """Cierres historicos de los tickers de cada par.

        Llega hasta ayer y no hasta hoy: el cierre del dia en curso lo
        guarda el cierre diario cuando termina la rueda. Pidiendolo aca
        se gastaba una llamada por ticker en cada arranque para traer un
        dato que iba a llegar igual, o que todavia no existe.
        """
        # Los pares por TIR leen bono_hist: sus cierres no hacen falta y
        # pedirlos daba 500 todos los dias en las Lecap/Boncap (TZXM9).
        simbolos = set()
        for p in self.pares:
            if p.get("modo") == "tir":
                continue
            simbolos.add((p["mercado"], p["num"]))
            simbolos.add((p["mercado"], p["den"]))
        hasta = datetime.now().date() - timedelta(days=1)
        hoy = datetime.now().date().isoformat()
        fallos = getattr(self, "_backfill_fallos", {})
        self._backfill_fallos = fallos
        try:
            import bonos as BO
            import historico as HI
            catalogo, _eq = BO.cargar()
            esps = BO.especies()
        except Exception:
            catalogo, esps, HI = {}, {}, None

        for mercado, sim in sorted(simbolos):
            # una especie que fallo hoy no se vuelve a pedir hasta manana
            if fallos.get(sim) == hoy:
                continue
            ultimo = db.ultimo_cierre_guardado(sim)
            if ultimo:
                desde = datetime.fromisoformat(ultimo).date() + timedelta(days=1)
                if desde > hasta:
                    continue
            else:
                desde = hasta - timedelta(days=BACKFILL_DIAS)
                # un bono no tiene historia antes de su emision
                info = esps.get(sim)
                if HI and info and catalogo.get(info["cronograma"]):
                    desde = max(desde, HI.inicio_de(catalogo[info["cronograma"]]))
                if desde > hasta:
                    continue
            try:
                datos = self.iol.serie(mercado, sim, desde.isoformat(),
                                       hasta.isoformat())
            except IOLError as e:
                fallos[sim] = hoy
                log.warning("historico %s: %s (se reintenta manana)", sim, e)
                continue
            filas = []
            for punto in datos or []:
                fecha = str(punto.get("fechaHora") or "")[:10]
                cierre = punto.get("ultimoPrecio") or punto.get("cierreAnterior")
                try:
                    cierre = float(cierre)
                except (TypeError, ValueError):
                    continue
                if fecha and cierre > 0:
                    filas.append((fecha, cierre))
            if filas:
                db.guardar_cierres(sim, filas)
                log.info("historico %s: +%d cierres", sim, len(filas))
            time.sleep(0.4)

    # -- loop ---------------------------------------------------------

    def loop(self):
        db.init()
        try:
            self._cargar_snapshot()
        except Exception as e:
            log.debug("snapshot guardado: %s", e)
        # Si IOL falla al arrancar (un 502 de su lado mientras HA reinicia)
        # el monitor sigue: el token se vuelve a pedir solo en el primer
        # pedido (`_asegurar_token`, con un minuto de espera entre
        # intentos). Antes el hilo terminaba y la app quedaba sin
        # monitor hasta reiniciar el add-on.
        try:
            self.iol.login()
        except Exception as e:
            self.ultimo_error = str(e)
            log.error("no se pudo autenticar al arrancar (se reintenta solo): %s", e)

        try:
            import calendario as CAL
            CAL.actualizar()
        except Exception as e:
            log.warning("calendario: %s", e)

        try:
            self.backfill()
        except Exception as e:
            log.warning("backfill incompleto: %s", e)

        threading.Thread(target=self.reconstruir_historico,
                         daemon=True, name="hist-bonos").start()

        # La marca del ultimo cierre hecho vive en la base. Antes se
        # arrancaba con la fecha de hoy, como si el cierre ya estuviera
        # hecho: cualquier dia con un reinicio (un despliegue) se quedaba
        # sin cierre de bonos, sin foto de la cartera y sin medicion de
        # señales. Faltaron el 06/10 y el 09/10/2026.
        try:
            ultimo_backfill = date.fromisoformat(db.get_estado("ultimo_cierre") or "")
        except (TypeError, ValueError):
            ultimo_backfill = datetime.now().date() - timedelta(days=1)
        espera = int(self.cfg.get("poll_seconds", 600))

        while True:
            try:
                # Niveles en dolares de NY: una revision por dia, a las 12
                # (NY ya abrio). Los avisos salen en el ciclo siguiente.
                ahora = datetime.now()
                if ahora.weekday() < 5 and ahora.hour >= 12 and \
                        db.get_estado("ny_dia") != ahora.date().isoformat():
                    # El dia se marca hecho solo si la revision termino
                    # entera: con un 429 o un corte de red se reintenta en
                    # el ciclo siguiente (cada poll_seconds) hasta las 18.
                    completa = True
                    try:
                        import gestion as GE
                        if any(n.get("modo") == "ny" for n in GE.config()["niveles"].values()):
                            log.info("precios de NY: %d", GE.actualizar_ny(self.iol))
                            completa = GE.ny_completo
                    except Exception as e:
                        completa = False
                        log.warning("precios de NY: %s", e)
                    if completa or ahora.hour >= 18:
                        db.set_estado("ny_dia", ahora.date().isoformat())
                    else:
                        log.info("precios de NY incompletos: se reintenta en el próximo ciclo")
                if self._en_horario():
                    self.ciclo()
                    self.ultimo_error = None
                # Fuera de rueda no se pide nada. Antes, si el snapshot
                # estaba vacio se ciclaba igual, pero IOL no manda puntas
                # con el mercado cerrado: el ciclo no lograba llenarlo y
                # se repetia cada diez minutos gastando cupo.

                hoy = datetime.now().date()
                if hoy != ultimo_backfill and datetime.now().hour >= 18:
                    try:
                        import calendario as CAL
                        CAL.actualizar()     # no hace nada hasta el mes
                    except Exception as e:
                        log.warning("calendario: %s", e)
                    self.backfill()
                    self.medir_senales()
                    # Foto diaria de la cartera, solo en dia de rueda: los
                    # precios de un sabado son los del viernes.
                    try:
                        import calendario as CAL
                        if CAL.hay_rueda(date.today()) and \
                                getattr(self, "foto_cartera", None):
                            self.foto_cartera()
                    except Exception as e:
                        log.warning("foto de cartera: %s", e)
                    self.cerrar_dia_bonos()
                    try:
                        self.completar_cierres()
                    except Exception as e:
                        log.warning("cierres faltantes: %s", e)
                    db.purgar()
                    db.purgar_api_log()
                    ultimo_backfill = hoy
                    db.set_estado("ultimo_cierre", hoy.isoformat())
                    # domingos: completar los días que faltaron
                    if hoy.weekday() == 6:
                        try:
                            self.rellenar_huecos()
                        except Exception as e:
                            log.warning("relleno semanal: %s", e)
            except Exception as e:
                self.ultimo_error = str(e)
                log.error("ciclo fallo: %s", e)

            if not self._en_horario():
                dormir = max(espera, 900)
            elif self.hay_rueda is False:
                dormir = max(espera, 1800)   # feriado: casi no consultamos
            else:
                dormir = espera
            time.sleep(dormir)


def _sufijo_dolar(sim, otro):
    """"D" o "C" si `sim` es `otro` en dolares MEP o cable, si no None.

    Misma guarda que `operaciones.simbolo_base`: la letra final se corta
    solo si lo que queda es la otra punta del par, no a ciegas.
    """
    if len(sim) > 2 and sim[-1] in ("D", "C") and sim[:-1] == otro:
        return sim[-1]
    return None


def es_par_moneda(num, den):
    """AL30/AL30D o AL30/AL30C: la misma especie en pesos y en dolares.

    AL30D/AL30C no cuenta: las dos puntas son dolares y el ratio es el
    canje, que se lee como un par comun.
    """
    a, b = (num or "").upper(), (den or "").upper()
    return bool(_sufijo_dolar(a, b) or _sufijo_dolar(b, a))


def sugerencia_par(num, den, zona, saldos=None):
    """En que punta del par conviene estar, segun la zona.

    Con ratio = num / den:
      - zona alta: el numerador esta caro, conviene el denominador;
      - zona baja: el numerador esta barato, conviene el numerador;
      - normal: sin ventaja, se mantiene lo que haya.

    En un par de moneda (AL30/AL30D) el ratio es el MEP o su inversa y
    la lectura se da vuelta: dolar caro, conviene pesos. Con el ratio en
    pesos por dolar la zona alta es dolar caro y lleva al numerador, que
    es la punta en pesos; con el ratio invertido la zona alta es dolar
    barato y lleva al numerador, que es la punta en dolares. En los dos
    casos, alta lleva al numerador.
    """
    moneda = es_par_moneda(num, den)
    estar_en, lectura = None, ""
    if zona in ("alta", "baja"):
        if moneda:
            estar_en = num if zona == "alta" else den
            a, b = num.upper(), den.upper()
            suf = _sufijo_dolar(a, b) or _sufijo_dolar(b, a)
            dolar = "dólar cable" if suf == "C" else "dólar"
            otra = den if estar_en == num else num
            en_pesos = _sufijo_dolar(otra.upper(), estar_en.upper()) is not None
            lectura = ("%s caro → pesos" % dolar) if en_pesos \
                else ("%s barato → dólares" % dolar)
        else:
            estar_en = den if zona == "alta" else num
            lectura = ("%s caro" % num) if zona == "alta" \
                else ("%s barato" % num)
    elif zona == "normal":
        lectura = "ratio dentro del rango"
    return {"estar_en": estar_en, "lectura": lectura, "moneda": moneda,
            "tenencia": saldos or {}}


def saldos_tenencia():
    """Cantidad de cada especie, sumando los brokers. Sale de `tenencia`.

    Una sola consulta para todas las tarjetas del panel.
    """
    try:
        filas = db.conn().execute(
            "SELECT simbolo, SUM(cantidad) FROM tenencia "
            "GROUP BY simbolo").fetchall()
        return {r[0]: r[1] for r in filas if r[1]}
    except Exception as e:
        log.debug("saldos de tenencia: %s", e)
        return {}


def _cerca_del_borde(par, ratio, est, umbral=0.15):
    """Devuelve 'alta', 'baja' o None si el ratio entró en el tramo final."""
    res = par.get("resistencia") or 0
    sop = par.get("soporte") or 0
    if res > 0 and sop > 0 and res > sop:
        ancho = res - sop
        if ratio >= res - ancho * umbral:
            return "alta"
        if ratio <= sop + ancho * umbral:
            return "baja"
        return None
    if est.get("n", 0) >= MIN_MUESTRA_Z and est.get("desvio"):
        z = (ratio - est["media"]) / est["desvio"]
        if z >= 1.5:
            return "alta"
        if z <= -1.5:
            return "baja"
    return None


def _stats(valores, fuente):
    if len(valores) < 5:
        return {"n": len(valores), "fuente": fuente}
    media = statistics.mean(valores)
    return {
        "n": len(valores),
        "fuente": fuente,
        "media": media,
        "desvio": statistics.pstdev(valores) if len(valores) > 1 else 0.0,
        "min": min(valores),
        "max": max(valores),
    }


def _n(v):
    try:
        return "{:,.2f}".format(float(v)).replace(",", "@").replace(
            ".", ",").replace("@", ".")
    except (TypeError, ValueError):
        return "—"


def _e(v):
    try:
        return "{:,.0f}".format(float(v or 0)).replace(",", ".")
    except (TypeError, ValueError):
        return "—"
