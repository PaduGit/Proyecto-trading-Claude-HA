"""Screener web. Se sirve por Ingress: todas las rutas son relativas."""

import logging
import statistics
import threading
from datetime import datetime, timedelta

from flask import Flask, jsonify, request, send_from_directory

import db
import bonos as BO
import cer as CER
import circuitos as CI
import cobros as COB
import costos as CO
import curva as CU
import historico as H
import opciones as OP
import operaciones as OPS
import posicion as P
import respaldo
import rotacion as RO
from iol import IOLError

log = logging.getLogger("web")


def crear_app(monitor):
    app = Flask(__name__, static_folder="static", static_url_path="")
    try:
        import diario as DI
        DI.configurar([n for n, _ in monitor.cuentas_iol()], monitor.boletos_cfg()["broker"], monitor.cfg)
    except Exception as e:
        log.warning("diario: %s", e)

    @app.after_request
    def sin_cache(resp):
        if resp.mimetype in ("text/html", "application/javascript"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.get("/")
    def index():
        import os
        ruta = os.path.join(app.static_folder, "index.html")
        with open(ruta, encoding="utf-8") as f:
            html = f.read()
        slug = os.environ.get("HOSTNAME", "") or ""
        slug = slug.replace("-", "_") if slug else ""
        # El del contenedor manda: como add-on local el slug es
        # local_ratios_iol y el de la configuracion puede quedar viejo.
        cfg_slug = (slug or monitor.cfg.get("addon_slug") or "").strip()
        html = html.replace(
            "<body>",
            '<body data-slug="%s" data-version="%s">' % (cfg_slug, _version()), 1)
        return app.response_class(html, mimetype="text/html")

    # -- panel --------------------------------------------------------

    @app.get("/api/estado")
    def estado():
        with monitor.lock:
            filas = list(monitor.snapshot.values())
        filas.sort(key=lambda f: (
            0 if f.get("zona") in ("alta", "baja") else 1, f.get("alias", "")))

        # La posicion NO va aca. Este panel es de alertas: un par puede
        # tener sus dos puntas en estrategias distintas o en ninguna, y
        # el mismo numero en dos pantallas se desincroniza. Vive en el
        # panel de la estrategia y en ningun otro lado.

        # La sugerencia se calcula al servir y no en el ciclo: el estado
        # guardado de una version anterior no la traia y fuera de rueda
        # no aparecia hasta la apertura, y la tenencia tiene que ser la
        # de ahora, no la del ultimo ciclo.
        import monitor as MON
        saldos = MON.saldos_tenencia()
        salida = []
        for f in filas:
            out = _limpiar(f)
            if f.get("num") and f.get("den") and f.get("zona"):
                out["sugerencia"] = MON.sugerencia_par(
                    f["num"], f["den"], f["zona"],
                    {s: saldos[s] for s in (f["num"], f["den"]) if s in saldos})
            salida.append(out)

        return jsonify({
            "pares": salida,
            "ciclo": monitor.ultimo_ciclo.isoformat(timespec="seconds")
            if monitor.ultimo_ciclo else None,
            "hace_seg": monitor.segundos_desde_ciclo(),
            "poll_seconds": int(monitor.cfg.get("poll_seconds", 600)),
            "error": monitor.ultimo_error,
            "en_rueda": monitor._en_horario(),
            "hay_rueda": monitor.hay_rueda,
            "snapshot_desde": getattr(monitor, "snapshot_desde", None),
            "sin_cotizacion": getattr(monitor, "sin_cotizacion", []),
            "orleans_fallas": getattr(monitor, "orleans_fallas", []),
            "orleans_descartados": getattr(monitor, "orleans_descartados", []),
            "fuente": getattr(monitor, "fuente", "iol"),
            "fuente_elegida": monitor.fuente_elegida(),
            "canjes": len(getattr(monitor, "canjes", [])),
            "byma_fallas": getattr(monitor, "byma_fallas", []),
        })

    @app.post("/api/refrescar")
    def refrescar():
        with monitor.iol.como("boton"):
            ok, falta = monitor.ciclo_manual()
        if not ok and falta:
            return jsonify({"ok": False,
                            "mensaje": "Esperá %ds antes de volver a pedir."
                                       % falta}), 429
        if not ok:
            return jsonify({"ok": False,
                            "mensaje": "Ya hay un ciclo en curso."}), 409
        return jsonify({"ok": True,
                        "ciclo": monitor.ultimo_ciclo.isoformat(timespec="seconds")})

    @app.get("/api/serie")
    def serie():
        alias = request.args.get("alias", "")
        periodo = request.args.get("periodo", "3m")
        par = monitor.par_por_alias(alias)
        if not par:
            return jsonify({"error": "par desconocido"}), 404

        dias = {"hoy": 1, "5d": 5, "1m": 30, "3m": 90,
                "6m": 180, "1a": 365, "max": 5000}.get(periodo, 90)
        intradiario = periodo in ("hoy", "5d")

        if intradiario:
            desde = (datetime.now() - timedelta(days=dias)).isoformat()
            cond, extra = db.filtro_horario(monitor.horario())
            filas = db.conn().execute(
                "SELECT ts, ratio, p_num, p_den FROM lecturas WHERE alias=? "
                "AND ts>=?" + cond + " ORDER BY ts", [alias, desde] + extra).fetchall()
            puntos = [{"x": f["ts"], "y": f["ratio"],
                       "f": "propia" if f["p_num"] else "iol",
                       "p_num": f["p_num"] or None, "p_den": f["p_den"] or None}
                      for f in filas]
        elif par.get("modo") == "tir":
            # Por TIR la historia diaria sale de bono_hist, no de las
            # lecturas: el par tiene la serie completa desde el alta.
            desde = (datetime.now().date() - timedelta(days=dias)).isoformat()
            puntos = [{"x": x["f"], "y": x["v"], "f": "propia",
                       "tir_num": x["tir_num"], "tir_den": x["tir_den"],
                       "p_num": x["p_num"], "p_den": x["p_den"]}
                      for x in db.serie_tir_detalle(par["num"], par["den"], desde)]
        else:
            desde = (datetime.now().date() - timedelta(days=dias)).isoformat()
            propia = dict(db.serie_propia_diaria(alias, desde,
                                                 monitor.horario()))
            iol = dict(db.serie_ratio_diaria(par["num"], par["den"], desde))
            # Los precios de cada punta ese dia, para la lectura del
            # grafico: de las lecturas propias o de los cierres de IOL.
            pp = db.precios_propios_diarios(alias, desde, monitor.horario())
            cn = {r["fecha"]: r["cierre"] for r in db.cierres_de(par["num"], desde)}
            cd = {r["fecha"]: r["cierre"] for r in db.cierres_de(par["den"], desde)}
            puntos = []
            for f in sorted(set(propia) | set(iol)):
                if f in propia:
                    pn, pd = pp.get(f, (cn.get(f), cd.get(f)))
                    puntos.append({"x": f, "y": propia[f], "f": "propia",
                                   "p_num": pn, "p_den": pd})
                else:
                    puntos.append({"x": f, "y": iol[f], "f": "iol",
                                   "p_num": cn.get(f), "p_den": cd.get(f)})

        n_iol = sum(1 for p in puntos if p["f"] == "iol")
        return jsonify({
            "alias": alias, "puntos": puntos, "periodo": periodo,
            "n_iol": n_iol, "n_propia": len(puntos) - n_iol,
            "resistencia": par.get("resistencia") or 0,
            "soporte": par.get("soporte") or 0,
            "modo": par.get("modo") or "precio",
            "num": par["num"], "den": par["den"],
        })

    # -- calculadora --------------------------------------------------

    @app.get("/api/calc")
    def calc():
        num = (request.args.get("num") or "").strip().upper()
        den = (request.args.get("den") or "").strip().upper()
        mercado = (request.args.get("mercado") or "bCBA").strip()
        plazo = (request.args.get("plazo") or "t1").strip()
        dias = int(request.args.get("dias", 180))

        if not num or not den:
            return jsonify({"error": "Indicá las dos especies."}), 400

        cache = monitor.cotizaciones
        try:
            with monitor.iol.como("pestania"):
                a = cache.get(num) or monitor.iol.cotizacion(mercado, num, plazo)
                b = cache.get(den) or monitor.iol.cotizacion(mercado, den, plazo)
        except IOLError as e:
            return jsonify({"error": str(e)}), 502

        if not a["ref"] or not b["ref"]:
            faltan = num if not a["ref"] else den
            return jsonify({"error": "%s no tiene precio ahora. "
                                     "Revisá el ticker o el plazo." % faltan}), 404

        ratio = a["ref"] / b["ref"]
        for sim in (num, den):
            if not db.ultimo_cierre_guardado(sim):
                _traer_historico(monitor, mercado, sim, dias)

        desde = (datetime.now().date() - timedelta(days=dias)).isoformat()
        serie = db.serie_ratio_diaria(num, den, desde)
        valores = [v for _, v in serie]

        est = {"n": len(valores)}
        if len(valores) >= 5:
            est["media"] = statistics.mean(valores)
            est["desvio"] = statistics.pstdev(valores)
            est["min"] = min(valores)
            est["max"] = max(valores)
            if est["desvio"]:
                est["z"] = (ratio - est["media"]) / est["desvio"]

        db.set_estado("ultimo_par", "%s/%s" % (num, den))
        _recordar_par(num, den, mercado, plazo)

        return jsonify({
            "alias": "%s/%s" % (num, den), "ratio": ratio,
            "num": _p(a), "den": _p(b), "est": est,
            "puntos": [{"x": f, "y": v} for f, v in serie],
        })

    @app.get("/api/recientes")
    def recientes():
        return jsonify({
            "tickers": _tickers_conocidos(),
            "pares": _pares_recientes(),
        })

    # -- arbitraje t0/t1 ----------------------------------------------

    @app.get("/api/arbitraje")
    def arbitraje():
        try:
            with monitor.lock:
                previo = list(monitor.plazos or [])
            if not monitor._en_horario():
                # Fuera de rueda no se pide nunca, aunque no haya previo:
                # el t0 con el mercado cerrado no existe, asi que pedirlo
                # solo gasta cupo para devolver lo mismo.
                filas = previo
            else:
                with monitor.iol.como("pestania"):
                    filas = monitor.evaluar_arbitraje()
        except Exception as e:
            return jsonify({"error": str(e)}), 502
        tasa, origen_tasa = monitor.tasa_caucion()
        return jsonify({
            "filas": filas,
            "hay_rueda": monitor._en_horario(),
            "tasa_origen": origen_tasa,
            "tasa_caucion_anual": tasa,
            "ts": datetime.now().isoformat(timespec="seconds"),
        })

    # -- posicion -----------------------------------------------------

    def _mep():
        """El MEP de la configuracion, o None si no se puede calcular."""
        try:
            return (BO.calcular_mep(
                monitor.cotizaciones_vigentes(),
                monitor.cfg.get("mep_par_pesos") or "AL30",
                monitor.cfg.get("mep_par_usd") or "AL30D"
            ).get("medio") or 0) or None
        except Exception as e:
            log.debug("mep: %s", e)
            return None

    def _precios_vigentes():
        """Precio de referencia de todo lo que ya esta en cache, en pesos.

        No pide nada: se usa al guardar la tenencia, para que el diff
        registre el precio del momento de la foto, y para valuar. Incluye
        las que no operan hace dias: para valuar, un precio viejo es
        mucho mejor que ninguno.

        Lo que cotiza en dolares se pasa a pesos al MEP. Un fondo en
        dolares tiene la cuotaparte en 1,09: sumarla como si fueran 1,09
        pesos no es un error chico, es la posicion entera desaparecida.
        Si no hay MEP se deja afuera y figura sin precio, que avisa.
        """
        mep, out = None, {}
        for sim, c in monitor.cotizaciones_para_valuar().items():
            ref = c.get("ref")
            if not ref:
                continue
            # Solo los fondos, a proposito. Un AO28D tambien cotiza en
            # dolares, pero eso ya viene funcionando asi desde siempre y
            # cambiarlo de paso movería el MEP y la valuacion entera sin
            # haberlo verificado. Un FCI no tenia precio hasta ahora:
            # ahi no hay comportamiento previo que romper.
            if (c.get("instrumento") == "fci"
                    and "dolar" in (c.get("moneda") or "").lower()):
                if mep is None:
                    mep = _mep()
                if not mep:
                    continue
                ref = ref * mep
            out[sim] = ref
        return out

    def _precios_para(grupo):
        """Precio de referencia de cada ticker del grupo.

        Fuera de rueda no se pide nada: con el mercado cerrado el ticker
        que falta va a seguir faltando, y pedirlo uno por uno en cada
        visita a Posicion era de lo que mas consumia.
        """
        precios = {}
        cache = monitor.cotizaciones_vigentes()
        abierto = monitor._en_horario()
        for tk in grupo["tickers"]:
            c = cache.get(tk)
            if not c and abierto:
                try:
                    with monitor.iol.como("pestania"):
                        c = monitor.iol.cotizacion(
                            grupo.get("mercado") or "bCBA", tk)
                except IOLError:
                    continue
            if c and c.get("ref"):
                precios[tk] = c["ref"]
        return precios

    @app.get("/api/grupos")
    def listar_grupos():
        # Un grupo es la definicion de un par para alertar: num, den y los
        # umbrales. Nada de posicion, que es de la estrategia.
        salida = []
        for g in db.listar_grupos():
            salida.append({
                "id": g["id"], "nombre": g["nombre"], "base": g["base"],
                "tickers": g["tickers"], "mercado": g["mercado"],
                "num": g.get("num"), "den": g.get("den"),
                "plazo": g.get("plazo"), "resistencia": g.get("resistencia"),
                "soporte": g.get("soporte"), "factor": g.get("factor"),
                "alertas": bool(g.get("alertas", 1)),
                "modo": g.get("modo") or "precio",
                "precios": _precios_para(g),
            })
        return jsonify(salida)

    @app.post("/api/grupos")
    def nuevo_grupo():
        d = request.get_json(silent=True) or {}
        nombre = (d.get("nombre") or "").strip()
        base = (d.get("base") or "").strip().upper()
        tickers = [t.strip().upper() for t in (d.get("tickers") or [])
                   if t and t.strip()]
        if not nombre:
            return jsonify({"error": "Poné un nombre al grupo."}), 400
        if len(tickers) != 2:
            return jsonify({"error": "Un par tiene exactamente dos tickers."}), 400
        if base not in tickers:
            return jsonify({"error": "La base tiene que ser uno de los tickers."}), 400
        if any(g["nombre"].lower() == nombre.lower() for g in db.listar_grupos()):
            return jsonify({"error": "Ya existe un par con ese nombre."}), 400
        gid = db.crear_grupo(nombre, base, tickers,
                             (d.get("mercado") or "bCBA").strip())
        db.actualizar_par(gid, _campos_par(d, tickers))
        _tarjeta_al_dia(gid)
        return jsonify({"ok": True, "id": gid})

    def _tarjeta_al_dia(gid):
        """Sin esto la tarjeta esperaba al proximo ciclo. Si falla, el
        par igual quedo guardado: no se corta la respuesta."""
        try:
            monitor.evaluar_uno(gid)
        except Exception as e:
            log.warning("tarjeta del par %s: %s", gid, e)

    def _campos_par(d, tickers):
        """Numerador, denominador y zonas. Por defecto el ratio va en el
        orden en que se cargaron los tickers."""
        num = (d.get("num") or tickers[0]).strip().upper()
        den = (d.get("den") or tickers[1]).strip().upper()
        def _f(k):
            try:
                v = float(d.get(k))
                return v or None
            except (TypeError, ValueError):
                return None
        res, sop = _f("resistencia"), _f("soporte")
        if res and sop and res <= sop:
            res = sop = None      # niveles invertidos: no sirven
        modo = "tir" if (d.get("modo") or "") == "tir" else "precio"
        return {"num": num, "den": den, "modo": modo,
                "plazo": (d.get("plazo") or "t1").strip(),
                "resistencia": res, "soporte": sop,
                "factor": _f("factor"),
                "alertas": 1 if d.get("alertas", True) else 0}

    @app.post("/api/grupos/<int:gid>")
    def editar_grupo(gid):
        d = request.get_json(silent=True) or {}
        g = db.grupo_por_id(gid)
        if not g:
            return jsonify({"error": "No existe."}), 404
        tickers = [t.strip().upper() for t in (d.get("tickers") or g["tickers"])
                   if t and t.strip()]
        if len(tickers) != 2:
            return jsonify({"error": "Un par tiene exactamente dos tickers."}), 400
        campos = _campos_par(d, tickers)
        if d.get("nombre"):
            campos["nombre"] = d["nombre"].strip()
        base = (d.get("base") or g["base"]).strip().upper()
        if base not in tickers:
            return jsonify({"error": "La base tiene que ser uno de los tickers."}), 400
        campos["base"] = base
        if d.get("mercado"):
            campos["mercado"] = d["mercado"].strip()
        db.actualizar_par(gid, campos)
        if tickers != g["tickers"]:
            db.actualizar_tickers(gid, tickers)
        _tarjeta_al_dia(gid)
        return jsonify({"ok": True})

    @app.delete("/api/grupos/<int:gid>")
    def eliminar_grupo(gid):
        db.borrar_grupo(gid)
        _tarjeta_al_dia(gid)
        return jsonify({"ok": True})

    # -- bonos --------------------------------------------------------

    _cache_bonos = {"ts": None, "datos": None}
    VIDA_CACHE = 20          # segundos
    _sin_precio = set()      # especies que IOL no cotiza: no insistir

    def _cot_bonos():
        """Cotizaciones de las especies con cronograma.

        Casi todo viene del panel del último ciclo. Lo que no vino se pide
        suelto, con dos cuidados: se cachea unos segundos —entre dos
        aperturas seguidas los precios no cambiaron— y se deja de insistir
        con las que IOL no cotiza.
        """
        ahora = datetime.now()
        c = _cache_bonos
        if c["datos"] is not None and c["ts"] and \
                (ahora - c["ts"]).total_seconds() < VIDA_CACHE:
            return c["datos"]

        # Con la rueda cerrada no se pide nada: los precios no se mueven
        # y cada consulta gasta cupo mensual de la API. Se responde con lo
        # ultimo guardado, marcado como viejo.
        if not monitor._en_horario():
            datos = monitor.cotizaciones_vigentes()
            c["datos"], c["ts"] = datos, ahora
            return datos

        cache = dict(monitor.cotizaciones)
        faltan = [s for s in BO.especies()
                  if s not in cache and s not in _sin_precio]
        # Los paneles cubren los dolarizados y los cinco del canje 2005.
        # Los BONCER sueltos (TZX*, TX28, TX31, X30S6, PBA28) no estan en
        # ningun panel y hay que pedirlos de a uno: el tope tiene que
        # alcanzarlos a todos o los ultimos nunca aparecen.
        for sim in faltan[:30]:
            try:
                with monitor.iol.como("pestania"):
                    cache[sim] = monitor.iol.cotizacion("bCBA", sim, "t1")
            except Exception:
                _sin_precio.add(sim)
                continue     # una especie sin precio no puede tumbar la tabla

        c["ts"], c["datos"] = ahora, cache
        return cache

    @app.post("/api/bonos/reintentar")
    def bonos_reintentar():
        """Vuelve a intentar las especies que quedaron sin precio."""
        n = len(_sin_precio)
        _sin_precio.clear()
        _cache_bonos["datos"] = None
        return jsonify({"reintentadas": n})

    def _cartera_por_especie():
        """Nominales en tenencia por especie, con el detalle por broker.

        Por especie y no por bono: tener AO29 no pone AO29D en cartera.
        """
        out = {}
        try:
            for r in db.conn().execute(
                    "SELECT broker, simbolo, SUM(cantidad) AS c FROM tenencia "
                    "GROUP BY broker, simbolo"):
                if not r["c"] or abs(r["c"]) < 1e-9:
                    continue
                sim = (r["simbolo"] or "").upper()
                e = out.setdefault(sim, {"total": 0.0, "brokers": []})
                e["total"] += r["c"]
                e["brokers"].append({"broker": r["broker"],
                                     "cantidad": r["c"]})
        except Exception as e:
            log.warning("tenencia para bonos: %s", e)
        return out

    def _etiquetar_bonos(filas):
        """Chip de tipo y marca de cartera por fila."""
        try:
            bonos_cfg, _ = BO.cargar()
            esps = BO.especies()
        except Exception as e:
            log.warning("etiquetas de bonos: %s", e)
            return
        cartera = _cartera_por_especie()
        for f in filas:
            info = esps.get(f.get("simbolo"))
            cfg = bonos_cfg.get(info["cronograma"]) if info else None
            f["etiqueta"], f["etiqueta_ayuda"] = BO.etiqueta(cfg, f)
            f["en_cartera"] = bool(cartera.get(f.get("simbolo")))

    @app.get("/api/bonos")
    def bonos_tabla():
        try:
            par = (monitor.cfg.get("mep_par_pesos") or "AL30",
                   monitor.cfg.get("mep_par_usd") or "AL30D")
            cer = float(monitor.cfg.get("cer_actual") or 0)
            t = BO.tabla(_cot_bonos(), par_mep=par, cer_actual=cer)
            _etiquetar_bonos(t["filas"])
            try:
                an = CU.analizar(t["filas"])
                for f in t["filas"]:
                    f.update(an.get(f["simbolo"]) or {})
            except Exception as e:
                log.warning("curva: %s", e)
            return jsonify(t)
        except Exception as e:
            log.exception("tabla de bonos")
            return jsonify({"error": str(e)}), 500

    @app.get("/api/bonos/<simbolo>")
    def bono_detalle(simbolo):
        try:
            par = (monitor.cfg.get("mep_par_pesos") or "AL30",
                   monitor.cfg.get("mep_par_usd") or "AL30D")
            cer = float(monitor.cfg.get("cer_actual") or 0)
            cot = _cot_bonos()
            d = BO.detalle(simbolo.upper(), cot, par_mep=par, cer_actual=cer)
            if d:
                d["cartera"] = _cartera_por_especie().get(simbolo.upper())
                try:
                    t = BO.tabla(cot, par_mep=par, cer_actual=cer)
                    an = CU.analizar(t["filas"])
                    d["fila"].update(an.get(simbolo.upper()) or {})
                except Exception as e:
                    log.debug("curva en detalle: %s", e)
        except Exception as e:
            log.exception("detalle de bono")
            return jsonify({"error": str(e)}), 500
        if not d:
            return jsonify({"error": "no tengo cronograma de %s" % simbolo}), 404
        return jsonify(d)

    @app.get("/api/circuitos")
    def circuitos_ver():
        try:
            cot = _cot_bonos()
            bonos_cfg, _ = BO.cargar()
            esps = BO.especies()
            # Un bono sirve, como origen y como puente, si cotiza en pesos
            # y en MEP. Sin las dos puntas no hay salto posible: el PARP
            # solo cotiza en pesos, así que venderlo y recomprarlo paga su
            # propio spread sin convertir nada.
            puentes = [b for b in bonos_cfg if (b + "D") in esps]
            tengo = monitor.tengo_actual()
            # los bonos declarados se suman al universo aunque les falte
            # alguna especie: pueden ser origen aunque no sean intermedios
            universo = sorted(set(puentes) | set(tengo.get("bonos") or []))
            # El ciclo ya lo calculo: recalcular aca solo repetiria
            # trabajo sobre las mismas cotizaciones.
            with monitor.lock:
                previo = dict(monitor.circuitos or {})
            if previo and not monitor._en_horario():
                r = previo
            else:
                r = CI.analizar(cot, universo, tengo,
                                monitor.cfg.get("comisiones") or {},
                                float(monitor.cfg.get("rulo_umbral_pct") or 0),
                                monitor.cfg.get("derechos_mercado") or {},
                                monitor.cfg.get("iva_pct") or 0,
                                CO.esquema(monitor.cfg),
                                min_monto=monitor._min_monto(),
                                mep=monitor._mep(cot))
            r["tengo"] = tengo
            r["candidatos"] = sorted(puentes)
            return jsonify(r)
        except Exception as e:
            log.exception("circuitos")
            return jsonify({"error": str(e)}), 500

    @app.get("/api/rulo")
    def rulo_tabla():
        try:
            umbral = float(monitor.cfg.get("rulo_umbral_pct") or 0.6)
            return jsonify(BO.rulo(_cot_bonos(), umbral,
                                   min_monto=monitor._min_monto()))
        except Exception as e:
            log.exception("rulo")
            return jsonify({"error": str(e)}), 500

    def _cierres_subyacente(sim, mercado="bCBA"):
        """Cierres para las medias. Se rellenan desde IOL una vez por día."""
        from datetime import date, timedelta
        desde = (date.today() - timedelta(days=90)).isoformat()
        ultimo = db.ultimo_cierre_guardado(sim)
        if not db._en_bono_hist(sim) and monitor._en_horario() and (
                not ultimo
                or ultimo < (date.today() - timedelta(days=1)).isoformat()):
            try:
                with monitor.iol.como("pestania"):
                    serie = monitor.iol.serie(mercado, sim, desde,
                                              date.today().isoformat())
                filas = []
                for p in serie or []:
                    f = str(p.get("fechaHora") or "")[:10]
                    c = p.get("ultimoPrecio") or p.get("cierre")
                    if f and c:
                        filas.append((f, float(c)))
                if filas:
                    db.guardar_cierres(sim, filas)
            except Exception as e:
                log.debug("cierres de %s: %s", sim, e)
        return [(r["fecha"], r["cierre"]) for r in db.cierres_de(sim, desde)]

    @app.get("/api/opciones")
    def opciones_tabla():
        try:
            cfg = monitor.cfg
            series, spots, diag, viejo, desde = monitor.cadena_opciones()
            par = monitor.parametros_opciones()
            cierres = {s: _cierres_subyacente(s) for s in spots}
            tasa, origen_tasa = monitor.tasa_caucion()
            r = OP.analizar(series, spots, par,
                            cfg.get("comisiones") or {}, cierres,
                            cfg.get("derechos_mercado") or {},
                            cfg.get("iva_pct") or 0, tasa)
            r["tasa_origen"] = origen_tasa
            marcas = db.opc_marcas()
            abiertas = {p["combo"] for p in db.opc_posiciones(abiertas=True)}
            for f in r["filas"]:
                m = marcas.get(f["id"]) or {}
                f["seguida"] = bool(m)
                f["silenciada"] = bool(m.get("silenciada"))
                f["con_posicion"] = f["id"] in abiertas
            r["diagnostico"] = {k: v for k, v in diag.items() if k != "muestra"}
            r["parametros"] = par
            r["viejo"] = viejo
            r["desde"] = desde
            r["sin_puntas"] = diag["con_puntas"] == 0
            r["nunca_hubo"] = viejo is False and diag["con_puntas"] == 0
            r["hay_rueda"] = monitor.hay_rueda
            # La cadena para el desplegable: por subyacente y vencimiento,
            # una fila por base con las puntas de la call y de la put.
            cad = {}
            for sr in series or []:
                if not sr.get("base") or sr.get("tipo") not in ("CALL", "PUT"):
                    continue
                k = "%s|%s" % (sr.get("subyacente"), sr.get("vencimiento"))
                fila = cad.setdefault(k, {}).setdefault(sr["base"], {"base": sr["base"]})
                pre = "c" if sr["tipo"] == "CALL" else "p"
                fila[pre + "_compra"] = sr.get("compra")
                fila[pre + "_venta"] = sr.get("venta")
            r["cadena"] = {k: sorted(v.values(), key=lambda x: x["base"])
                           for k, v in cad.items()}
            return jsonify(r)
        except Exception as e:
            log.exception("opciones")
            return jsonify({"error": str(e)}), 500

    @app.get("/api/opciones/subyacente/<sim>")
    def opciones_subyacente(sim):
        """Un año de cierres del subyacente y su volatilidad de 6 meses,
        para el grafico de OPCIONES. Las medias las calcula la pantalla."""
        import escenarios as ES
        sim = (sim or "").strip().upper()
        serie = ES.serie_cierres(monitor.iol, "bCBA", sim)
        vol = ES.volatilidad([v for _, v in serie], "precio")
        out = {"simbolo": sim, "serie": serie, "vol_hist": vol}
        if len(serie) < 21:
            out["error"] = "Sin historia suficiente del subyacente."
        return jsonify(out)

    @app.get("/api/opciones/historico/<combo>")
    def opciones_historico(combo):
        return jsonify(db.opc_serie(combo))

    @app.post("/api/opciones/marcar/<combo>")
    def opciones_marcar(combo):
        d = request.get_json(silent=True) or {}
        if "seguir" in d:
            db.opc_seguir(combo, bool(d["seguir"]))
        if "silenciar" in d:
            db.opc_silenciar(combo, bool(d["silenciar"]))
        return jsonify((db.opc_marcas().get(combo) or {"combo": combo}))

    @app.get("/api/opciones/posiciones")
    def opciones_posiciones():
        try:
            series, spots, _, viejo, desde = monitor.cadena_opciones()
            par = monitor.parametros_opciones()
        except Exception:
            series, spots, viejo, desde = [], {}, True, None
            par = monitor.parametros_opciones()
        # Los lotes y el riesgo se rehacen con lo que hay en la cuenta.
        # Lo cargado a mano queda de respaldo: si el broker no informa
        # alguna pata o falta un PPC, se sigue viendo lo que habia.
        tenencias = db.tenencias()
        salida = []
        for p in db.opc_posiciones():
            if not p["cerrada_el"]:
                real, avisos = OP.desde_tenencia(
                    p, tenencias, monitor.cfg.get("comisiones") or {},
                    monitor.cfg.get("derechos_mercado") or {},
                    monitor.cfg.get("iva_pct") or 0)
                p["cargado"] = {"lotes": p["lotes"], "riesgo": p["riesgo"]}
                p["lotes_de_tenencia"] = "lotes" in real
                p["riesgo_de_ppc"] = "riesgo" in real
                p.update(real)
                p["avisos"] = avisos
            v = OP.valuar(p, series) if not p["cerrada_el"] else None
            p["valuacion"] = v
            if not p["cerrada_el"]:
                p["motivos"] = OP.motivos_desarme(
                    p, v, spots.get(p["subyacente"]), par)
                p["spot"] = spots.get(p["subyacente"])
            salida.append(p)
        return jsonify({"posiciones": salida, "viejo": viejo, "desde": desde})

    @app.post("/api/opciones/posiciones")
    def opciones_crear():
        d = request.get_json(silent=True) or {}
        faltan = [k for k in ("combo", "subyacente", "estructura",
                              "vencimiento", "base_compra", "base_venta",
                              "riesgo", "ancho") if d.get(k) is None]
        if faltan:
            return jsonify({"error": "faltan datos: %s" % ", ".join(faltan)}), 400
        try:
            pid = db.opc_crear_posicion(d)
        except Exception as e:
            return jsonify({"error": str(e)}), 400
        return jsonify({"id": pid})

    @app.post("/api/opciones/posiciones/<int:pid>")
    def opciones_editar(pid):
        d = request.get_json(silent=True) or {}
        return jsonify({"cambiados": db.opc_actualizar_posicion(pid, d)})

    @app.post("/api/opciones/posiciones/<int:pid>/cerrar")
    def opciones_cerrar(pid):
        d = request.get_json(silent=True) or {}
        if d.get("precio_salida") is None:
            return jsonify({"error": "falta el precio de salida"}), 400
        try:
            salida = float(d["precio_salida"])
        except (TypeError, ValueError):
            return jsonify({"error": "precio de salida invalido"}), 400
        pos = next((p for p in db.opc_posiciones() if p["id"] == pid), None)
        if not pos:
            return jsonify({"error": "no existe"}), 404
        # el resultado sale del precio realmente ejecutado, no del teorico
        if pos["estructura"] == "BEAR_CALL":
            gan = (pos["ancho"] - pos["riesgo"]) + salida
        else:
            gan = salida - pos["riesgo"]
        total = round(gan * OP.LOTE * (pos["lotes"] or 1), 2)
        db.opc_cerrar_posicion(pid, salida, total)
        return jsonify({"id": pid, "resultado": total})

    @app.post("/api/opciones/posiciones/<int:pid>/borrar")
    def opciones_borrar(pid):
        return jsonify({"borradas": db.opc_borrar_posicion(pid)})

    @app.get("/api/opciones/crudo")
    def opciones_crudo():
        """Una serie tal cual la manda IOL, para ver qué campos trae."""
        try:
            subs = [s.strip().upper()
                    for s in (monitor.cfg.get("opc_subyacentes")
                              or "GGAL").split(",") if s.strip()]
            _, diag = OP.cadena(monitor.iol, subs)
            return jsonify(diag)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    # -- alertas de precio y tenencias --------------------------------

    @app.get("/api/alertas-precio")
    def alertas_precio_listar():
        cot = monitor.cotizaciones_vigentes()
        out = []
        for a in db.alertas_precio():
            a["estado"] = monitor.evaluar_alerta(a, cot)
            out.append(a)
        return jsonify({"alertas": out, "hay_rueda": monitor._en_horario()})

    @app.post("/api/alertas-precio")
    def alertas_precio_crear():
        d = request.get_json(silent=True) or {}
        if not (d.get("condiciones") or []):
            return jsonify({"error": "hace falta al menos una condición"}), 400
        return jsonify({"id": db.guardar_alerta_precio(d, d.get("id"))})

    @app.post("/api/alertas-precio/<int:aid>/activar")
    def alertas_precio_activar(aid):
        d = request.get_json(silent=True) or {}
        db.activar_alerta_precio(aid, bool(d.get("activa", True)))
        monitor._precio_avisado.discard(aid)
        return jsonify({"id": aid, "activa": bool(d.get("activa", True))})

    @app.post("/api/alertas-precio/<int:aid>/borrar")
    def alertas_precio_borrar(aid):
        monitor._precio_avisado.discard(aid)
        return jsonify({"borradas": db.borrar_alerta_precio(aid)})

    @app.get("/api/alertas-fecha")
    def alertas_fecha_listar():
        from datetime import date as _d
        hoy = _d.today()
        out = []
        for a in db.alertas_fecha():
            try:
                f = _d.fromisoformat(str(a["fecha"])[:10])
                a["dias"] = (f - hoy).days
            except ValueError:
                a["dias"] = None
            out.append(a)
        return jsonify({"alertas": out})

    @app.post("/api/alertas-fecha")
    def alertas_fecha_crear():
        d = request.get_json(silent=True) or {}
        if not str(d.get("fecha") or "").strip():
            return jsonify({"error": "falta la fecha"}), 400
        return jsonify({"id": db.guardar_alerta_fecha(d, d.get("id"))})

    @app.post("/api/alertas-fecha/<int:aid>/activar")
    def alertas_fecha_activar(aid):
        d = request.get_json(silent=True) or {}
        db.activar_alerta_fecha(aid, bool(d.get("activa", True)))
        return jsonify({"id": aid})

    @app.post("/api/alertas-fecha/<int:aid>/borrar")
    def alertas_fecha_borrar(aid):
        return jsonify({"borradas": db.borrar_alerta_fecha(aid)})

    @app.get("/api/tenencias/<sim>/escenarios")
    def tenencia_escenarios(sim):
        """Historia de 6 meses, volatilidad y niveles para el grafico de
        escenarios de la ficha. Precio en pesos, en US$ de NY si los
        niveles estan en ese modo, o TIR para la renta fija."""
        import escenarios as ES
        import gestion as GE
        sim = (sim or "").strip().upper()
        filas = [t for t in db.tenencias() if t["simbolo"] == sim]
        if not filas:
            return jsonify({"error": "no está en la tenencia"}), 404
        tipo = (filas[0].get("tipo") or "").lower()
        if tipo in ("moneda", "fci"):
            return jsonify({"error": "sin gráfico para este tipo"}), 400
        niv = GE.config()["niveles"].get(sim) or {}
        es_rf = tipo in ("bonos", "letras", "on", "bcra")
        modo = "ny" if niv.get("modo") == "ny" else \
            "tir" if (es_rf and niv.get("modo") != "precio") else "precio"
        # Gestion pide el grafico en el modo que se esta editando, aunque
        # todavia no este guardado (y con el ticker de NY que se escribio).
        pedido = (request.args.get("modo") or "").strip().lower()
        if pedido in ("precio", "tir", "ny") and (pedido != "tir" or es_rf):
            modo = pedido
        if request.args.get("ny"):
            niv = dict(niv, ny=request.args.get("ny").strip().upper())
        out = {"simbolo": sim, "tipo": tipo}
        serie, v0 = [], None

        if modo == "tir":
            st = ES.serie_tir(sim)
            if len(st) >= 20:
                tm = _tir_md().get(sim) or (None, None)
                v0 = tm[0] if tm[0] is not None else st[-1][1]
                serie = [(f, t) for f, t, _ in st]
                out.update(md=tm[1] if tm[1] else st[-1][2],
                           curva=ES.tir_curva(sim, v0))
            else:
                modo = "precio"     # sin historia de TIR: se grafica el precio
        if modo == "ny":
            pny = GE.precios_ny().get(sim) or {}
            tk = (niv.get("ny") or pny.get("ticker") or GE.ticker_ny(sim, tipo) or sim).upper()
            if pny.get("ticker") != tk or not pny.get("mercado"):
                # ticker nuevo (se esta editando): se cotiza una vez para
                # saber el mercado y el precio
                mer, p = GE.cotizar_ny(monitor.iol, tk)
                pny = {"ticker": tk, "mercado": mer, "precio": p} if mer else {}
            serie = ES.serie_cierres(monitor.iol, pny.get("mercado") or "nYSE",
                                     tk, "NY:" + tk) if pny else []
            v0 = pny.get("precio") or (serie[-1][1] if serie else None)
            if not pny:
                out["error"] = "Sin cotización en NY para %s." % tk
            out.update(ticker_ny=tk, precio_fecha=pny.get("fecha"))
        if modo == "precio":
            serie = ES.serie_cierres(monitor.iol, "bCBA", sim)
            cot = monitor.cotizaciones_para_valuar().get(sim) or {}
            v0 = cot.get("ultimo") or cot.get("ref") or (serie[-1][1] if serie else None)
            if not es_rf:
                # PPC en la misma unidad que el precio: el de la valuacion,
                # ponderado por cantidad entre brokers. En bonos se omite:
                # el PPC puede venir por lamina o por unidad.
                try:
                    r, _m = _valuar_completa()
                    ps = [p for p in r.get("posiciones") or []
                          if p.get("simbolo") == sim and p.get("ppc") and p.get("cantidad")]
                    q = sum(p["cantidad"] for p in ps)
                    if q:
                        out["ppc"] = sum(p["ppc"] * p["cantidad"] for p in ps) / q
                except Exception as e:
                    log.debug("ppc de %s: %s", sim, e)

        vol = ES.volatilidad([v for _, v in serie], modo)
        out.update(modo=modo, serie=serie, hoy=v0, vol=vol)
        if niv.get("modo", "precio") == modo:
            out["stop"], out["obj"] = niv.get("stop"), niv.get("obj")
        if not serie or not v0 or not vol:
            out.setdefault("error", "Sin historia suficiente para estimar escenarios.")
        return jsonify(out)

    @app.get("/api/tenencias")
    def tenencias_listar():
        fuera = monitor.brokers_extranjeros()
        filas = db.tenencias()
        for f in filas:
            f["extranjero"] = f["broker"].upper() in fuera
        return jsonify({
            "tenencias": filas,
            "brokers_extranjeros": sorted(fuera),
            "en_rulo": monitor.tengo_actual(),
        })

    # -- boletos (Veta) -----------------------------------------------

    def _boletos_vista():
        import boletos as BOL
        bc = monitor.boletos_cfg()
        estr = [{"id": e["id"], "nombre": e["nombre"], "familia": e["familia"]}
                for e in db.estrategias()]
        return {"broker": bc["broker"],
                "configurado": bool(bc["carpeta"] and bc["clave"]),
                "fuente": BOL.estado_fuente(),
                "vista": BOL.preparar(bc["broker"]),
                "informativos": BOL.informativos(bc["broker"]),
                "estrategias": estr, "motivos": list(BOL.MOTIVOS)}

    @app.get("/api/boletos")
    def boletos_ver():
        try:
            return jsonify(_boletos_vista())
        except Exception as e:
            log.exception("boletos")
            return jsonify({"error": str(e)}), 500

    @app.post("/api/boletos/revisar")
    def boletos_revisar():
        try:
            r = monitor.revisar_boletos()
            if r is None:
                return jsonify({"error": "Falta configurar la carpeta de Drive y la clave de Google en el add-on."}), 400
            out = _boletos_vista()
            out["revision"] = r
            return jsonify(out)
        except Exception as e:
            return jsonify({"error": str(e)}), 502

    @app.post("/api/boletos/subir")
    def boletos_subir():
        import base64 as _b64
        import boletos as BOL
        d = request.get_json(silent=True) or {}
        try:
            datos = _b64.b64decode(d.get("datos") or "")
        except Exception:
            return jsonify({"error": "El archivo no llegó bien."}), 400
        if not datos.startswith(b"%PDF"):
            return jsonify({"error": "No es un PDF."}), 400
        try:
            leidos, nuevos = BOL.cargar_pdf(datos, (d.get("nombre") or "boletos.pdf")[:120],
                                            monitor.boletos_cfg()["broker"])
        except Exception as e:
            return jsonify({"error": "No se pudo leer el PDF: %s" % e}), 400
        out = _boletos_vista()
        out["revision"] = {"boletos": nuevos, "leidos": leidos}
        return jsonify(out)

    @app.post("/api/boletos/aplicar")
    def boletos_aplicar():
        import boletos as BOL
        d = request.get_json(silent=True) or {}
        precios = {}
        for sim, cv in (monitor.cotizaciones_para_valuar() or {}).items():
            p = (cv or {}).get("ultimo") or (cv or {}).get("ref")
            if p:
                precios[sim] = p
        try:
            r = BOL.aplicar(monitor.boletos_cfg()["broker"], d.get("decisiones") or {},
                            precios, d.get("rotacion"))
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        except Exception as e:
            log.exception("boletos aplicar")
            return jsonify({"error": str(e)}), 500
        out = _boletos_vista()
        out["resultado"] = r
        return jsonify(out)

    @app.post("/api/boletos/descartar")
    def boletos_descartar():
        import boletos as BOL
        d = request.get_json(silent=True) or {}
        n = BOL.descartar(monitor.boletos_cfg()["broker"], d.get("claves"))
        out = _boletos_vista()
        out["descartados"] = n
        return jsonify(out)

    @app.post("/api/tenencias")
    def tenencias_cargar():
        d = request.get_json(silent=True) or {}
        filas = d.get("tenencias")
        if not isinstance(filas, list):
            return jsonify({"error": "falta la lista 'tenencias'"}), 400
        n = db.guardar_tenencias(filas, d.get("reemplazar") or "todo",
                                 _precios_vigentes())
        return jsonify({"cargadas": n, "en_rulo": monitor.tengo_actual()})

    @app.post("/api/tenencias/una")
    def tenencia_editar():
        d = request.get_json(silent=True) or {}
        br, sim = (d.get("broker") or "").strip(), (d.get("simbolo") or "").strip()
        if not br or not sim:
            return jsonify({"error": "faltan el broker o el símbolo"}), 400
        campos = d.get("campos") or {}
        try:
            n = db.actualizar_tenencia(br, sim, campos)
        except (TypeError, ValueError) as e:
            return jsonify({"error": str(e)}), 400
        if not n:
            return jsonify({"error": "no se encontró esa posición"}), 404

        # Alta de estrategia en el mismo paso. La fecha de alta es la de
        # la compra y no la de hoy: de ahi sale el valor del patron
        # contra el que se va a medir.
        nueva = d.get("estrategia_nueva")
        eid = None
        if nueva and (nueva.get("nombre") or "").strip():
            datos = dict(nueva)
            datos.setdefault("origen", "cargada desde %s" % sim)
            try:
                eid = db.guardar_estrategia(datos)
            except (TypeError, ValueError) as e:
                return jsonify({"error": str(e), "guardada": True}), 400
            if campos.get("fecha_alta"):
                db.fijar_alta(eid, campos["fecha_alta"])
            db.asignar(sim, eid)
        return jsonify({"actualizadas": n, "estrategia_id": eid,
                        "en_rulo": monitor.tengo_actual()})

    @app.delete("/api/tenencias/una")
    def tenencia_borrar():
        br = (request.args.get("broker") or "").strip()
        sim = (request.args.get("simbolo") or "").strip()
        if not br or not sim:
            return jsonify({"error": "faltan el broker o el símbolo"}), 400
        return jsonify({"borradas": db.borrar_tenencia(br, sim),
                        "en_rulo": monitor.tengo_actual()})

    @app.get("/api/movimientos-propuestos")
    def propuestos_listar():
        eid = request.args.get("estrategia_id")
        return jsonify({"propuestos": db.movimientos_propuestos(
            request.args.get("estado") or "pendiente",
            int(eid) if (eid or "").isdigit() else None)})

    @app.get("/api/movimientos-propuestos/<int:mid>/candidatos")
    def propuestos_candidatos(mid):
        """Con que otra propuesta se puede unir esta.

        Una rotacion hecha en dos cuentas -vende en una, compra en la
        otra- sale como un retiro y un aporte sueltos. Unirlas es lo que
        evita que la cuota se mueva por una operacion que no cambio el
        capital.
        """
        return jsonify({"candidatos": db.candidatos_a_unir(mid)})

    @app.post("/api/movimientos-propuestos/<int:mid>")
    def propuestos_resolver(mid):
        d = request.get_json(silent=True) or {}
        unir = d.get("unir_con")
        try:
            r = db.resolver_propuesto(
                mid, d.get("accion") or "confirmar",
                d.get("editado"), int(unir) if unir else None)
        except (TypeError, ValueError) as e:
            return jsonify({"error": str(e)}), 400
        if not r:
            return jsonify({"error": "no existe"}), 404
        return jsonify({"estado": r})

    @app.get("/api/estrategias")
    def estrategias_listar():
        # La posicion viaja adentro de cada estrategia y en ningun otro
        # endpoint. Los precios salen del cache: esto no pide nada.
        precios = _precios_vigentes()
        lista = db.estrategias(
            incluir_cerradas=request.args.get("cerradas") == "1",
            familia=request.args.get("familia") or None)
        for e in lista:
            try:
                e["posicion"] = P.resumen(e, precios)
            except Exception as ex:
                log.debug("posicion de %s: %s", e["id"], ex)
                e["posicion"] = None
        return jsonify({
            "estrategias": lista,
            # El patron dejo de depender de la familia, asi que la clave
            # ya no existe y esto reventaba con KeyError. En su lugar van
            # la pestaña y los tipos esperados, que es lo que el front
            # necesita para armar la tarjeta y avisar la familia cruzada.
            "familias": [{"id": k, "nombre": v["nombre"],
                          "pestana": v["pestana"],
                          "tipos": list(v["tipos"]),
                          "campos": list(v["campos"])}
                         for k, v in db.FAMILIAS.items()],
            "patrones": list(db.PATRONES),
            "grupos": [{"id": g["id"], "nombre": g["nombre"]}
                       for g in db.listar_grupos()],
        })

    @app.post("/api/estrategias")
    def estrategias_guardar():
        d = request.get_json(silent=True) or {}
        try:
            eid = db.guardar_estrategia(d, d.get("id"))
        except (TypeError, ValueError) as e:
            return jsonify({"error": str(e)}), 400
        return jsonify({"id": eid})

    @app.get("/api/estrategias/<int:eid>/evolucion")
    def estrategias_evolucion(eid):
        return jsonify({"evolucion": db.evolucion(eid)})

    # -- posicion y ledger de la estrategia ---------------------------
    # Todo esto colgaba del grupo. Un grupo es un par para alertar; la
    # posicion, el capital aportado y la cuota son de la estrategia, que
    # es la que sobrevive a la rotacion.

    def _estrategia(eid):
        for e in db.estrategias(incluir_cerradas=True):
            if e["id"] == eid:
                return e
        return None

    @app.get("/api/estrategias/<int:eid>/posicion")
    def estrategias_posicion(eid):
        e = _estrategia(eid)
        if not e:
            return jsonify({"error": "estrategia desconocida"}), 404
        return jsonify(P.resumen(e, _precios_vigentes()))

    @app.get("/api/estrategias/<int:eid>/movimientos")
    def estrategias_movimientos(eid):
        e = _estrategia(eid)
        if not e:
            return jsonify({"error": "estrategia desconocida"}), 404
        precios = _precios_vigentes()
        return jsonify({
            "movimientos": [{
                "id": m["id"], "ts": m["ts"], "tipo": m["tipo"],
                "ticker_de": m["ticker_de"], "cant_de": m["cant_de"],
                "ticker_a": m["ticker_a"], "cant_a": m["cant_a"],
                "ratio_base": m["ratio_base"],
                "equiv_antes": m["equiv_antes"],
                "propuesto_id": m["propuesto_id"], "nota": m["nota"],
            } for m in reversed(db.movimientos_estrategia(eid))],
            "curva": P.curva(e, precios),
            "resumen": P.resumen(e, precios),
        })

    @app.post("/api/estrategias/<int:eid>/movimientos")
    def estrategias_mov_nuevo(eid):
        e = _estrategia(eid)
        if not e:
            return jsonify({"error": "estrategia desconocida"}), 404
        precios = _precios_vigentes()
        limpio, error = P.validar_movimiento(e, request.get_json(silent=True)
                                             or {}, precios)
        if error:
            return jsonify({"error": error}), 400
        mid = db.registrar_mov_manual(eid, limpio)
        return jsonify({"ok": True, "id": mid,
                        "resumen": P.resumen(e, precios)})

    @app.delete("/api/estrategias/movimientos/<int:mid>")
    def estrategias_mov_borrar(mid):
        db.borrar_mov_estrategia(mid)
        return jsonify({"ok": True})

    @app.post("/api/estrategias/<int:eid>/sembrar")
    def estrategias_sembrar(eid):
        """Carga como aporte inicial lo que ya figura en la tenencia.

        La cuotaparte necesita un punto de partida. El equivalente sale
        del precio de ahora y se puede pisar por especie: la plata entro
        el dia que entro, no hoy. Con `simular` en true no escribe nada y
        devuelve lo que propondria, que es lo que la tarjeta muestra para
        que se corrija antes de confirmar.
        """
        e = _estrategia(eid)
        if not e:
            return jsonify({"error": "estrategia desconocida"}), 404
        if not e.get("ticker_base"):
            return jsonify({"error": "la estrategia no tiene ticker base: "
                                     "sin eso no hay en qué medir"}), 400
        d = request.get_json(silent=True) or {}
        # `rearmar`: la estrategia ya tiene ledger pero no cuadra con la
        # tenencia. Se borra y se vuelve a sembrar con lo de hoy; el
        # rendimiento acumulado se pierde y arranca de nuevo en 0.
        rearmar = bool(d.get("rearmar"))
        if db.movimientos_estrategia(eid) and not rearmar:
            return jsonify({"error": "la estrategia ya tiene movimientos"}), 400
        pisar = {(k or "").upper(): v
                 for k, v in (d.get("equivalentes") or {}).items()}
        precios = _precios_vigentes()
        sal = P.saldos(eid)
        if not sal:
            return jsonify({"error": "ninguna especie de la estrategia "
                                     "está en la tenencia"}), 400

        base = e["ticker_base"]
        propuesta, faltan, acum = [], [], 0.0
        for sim, v in sorted(sal.items()):
            eq = pisar.get(sim)
            try:
                eq = float(eq) if eq is not None else None
            except (TypeError, ValueError):
                eq = None
            if eq is None:
                eq = P.equiv_de(sim, v["cantidad"], base, precios, sal)
            if not eq:
                faltan.append(sim)
                continue
            propuesta.append({"simbolo": sim, "cantidad": v["cantidad"],
                              "equivalente": eq, "equiv_antes": acum})
            acum += eq
        if faltan and not propuesta:
            return jsonify({"error": "sin precio para %s: cargá el "
                                     "equivalente a mano"
                                     % ", ".join(faltan)}), 400
        if d.get("simular"):
            return jsonify({"propuesta": propuesta, "faltan_precio": faltan,
                            "ticker_base": base, "rearmar": rearmar})

        if rearmar:
            n = db.borrar_ledger(eid)
            log.info("estrategia %s: ledger rearmado (%d movimientos borrados)",
                     eid, n)
        for a in propuesta:
            db.registrar_mov_manual(eid, {
                "tipo": "aporte", "ticker_a": a["simbolo"],
                "cant_a": a["cantidad"], "ratio_base": a["equivalente"],
                "equiv_antes": a["equiv_antes"] or None,
                "nota": "tenencia inicial"})
        return jsonify({"sembrados": propuesta, "faltan_precio": faltan,
                        "resumen": P.resumen(e, precios)})

    @app.get("/api/estrategias/revisar")
    def estrategias_revisar():
        """Lo que la app sospecha y no aplica sola.

        Estaba escrito en db y no lo leia nadie: media funcionalidad.
        """
        return jsonify({"cruzadas": db.especies_cruzadas(),
                        "cierres": db.cierres_sugeridos()})

    @app.delete("/api/estrategias/<int:eid>")
    def estrategias_borrar(eid):
        return jsonify({"borradas": db.borrar_estrategia(eid)})

    @app.post("/api/estrategias/<int:eid>/cerrar")
    def estrategias_cerrar(eid):
        d = request.get_json(silent=True) or {}
        if d.get("reabrir"):
            db.reabrir_estrategia(eid)
        else:
            db.cerrar_estrategia(eid, (d.get("motivo") or "manual"))
        return jsonify({"ok": True})

    @app.post("/api/estrategias/asignar")
    def estrategias_asignar():
        # La asignacion es por simbolo y no por broker: la misma especie
        # en dos cuentas es una sola posicion de una sola estrategia. El
        # broker se sigue aceptando y se ignora, para no romper la
        # pantalla vieja mientras se saca.
        d = request.get_json(silent=True) or {}
        sim = (d.get("simbolo") or "").strip()
        if not sim:
            return jsonify({"error": "falta el símbolo"}), 400
        db.asignar(sim, d.get("estrategia_id") or None)
        return jsonify({"ok": True})

    @app.post("/api/estrategias/limpiar")
    def estrategias_limpiar():
        return jsonify({"borradas": db.borrar_vacias()})

    @app.post("/api/estrategias/auto")
    def estrategias_auto():
        """Crea una estrategia por grupo de rotacion y le asigna sus
        especies. Nunca pisa una asignacion hecha a mano."""
        return jsonify({"asignadas": db.asignar_por_grupos()})

    @app.get("/api/tenencias/historial")
    def tenencias_historial():
        return jsonify({
            "historial": db.historial_tenencia(
                request.args.get("broker"), request.args.get("simbolo"),
                request.args.get("desde")),
            "fechas": db.fechas_snapshot(request.args.get("broker")),
        })

    @app.get("/api/eventos")
    def eventos_listar():
        return jsonify({"eventos": db.eventos(request.args.get("simbolo"))})

    @app.post("/api/eventos")
    def eventos_crear():
        d = request.get_json(silent=True) or {}
        try:
            eid = db.guardar_evento(d.get("simbolo"), d.get("fecha"),
                                    d.get("factor"), d.get("nota"))
        except (TypeError, ValueError) as e:
            return jsonify({"error": str(e)}), 400
        return jsonify({"id": eid})

    @app.delete("/api/eventos/<int:eid>")
    def eventos_borrar(eid):
        return jsonify({"borrados": db.borrar_evento(eid)})

    # IOL agrupa por tipo de instrumento y no lo escribe siempre igual:
    # "TIT. PUBLICOS", "TitulosPublicos" y "titulos publicos" son el
    # mismo tipo. Se compara sin puntos, espacios ni acentos, buscando la
    # raiz adentro del texto.
    TIPO_IOL = (
        ("cedear", "cedears"),
        ("obligacion", "on"),
        ("negociable", "on"),
        ("letra", "letras"),
        ("titulopublico", "bonos"),
        ("titulospublicos", "bonos"),
        ("titpublico", "bonos"),
        ("publico", "bonos"),
        ("bono", "bonos"),
        ("accion", "acciones"),
        ("fondo", "fci"),
        ("fci", "fci"),
    )

    def _tipo_iol(txt):
        import unicodedata
        t = unicodedata.normalize("NFKD", str(txt or ""))
        t = "".join(ch for ch in t if not unicodedata.combining(ch))
        t = "".join(ch for ch in t.lower() if ch.isalnum())
        for clave, valor in TIPO_IOL:
            if clave in t:
                return valor
        return "otros"

    def _bajar_cuenta(cli, nombre):
        """Baja titulos y efectivo de una cuenta de IOL.

        Devuelve las filas listas para guardar. No escribe: el que llama
        decide, porque cada cuenta se reemplaza por separado y una que
        falla no tiene que impedir que la otra se cargue.
        """
        filas, vacios, deudas = [], [], []
        with cli.como("boton"):
            for pais in ("argentina", "estados_Unidos"):
                d = cli.portafolio(pais)
                # la respuesta trae los titulos bajo "activos" o bajo
                # "positions" segun la version; se aceptan las dos
                activos = ((d or {}).get("activos")
                           or (d or {}).get("positions") or [])
                if not activos:
                    vacios.append(pais)
                for a in activos:
                    t = (a or {}).get("titulo") or (a or {}).get("asset") or {}
                    sim = (t.get("simbolo") or t.get("symbol")
                           or "").strip().upper()
                    try:
                        cant = float(a.get("cantidad")
                                     or a.get("quantity") or 0)
                    except (TypeError, ValueError):
                        cant = 0
                    if not sim or not cant:
                        continue
                    tipo = _tipo_iol(t.get("tipo") or t.get("type")
                                     or a.get("tipo"))
                    filas.append({"broker": nombre, "simbolo": sim,
                                  "cantidad": cant, "tipo": tipo})

        # El portafolio trae solo titulos; el efectivo sale de otro
        # endpoint. Sin el disponible por moneda, el Rulo no sabe con que
        # se cuenta para partir desde una moneda.
        monedas = []
        try:
            with cli.como("boton"):
                ec = cli.estado_cuenta()
            for cu in (ec or {}).get("cuentas") or []:
                tipo_cta = (cu.get("tipo") or "").lower()
                if "estados_unidos" in tipo_cta:
                    sim = "CABLE"          # dolar que liquida afuera
                elif "dolares" in tipo_cta:
                    sim = "MEP"            # dolar que liquida local
                elif "pesos" in tipo_cta:
                    sim = "ARS"
                else:
                    continue
                # La suma de los disponibles por plazo, no el campo
                # "disponible" de la cuenta: ese ultimo netea lo
                # comprometido de una compra contra el saldo inmediato y
                # llega a dar negativo con dinero en la cuenta. Lo que
                # liquida en 24 o 48 horas igual sirve para operar, solo
                # que con esa fecha.
                monto, por_plazo = 0.0, []
                for sa in cu.get("saldos") or []:
                    try:
                        v = float(sa.get("disponible") or 0)
                    except (TypeError, ValueError):
                        continue
                    if not v:
                        continue
                    monto += v
                    por_plazo.append("%s %s" % (
                        sa.get("liquidacion") or "?", round(v, 2)))
                if not por_plazo:
                    # Sin desglose por plazo se cae al campo de la
                    # cuenta, que es mejor que no informar nada.
                    try:
                        monto = float(cu.get("disponible")
                                      or cu.get("saldo") or 0)
                    except (TypeError, ValueError):
                        monto = 0
                if not monto:
                    continue
                filas.append({"broker": nombre, "simbolo": sim,
                              "cantidad": monto, "tipo": "moneda"})
                monedas.append("%s %s%s" % (
                    sim, round(monto, 2),
                    " (" + " · ".join(por_plazo) + ")" if len(por_plazo) > 1
                    else ""))
                if monto < 0:
                    # No se descarta: si el saldo da negativo con el
                    # campo correcto, es un dato que hay que ver y no
                    # algo para tragarse en silencio.
                    deudas.append("%s %s" % (sim, round(monto, 2)))
        except IOLError as e:
            log.warning("estado de cuenta de %s: %s", nombre, e)
        return filas, vacios, monedas, deudas

    def _cuentas_iol():
        """Las cuentas configuradas, en orden. La segunda es opcional."""
        return monitor.cuentas_iol()

    @app.post("/api/iol/estadocuenta")
    def iol_estado_cuenta():
        """La respuesta cruda, sin interpretar.

        El registro de llamadas guarda ruta, estado y demora, pero no el
        cuerpo. Sin esto, cuando un saldo no cierra no hay donde mirar.
        """
        salida = []
        for nombre, cli in _cuentas_iol():
            try:
                with cli.como("boton"):
                    salida.append({"broker": nombre, "respuesta":
                                   cli.estado_cuenta()})
            except IOLError as e:
                salida.append({"broker": nombre, "error": str(e)})
        return jsonify({"cuentas": salida})

    @app.post("/api/iol/operaciones")
    def iol_operaciones():
        """La respuesta cruda de las operaciones, sin interpretar.

        De aca tienen que salir las fechas de alta, el PPC exacto y las
        comisiones reales. Primero se mira que devuelve: armar el
        importador contra un formato supuesto es como se metieron las
        TIR de 152%.
        """
        d = request.get_json(silent=True) or {}
        desde = (d.get("desde") or "").strip() or None
        hasta = (d.get("hasta") or "").strip() or None
        salida = []
        for nombre, cli in _cuentas_iol():
            try:
                with cli.como("boton"):
                    salida.append({"broker": nombre,
                                   "respuesta": cli.operaciones(desde, hasta)})
            except IOLError as e:
                salida.append({"broker": nombre, "error": str(e)})
        return jsonify({"cuentas": salida})

    @app.post("/api/iol/operaciones/altas")
    def iol_altas():
        """Reconstruye fecha de alta y PPC desde las operaciones.

        Con `aplicar` en false -el default- no escribe nada: devuelve que
        cierra y que no. Solo se guarda lo que cierra: si la cantidad que
        sale de las operaciones no es la que figura hoy, la fecha de alta
        es de otra posicion, y una fecha mal puesta arrastra el ajuste
        por evento societario y la medicion desde el origen.
        """
        d = request.get_json(silent=True) or {}
        desde = (d.get("desde") or "").strip() or None
        hasta = (d.get("hasta") or "").strip() or None
        aplicar = bool(d.get("aplicar"))
        pisar = bool(d.get("pisar"))
        salida = []
        for nombre, cli in _cuentas_iol():
            try:
                with cli.como("boton"):
                    ops = cli.operaciones(desde, hasta)
            except IOLError as e:
                salida.append({"broker": nombre, "error": str(e)})
                continue
            if not isinstance(ops, list):
                salida.append({"broker": nombre,
                               "error": "respuesta inesperada"})
                continue
            ten = db.tenencias(nombre)
            rec = OPS.reconstruir(ops, [t["simbolo"] for t in ten],
                                  mep_de=BO.mep_al, eventos_de=db.eventos)
            r = OPS.conciliar(rec, ten)
            r["broker"] = nombre
            r["operaciones"] = len(ops)
            # La mas vieja que trajo la consulta. Si es posterior a lo
            # que se pidio, el rango no llego tan atras y varias de las
            # que "dan menos de lo que hay" son solo eso.
            fechas = [str(o.get("fechaOperada") or "")[:10] for o in ops]
            r["desde_real"] = min([f for f in fechas if f] or [""])
            if aplicar:
                escritas = 0
                for f in r["cierran"]:
                    campos = {"fecha_alta": f["fecha_alta"],
                              "precision": "exacta"}
                    # La posicion puede estar en dos filas -AO29 y
                    # AO29D-: el alta es la misma para las dos.
                    destinos = f.get("filas") or [f["simbolo"]]
                    # El PPC cargado a mano no se pisa salvo que se pida:
                    # el de las operaciones va sin comisiones y el tuyo
                    # puede ser mejor.
                    for sim in destinos:
                        actual = next((t for t in ten
                                       if t["simbolo"] == sim), None)
                        campos_sim = dict(campos)
                        if f["ppc"] and (pisar
                                         or not (actual or {}).get("ppc")):
                            campos_sim["ppc"] = f["ppc"]
                            campos_sim["ppc_base"] = 1
                        # El PPC en dolares va aparte: es una columna que
                        # no existia y no hay nada cargado a mano que
                        # respetar. Atado al de pesos, no se escribia
                        # nunca en las posiciones que ya tenian PPC.
                        #
                        # El que sale del reconstructor es por unidad,
                        # pero `ppc_base` es una sola para los dos PPC:
                        # si el de pesos no se pisa, la fila conserva su
                        # base y el de dolares tiene que entrar en esa
                        # misma unidad, no en la suya.
                        if f.get("ppc_usd") and (pisar
                                                 or not (actual or {}).get("ppc_usd")):
                            b = (1 if campos_sim.get("ppc_base") == 1
                                 else ((actual or {}).get("ppc_base") or 1))
                            campos_sim["ppc_usd"] = f["ppc_usd"] * b
                        try:
                            db.actualizar_tenencia(nombre, sim, campos_sim)
                            escritas += 1
                        except (TypeError, ValueError) as e:
                            log.warning("alta %s: %s", sim, e)
                r["escritas"] = escritas
            salida.append(r)
        return jsonify({"cuentas": salida, "aplicado": aplicar})

    @app.get("/api/fci/buscar")
    def fci_buscar():
        """Busca un fondo en CAFCI por nombre, para atarlo a un simbolo.

        Hay fondos con cuatro clases y nombres casi iguales; elegir mal
        la clase da un precio parecido y equivocado, que es peor que no
        tener ninguno. Por eso se elige de una lista y no se escribe.
        """
        import cafci
        q = (request.args.get("q") or "").strip()
        if len(q) < 3:
            return jsonify({"fondos": [], "aviso": "escribí al menos 3 letras"})
        try:
            return jsonify({"fondos": cafci.buscar(q)[:25]})
        except Exception as e:
            log.warning("buscar fci: %s", e)
            return jsonify({"error": "no se pudo consultar CAFCI"}), 502

    @app.post("/api/tenencias/traer")
    def tenencias_traer():
        """Baja la tenencia de las cuentas de IOL y las carga.

        Cada cuenta reemplaza solo su propio broker: las cargadas a mano
        y la del exterior quedan intactas. Si una cuenta falla, la otra
        se carga igual y el error se informa aparte.
        """
        pedido = (request.args.get("broker") or "").strip()
        cuentas = _cuentas_iol()
        if pedido:
            cuentas = [c for c in cuentas if c[0] == pedido] or \
                      [(pedido, monitor.iol)]
        resultados, errores = [], []
        for nombre, cli in cuentas:
            try:
                filas, vacios, monedas, deudas = _bajar_cuenta(cli, nombre)
            except IOLError as e:
                errores.append("%s: %s" % (nombre, e))
                continue
            if not filas:
                errores.append("%s: no devolvió posiciones" % nombre)
                continue
            n = db.guardar_tenencias(filas, nombre, _precios_vigentes())
            resultados.append({
                "broker": nombre, "cargadas": n,
                "sin_posiciones": vacios, "monedas": monedas,
                "deudas": deudas,
                "sin_clasificar": sorted({f["simbolo"] for f in filas
                                          if f["tipo"] == "otros"}),
            })
        if not resultados:
            return jsonify({"error": " · ".join(errores)
                            or "IOL no devolvió posiciones"}), 502
        primero = resultados[0]
        # Los campos sueltos quedan por compatibilidad: son los de la
        # primera cuenta, que es la principal.
        return jsonify({"cuentas": resultados, "errores": errores,
                        "cargadas": sum(r["cargadas"] for r in resultados),
                        "broker": primero["broker"],
                        "sin_posiciones": primero["sin_posiciones"],
                        "sin_clasificar": primero["sin_clasificar"],
                        "monedas": primero["monedas"],
                        "deudas": primero["deudas"],
                        "en_rulo": monitor.tengo_actual()})

    @app.get("/api/canjes")
    def canjes_listar():
        """Contra que conviene rotar cada bono que se tiene.

        Por defecto devuelve lo que dejo el ultimo ciclo, que es lo mismo
        que ya se aviso por notificacion. Recalcular la curva entera en
        cada visita seria repetir un trabajo hecho.
        """
        if request.args.get("recalcular") == "1":
            try:
                filas = monitor.canjes_curva()
            except Exception as e:
                log.warning("canjes: %s", e)
                return jsonify({"error": str(e)}), 500
        else:
            filas = getattr(monitor, "canjes", [])
        return jsonify({"canjes": filas,
                        "calculado": monitor.ultimo_ciclo.isoformat(
                            timespec="seconds") if monitor.ultimo_ciclo else None,
                        "minimo": float(monitor.cfg.get("canje_min_pct") or 1)})

    @app.post("/api/rotacion")
    def rotacion_calcular():
        """La orden concreta de una rotacion propuesta.

        La misma cuenta para un canje de curva y para un par de ratios:
        se vende al bid de la que sale, se compra al ask de la que entra
        y las comisiones de las dos patas salen de `costos`. Sin
        `cantidad` se rota toda la tenencia de la especie que sale.
        """
        d = request.get_json(silent=True) or {}
        try:
            r = RO.calcular(
                d.get("sale"), d.get("entra"), d.get("cantidad"),
                monitor.cotizaciones_para_valuar(), db.tenencias(),
                monitor.cfg.get("comisiones") or {},
                monitor.cfg.get("derechos_mercado") or {},
                monitor.cfg.get("iva_pct") or 0,
                mep=_mep())
        except Exception as e:
            log.exception("rotacion")
            return jsonify({"error": str(e)}), 500
        return jsonify(r), (400 if r.get("error") else 200)

    @app.post("/api/precios/por-especie")
    def precios_por_especie():
        """Pide las cotizaciones de a una, hasta que la API frena.

        No corre solo: consume el cupo de la cuenta que hace el ciclo, y
        para valuar alcanza con BYMA. Es para cuando hay que operar y los
        veinte minutos de retraso no sirven.
        """
        try:
            n = monitor.repuesto_por_especie()
        except Exception as e:
            log.warning("por especie: %s", e)
            return jsonify({"error": str(e)}), 502
        return jsonify({"precios": n, "fuente": getattr(monitor, "fuente", "")})

    @app.post("/api/fuente")
    def fijar_fuente():
        """Cambia la fuente de precios sin reiniciar el add-on."""
        d = request.get_json(silent=True) or {}
        v = (d.get("fuente") or "").strip().lower()
        if v not in ("auto", "iol", "byma"):
            return jsonify({"error": "auto, iol o byma"}), 400
        monitor._fuente_forzada = None if v == "auto" else v
        return jsonify({"elegida": monitor.fuente_elegida(),
                        "usando": getattr(monitor, "fuente", "iol")})

    @app.post("/api/byma/panel")
    def byma_panel():
        """Respuesta cruda de un panel, sin interpretar.

        Mismo criterio que el estado de cuenta de IOL: cuando un numero
        no cierra hace falta ver de que campo salio, y el registro de
        llamadas guarda ruta y estado pero nunca el cuerpo.
        """
        import byma as BY
        d = request.get_json(silent=True) or {}
        inst = (d.get("panel") or "titulosPublicos").strip()
        if inst not in BY.PANELES:
            return jsonify({"error": "panel desconocido",
                            "paneles": sorted(BY.PANELES)}), 400
        cli = BY.Byma(verificar_ssl=bool(monitor.cfg.get("byma_verificar_ssl")))
        try:
            filas = cli.panel(inst, d.get("plazo") or None)
        except BY.BymaError as e:
            return jsonify({"error": str(e), "url": BY.BASE + BY.PANELES[inst],
                            "metodo": "POST"}), 502
        n = int(d.get("filas") or 3)
        simbolo = (d.get("simbolo") or "").strip().upper()
        if simbolo:
            filas = [f for f in filas
                     if (f.get("symbol") or "").upper() == simbolo]
        return jsonify({
            "panel": inst, "total": len(filas),
            "url": BY.BASE + BY.PANELES[inst],
            "plazos": sorted({str(f.get("settlementType") or "")
                              for f in filas}),
            "campos": sorted(filas[0].keys()) if filas else [],
            "filas": filas[:max(1, min(n, 25))],
        })

    def _valuar_completa():
        """La cartera entera valuada con lo que hay en cache. La usan la
        pestaña y la foto diaria del monitor."""
        import cartera as CA
        import bonos as BO
        filas = db.tenencias()
        fuera = monitor.brokers_extranjeros()
        for f in filas:
            f["extranjero"] = f["broker"].upper() in fuera
        precios = _precios_vigentes()
        try:
            bonos_cfg, _ = BO.cargar()
        except Exception:
            bonos_cfg = {}
        cache = monitor.cotizaciones_vigentes()
        mep = None
        try:
            mep = (BO.calcular_mep(
                cache, monitor.cfg.get("mep_par_pesos") or "AL30",
                monitor.cfg.get("mep_par_usd") or "AL30D"
            ).get("medio") or 0) or None
        except Exception:
            pass
        r = CA.valuar(filas, precios, mep, bonos_cfg,
                      meta=monitor.cotizaciones_para_valuar(),
                      estrategias_=db.estrategias())
        return r, mep

    def _foto_cartera():
        from datetime import date as _d
        r, mep = _valuar_completa()
        if not r.get("total"):
            return 0
        return db.guardar_cartera_hist(_d.today().isoformat(),
                                       r.get("posiciones") or [], mep)

    # El monitor la llama a diario, despues del cierre.
    monitor.foto_cartera = _foto_cartera

    def _tir_md():
        """{simbolo: (TIR, MD)} de la tabla de BONOS con los precios en cache."""
        import bonos as BO
        out = {}
        try:
            t = BO.tabla(monitor.cotizaciones_vigentes(),
                         cer_actual=float(monitor.cfg.get("cer_actual") or 0))
            for f in t.get("filas") or []:
                if f.get("tir_last") is not None:
                    out[f["simbolo"]] = (f["tir_last"], f.get("md"))
        except Exception as e:
            log.debug("tabla de bonos: %s", e)
        return out

    # -- diario de trading ---------------------------------------------

    def _diario_vista(sincronizar=True):
        import diario as DI
        cuentas = [n for n, _ in monitor.cuentas_iol()]
        bol = monitor.boletos_cfg()["broker"]
        DI.configurar(cuentas, bol, monitor.cfg)
        if sincronizar:
            DI.sincronizar_local()
        pos = DI.posiciones(_precios_vigentes(), _mep())
        return {"posiciones": pos, "pendientes": DI.pendientes(pos),
                "estrategias": [{"id": e["id"], "nombre": e["nombre"],
                                 "familia": e["familia"], "cerrada": bool(e.get("cierre"))}
                                for e in db.estrategias(incluir_cerradas=True)],
                "motivos": list(DI.MOTIVOS), "estado": DI.estado(cuentas, bol),
                "hoy": datetime.now().date().isoformat()}

    @app.get("/api/diario")
    def diario_ver():
        try:
            return jsonify(_diario_vista())
        except Exception as e:
            log.exception("diario")
            return jsonify({"error": str(e)}), 500

    @app.post("/api/diario/importar")
    def diario_importar():
        try:
            r = monitor.sincronizar_diario()
            out = _diario_vista(sincronizar=False)
            out["importacion"] = r
            return jsonify(out)
        except Exception as e:
            log.exception("diario importar")
            return jsonify({"error": str(e)}), 500

    @app.post("/api/diario/op")
    def diario_op():
        import diario as DI
        d = request.get_json(silent=True) or {}
        try:
            DI.guardar_op(str(d.get("ref") or ""), d)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        return jsonify(_diario_vista(sincronizar=False))

    @app.post("/api/diario/pos")
    def diario_pos():
        import diario as DI
        d = request.get_json(silent=True) or {}
        try:
            DI.guardar_pos(str(d.get("ref") or ""), d)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        return jsonify(_diario_vista(sincronizar=False))

    @app.get("/api/gestion")
    def gestion_ver():
        import gestion as GE
        try:
            r, _mep = _valuar_completa()
        except Exception as e:
            return jsonify({"error": str(e)}), 500
        return jsonify(GE.calcular(r.get("posiciones") or [], _tir_md()))

    @app.post("/api/gestion")
    def gestion_guardar():
        import gestion as GE
        d = request.get_json(silent=True) or {}
        GE.guardar(d)
        # Un nivel nuevo en NY se cotiza en el momento: sin precio, el riel
        # y el riesgo quedarian vacios hasta las 12 del dia siguiente.
        nuevos = [s for s, n in (d.get("niveles") or {}).items()
                  if n and n.get("modo") == "ny"]
        if nuevos:
            try:
                GE.actualizar_ny(monitor.iol, solo=nuevos)
            except Exception as e:
                log.warning("precio en NY de %s: %s", ", ".join(nuevos), e)
        return gestion_ver()

    @app.post("/api/gestion/importar")
    def gestion_importar():
        """Niveles pegados como JSON. Con `simular` devuelve la vista previa
        sin guardar; sin el, guarda solo lo valido y en cartera."""
        import gestion as GE
        import json as _json
        d = request.get_json(silent=True) or {}
        datos = d.get("datos")
        if isinstance(datos, str):
            try:
                datos = _json.loads(datos)
            except ValueError as e:
                return jsonify({"error": "El texto no es un JSON válido: %s" % e}), 400
        en_cartera = {t["simbolo"] for t in db.tenencias()
                      if float(t.get("cantidad") or 0) != 0}
        try:
            filas, validos = GE.revisar_importacion(datos, en_cartera)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        if d.get("simular") or not validos:
            return jsonify({"filas": filas, "guardados": 0})
        GE.guardar({"niveles": validos})
        ny = [s for s, n in validos.items() if n["modo"] == "ny"]
        if ny:
            try:
                GE.actualizar_ny(monitor.iol, solo=ny)
            except Exception as e:
                log.warning("precios de NY al importar: %s", e)
        return jsonify({"filas": filas, "guardados": len(validos)})

    @app.get("/api/gestion/niveles")
    def gestion_niveles():
        """Solo los niveles y cuales estan tocados: TENENCIAS los dibuja en
        el riel de cada posicion y no necesita valuar la cartera entera."""
        import gestion as GE
        return jsonify({"niveles": GE.config()["niveles"],
                        "tocados": GE.tocados(), "ny": GE.precios_ny()})

    # El monitor revisa los niveles en cada ciclo de rueda.
    monitor.tir_md_bonos = _tir_md

    @app.get("/api/inicio")
    def inicio():
        """Todo lo que la solapa de Inicio muestra, en un pedido. Cada parte
        falla por separado: sin MEP o sin cartera, el resto sale igual."""
        import bonos as BO
        from datetime import date as _d
        out = {"en_rueda": monitor._en_horario(),
               "hace_seg": monitor.segundos_desde_ciclo(),
               "fallas": list(getattr(monitor, "orleans_fallas", []) or [])}
        c = db.conn()
        # mercado
        merc = {}
        try:
            cache = monitor.cotizaciones_vigentes()
            m = BO.calcular_mep(cache, monitor.cfg.get("mep_par_pesos") or "AL30",
                                monitor.cfg.get("mep_par_usd") or "AL30D")
            merc["mep"] = m.get("medio")
            ccl = BO.calcular_mep(cache, monitor.cfg.get("mep_par_pesos") or "AL30",
                                  "AL30C").get("medio") if "AL30C" in cache else None
            merc["ccl"] = ccl
            if ccl and merc["mep"]:
                merc["canje_pct"] = (ccl / merc["mep"] - 1) * 100
            ayer = (_d.today() - timedelta(days=1))
            mep_ayer = BO.mep_al(ayer.isoformat())
            if mep_ayer and merc.get("mep"):
                merc["mep_var_pct"] = (merc["mep"] / mep_ayer - 1) * 100
        except Exception as e:
            log.debug("inicio mercado: %s", e)
        for t in ("cer", "tamar", "badlar", "a3500"):
            try:
                r = c.execute("SELECT fecha, valor FROM %s ORDER BY fecha DESC "
                              "LIMIT 2" % t).fetchall()
                if r:
                    merc[t] = {"fecha": r[0]["fecha"], "valor": r[0]["valor"],
                               "anterior": r[1]["valor"] if len(r) > 1 else None}
            except Exception:
                pass
        out["mercado"] = merc
        # cartera: total y variacion contra la ultima foto anterior a hoy
        try:
            r, mep = _valuar_completa()
            hoy = _d.today().isoformat()
            prev = c.execute("SELECT fecha, SUM(valor) v, SUM(valor_usd) u FROM "
                             "cartera_hist WHERE fecha < ? GROUP BY fecha ORDER BY "
                             "fecha DESC LIMIT 1", (hoy,)).fetchone()
            tot = r.get("total")
            out["cartera"] = {
                "total": tot, "total_usd": (tot / mep) if (tot and mep) else None,
                "resultado_pct": r.get("resultado_pct"),
                "resultado_usd_pct": r.get("resultado_usd_pct"),
                "desde": prev["fecha"] if prev else None,
                "var_pct": ((tot / prev["v"] - 1) * 100) if (prev and prev["v"] and tot) else None,
                "var_usd_pct": (((tot / mep) / prev["u"] - 1) * 100)
                if (prev and prev["u"] and tot and mep) else None,
            }
        except Exception as e:
            log.debug("inicio cartera: %s", e)
            out["cartera"] = None
        # movimientos para confirmar
        try:
            props = db.movimientos_propuestos()
            out["movimientos"] = [{"tipo": m["tipo"], "sale": m.get("sale"),
                                   "entra": m.get("entra"), "broker": m.get("broker")}
                                  for m in props]
        except Exception:
            out["movimientos"] = []
        # stops y objetivos tocados
        try:
            import gestion as GE
            out["niveles"] = GE.tocados()
        except Exception:
            out["niveles"] = {}
        # cobros de la semana
        try:
            out["cobros"] = COB.proximos(
                dias=7, cer_actual=float(monitor.cfg.get("cer_actual") or 0),
                brokers_fuera=monitor.brokers_extranjeros())
        except Exception as e:
            log.debug("inicio cobros: %s", e)
            out["cobros"] = []
        return jsonify(out)

    @app.get("/api/cartera/evolucion")
    def cartera_evolucion():
        # La primera vez, una foto de hoy para que la serie arranque.
        try:
            if not db.conn().execute("SELECT 1 FROM cartera_hist LIMIT 1").fetchone():
                _foto_cartera()
        except Exception as e:
            log.warning("primera foto de cartera: %s", e)
        return jsonify({"puntos": db.evolucion_cartera(
            (request.args.get("broker") or "").strip() or None,
            (request.args.get("exposicion") or "").strip() or None)})

    @app.get("/api/cartera")
    def cartera_valuada():
        import cartera as CA
        import bonos as BO
        filas = db.tenencias()
        fuera = monitor.brokers_extranjeros()
        for f in filas:
            f["extranjero"] = f["broker"].upper() in fuera
        # Solo lo que ya esta en cache: valuar no justifica una rueda de
        # requests por cada visita a la pestania.
        cache = monitor.cotizaciones_vigentes()
        precios = _precios_vigentes()
        try:
            bonos_cfg, _ = BO.cargar()
        except Exception as e:
            log.warning("bonos.yaml para la cartera: %s", e)
            bonos_cfg = {}
        mep = None
        try:
            mep = (BO.calcular_mep(
                cache, monitor.cfg.get("mep_par_pesos") or "AL30",
                monitor.cfg.get("mep_par_usd") or "AL30D"
            ).get("medio") or 0) or None
        except Exception as e:
            log.debug("mep para la cartera: %s", e)

        # La medicion de estrategias va siempre sobre la cartera entera:
        # filtrada por broker daria el rendimiento de media estrategia,
        # que no significa nada.
        # `meta` trae del panel la descripcion y la marca de precio
        # viejo; `estrs` deja medir cada tenencia contra el patron de su
        # estrategia sin tener que volver a leer la base por fila.
        meta = monitor.cotizaciones_para_valuar()
        estrs = db.estrategias()
        completa = CA.valuar(filas, precios, mep, bonos_cfg,
                             meta=meta, estrategias_=estrs)

        # Los mismos filtros que la lista: al mirar un solo broker o un
        # solo tipo, el total y los pesos tienen que ser de eso.
        br = (request.args.get("broker") or "").strip()
        tp = (request.args.get("tipo") or "").strip().lower()
        fa = (request.args.get("familia") or "").strip().lower()
        ex = (request.args.get("exposicion") or "").strip()
        if br:
            filas = [f for f in filas if f["broker"] == br]
        if tp:
            filas = [f for f in filas if (f.get("tipo") or "otros") == tp]
        if ex:
            # La exposición no está en la tenencia: sale de bonos.yaml,
            # así que hay que calcularla para poder filtrar por ella.
            filas = [f for f in filas
                     if CA.exposicion(f, bonos_cfg) == ex]
        if fa == "_sin":
            filas = [f for f in filas if not f.get("estrategia_id")]
        elif fa:
            filas = [f for f in filas if f.get("familia") == fa]
        r = (completa if not (br or tp or fa or ex)
             else CA.valuar(filas, precios, mep, bonos_cfg,
                            meta=meta, estrategias_=estrs))
        try:
            r["estrategias"] = CA.medir(db.estrategias(),
                                        completa["posiciones"])
            # Se guarda antes de que la estrategia pueda cerrarse: es el
            # unico momento en que todavia hay tenencia con que medir.
            db.guardar_medicion(r["estrategias"])
        except Exception as e:
            log.warning("medición de estrategias: %s", e)
            r["estrategias"] = []
        # Las exposiciones de la cartera entera: los chips no se pueden
        # armar con las del subconjunto o al filtrar quedaria una sola y
        # no habria como volver.
        r["exposiciones"] = [e["nombre"] for e in completa["por_exposicion"]]
        # La composicion siempre de la cartera entera: es el control con
        # que se filtra, y filtrada mostraria un solo tramo.
        r["composicion"] = {"exposicion": completa["por_exposicion"],
                            "broker": completa["por_broker"],
                            "total": completa.get("total")}
        por_sim = {}
        for f in completa.get("posiciones") or []:
            if f.get("valor") and (f.get("tipo") or "") != "moneda":
                por_sim[f["simbolo"]] = por_sim.get(f["simbolo"], 0) + f["valor"]
        tot = completa.get("total") or 0
        r["concentracion"] = [
            {"simbolo": k, "valor": v, "pct": v / tot * 100 if tot else 0}
            for k, v in sorted(por_sim.items(), key=lambda x: -x[1])[:5]]
        # Sin precios, decir por que: si los paneles estan caidos no es
        # que falte esperar el proximo ciclo.
        r["fallas"] = list(getattr(monitor, "orleans_fallas", []) or [])
        # Las que se valuaron con un precio de dias anteriores. El total
        # no miente por omision, pero conviene saber de que esta hecho.
        viejas = getattr(monitor, "_viejas", None) or {}
        r["precios_viejos"] = sorted(
            {f["simbolo"]: viejas[f["simbolo"]].get("ultima_operacion")
             for f in (r.get("posiciones") or [])
             if f["simbolo"] in viejas}.items())
        return jsonify(r)

    @app.get("/api/cobros")
    def cobros_listar():
        try:
            dias = int(request.args.get("dias", 365))
        except ValueError:
            dias = 365
        try:
            filas = COB.proximos(
                dias=dias,
                cer_actual=float(monitor.cfg.get("cer_actual") or 0),
                incluir_extranjeros=request.args.get("todos") == "1",
                brokers_fuera=monitor.brokers_extranjeros())
        except Exception as e:
            log.exception("cobros")
            return jsonify({"error": str(e)}), 500
        # No tener pagos en la ventana no es no tener cronograma: un bono
        # que vence en 2029 no paga nada en 90 dias y esta perfectamente
        # cargado. Se mira contra el universo de especies.
        esps = set(BO.especies())
        sin_cronograma = sorted(
            {t["simbolo"] for t in db.tenencias()
             if t["cantidad"] and t["simbolo"] not in esps
             and (t.get("tipo") or "") in ("bonos", "letras", "on", "bcra")})
        return jsonify({
            "cobros": filas,
            "sin_cronograma": sin_cronograma,
            "dias_aviso": int(monitor.cfg.get("dias_aviso_cobro") or 2),
        })

    @app.get("/api/a3500")
    def a3500_estado():
        """Estado del tipo de cambio oficial, y prueba de la serie.

        El numero de serie del BCRA no esta confirmado contra la
        documentacion: con ?serie=N se puede probar otro sin tocar el
        codigo.
        """
        import dolar as DL
        serie = request.args.get("serie")
        if request.args.get("listar") == "1":
            # el catalogo completo: asi se ve cual es la A3500 sin adivinar
            filas = DL.catalogo()
            cambio = [f for f in filas
                      if "cambio" in f["descripcion"].lower()
                      or "3500" in f["descripcion"]]
            return jsonify({"series": cambio or filas[:40],
                            "total": len(filas),
                            "detectada": DL.buscar_a3500(),
                            "error": DL.ultimo_error})
        if serie and request.args.get("fijar") == "1":
            DL.fijar_serie(int(serie))
        if request.args.get("probar") == "1":
            DL.reintentar_ya()
            from datetime import date as _d, timedelta as _td
            hasta = _d.today()
            n = DL.descargar((hasta - _td(days=30)).isoformat(),
                             hasta.isoformat(),
                             serie=int(serie) if serie else None)
            return jsonify({"bajados": n, "estado": DL.estado(),
                            "serie_probada": int(serie) if serie else DL.SERIE,
                            "muestra": DL.ultima_respuesta,
                            "error": DL.ultimo_error})
        return jsonify(DL.estado())

    @app.get("/api/cer")
    def cer_estado():
        try:
            bonos_cfg, _ = BO.cargar()
            actual = CER.vigente()
            det = []
            for tk, cfg in bonos_cfg.items():
                if (cfg.get("ajuste") or "").lower() != "cer":
                    continue
                base = cfg.get("cer_base") or CER.base_de(cfg.get("emision"))
                det.append({
                    "ticker": tk, "emision": str(cfg.get("emision"))[:10],
                    "cer_base": base,
                    "factor": (actual / base) if (base and actual) else None,
                })
            return jsonify({"vigente": actual,
                            "rezago_habiles": CER.REZAGO_HABILES,
                            "ultimo_error": CER.ultimo_error,
                            "bonos": det})
        except Exception as e:
            return jsonify({"error": str(e)}), 502

    @app.post("/api/cer/probar")
    def cer_probar():
        """Fuerza una consulta al BCRA y devuelve el error si falla."""
        from datetime import date as _d, timedelta as _t
        CER.reintentar_ya()
        hoy = _d.today()
        n = CER.descargar((hoy - _t(days=30)).isoformat(), hoy.isoformat())
        bonos_cfg, _ = BO.cargar()
        act = CER.vigente()
        det = []
        for tk, cfg in bonos_cfg.items():
            if (cfg.get("ajuste") or "").lower() != "cer":
                continue
            emi = str(cfg.get("emision"))[:10]
            base = cfg.get("cer_base") or CER.base_de(emi)
            det.append("%s emi %s base %s factor %s" % (
                tk, emi, round(base, 2) if base else "?",
                round(act / base, 4) if (base and act) else "?"))
        rango = db.conn().execute(
            "SELECT MIN(fecha) a, MAX(fecha) b, COUNT(*) n FROM cer").fetchone()
        return jsonify({"dias_traidos": n, "vigente": act,
                        "error": CER.ultimo_error,
                        "respuesta": CER.ultima_respuesta,
                        "rango": "%s a %s (%s días)" % (
                            rango["a"], rango["b"], rango["n"]),
                        "bonos": det})

    @app.post("/api/badlar/probar")
    def badlar_probar():
        """Fuerza una consulta al BCRA y devuelve el error si falla."""
        from datetime import date as _d, timedelta as _t
        import badlar as BA
        BA.reintentar_ya()
        hoy = _d.today()
        n = BA.descargar((hoy - _t(days=30)).isoformat(), hoy.isoformat())
        est = BA.resumen()
        bonos_cfg, _ = BO.cargar()
        det = []
        for tk, cfg in bonos_cfg.items():
            var = (cfg.get("interes") or {}).get("variable")
            if not var:
                continue
            v = BA.vigente()
            det.append("%s %s spread %s -> %s" % (
                tk, var.get("fuente"), var.get("spread") or 0,
                round(v + float(var.get("spread") or 0), 4) if v is not None else "sin dato"))
        return jsonify({"dias_traidos": n, "vigente": BA.vigente(),
                        "serie": 7,
                        "error": BA.ultimo_error,
                        "respuesta": BA.ultima_respuesta,
                        "rango": "%s a %s (%s días)" % (
                            est["desde"], est["hasta"], est["dias"])
                        if est["dias"] else None,
                        "bonos": det})

    @app.get("/api/bonos/<simbolo>/historico")
    def bono_historico(simbolo):
        periodo = request.args.get("periodo", "1a")
        dias = {"3m": 90, "6m": 180, "1a": 365, "2a": 730,
                "max": 5000}.get(periodo, 365)
        desde = (datetime.now().date() - timedelta(days=dias)).isoformat()
        try:
            puntos = H.serie(simbolo.upper(), desde)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
        # El z de cada dia, con la ventana que terminaba ese dia: el mismo
        # que usan los avisos. Se calcula con toda la historia aunque se
        # pida un periodo corto.
        try:
            zs = CU.z_historico(simbolo.upper())
            for p in puntos:
                x = zs.get(str(p.get("fecha"))[:10])
                if x:
                    p["residuo"], p["z"] = x
        except Exception as e:
            log.debug("z historico %s: %s", simbolo, e)
        return jsonify({"simbolo": simbolo.upper(), "periodo": periodo,
                        "puntos": puntos})

    @app.post("/api/curva/reconstruir")
    def curva_reconstruir():
        try:
            n = CU.reconstruir()
        except Exception as e:
            log.exception("residuos")
            return jsonify({"error": str(e)}), 500
        r = db.conn().execute(
            "SELECT COUNT(*) n, COUNT(DISTINCT simbolo) esp, "
            "MIN(fecha) a, MAX(fecha) b FROM residuo_hist").fetchone()
        return jsonify({"puntos": n, "total": r["n"], "especies": r["esp"],
                        "desde": r["a"], "hasta": r["b"]})

    @app.get("/api/historico/exportar")
    def historico_exportar():
        """Serie completa en CSV, para analizarla afuera."""
        desde = request.args.get("desde") or "2023-01-01"
        sims = (request.args.get("simbolos") or "").upper()
        q = ("SELECT simbolo, fecha, precio, tir, md, duration, residual, cer "
             "FROM bono_hist WHERE fecha >= ?")
        args = [desde]
        if sims:
            lista = [x.strip() for x in sims.split(",") if x.strip()]
            q += " AND simbolo IN (%s)" % ",".join("?" * len(lista))
            args += lista
        q += " ORDER BY simbolo, fecha"

        filas = db.conn().execute(q, args).fetchall()
        salida = ["simbolo,fecha,precio,tir,md,duration,residual,cer"]
        for f in filas:
            salida.append(",".join(
                "" if f[c] is None else
                ("%.6f" % f[c] if isinstance(f[c], float) else str(f[c]))
                for c in ("simbolo", "fecha", "precio", "tir", "md",
                          "duration", "residual", "cer")))
        texto = "\n".join(salida)
        return app.response_class(
            texto, mimetype="text/csv",
            headers={"Content-Disposition":
                     "attachment; filename=historico_tir.csv"})

    @app.get("/api/historico/estado")
    def historico_estado():
        r = H.resumen()
        try:
            r["sin_serie"] = [{"simbolo": x[0], "desde": str(x[1]),
                               "hasta": str(x[2]) if x[2] else None}
                              for x in H.sin_serie()]
        except Exception:
            r["sin_serie"] = []
        r["progreso"] = dict(H.progreso)
        r["huecos"] = H.huecos()
        r["ajustes"] = H.ajustes()
        return jsonify(r)

    @app.post("/api/historico/reconstruir")
    def historico_reconstruir():
        """Arranca la reconstruccion en segundo plano y vuelve enseguida.

        Sin forzar completa lo que falta, incluido el hueco hacia atras
        de las especies agregadas despues del primer backfill. Forzado
        rehace todo, o una especie.
        """
        sim = (request.args.get("simbolo") or "").upper() or None
        forzar = request.args.get("forzar") in ("1", "true", "si")
        arranco = H.en_fondo(monitor.iol, sim, forzar=forzar)
        return jsonify({"arranco": arranco, "forzado": forzar,
                        "progreso": dict(H.progreso)})

    @app.get("/api/oportunidades")
    def oportunidades():
        return jsonify({"oportunidades": monitor.oportunidades(),
                        "en_rueda": monitor._en_horario()})

    @app.get("/api/senales")
    def senales_resumen():
        import senales as SE
        sim = (request.args.get("simuladas") or "1") != "0"
        return jsonify(SE.resumen(simuladas=sim))

    @app.post("/api/senales/medir")
    def senales_medir():
        """Mide ahora. Con `reconstruir`, rearma tambien las simuladas
        con los parametros actuales de la configuracion."""
        d = request.get_json(silent=True) or {}
        n = monitor.medir_senales(reconstruir=bool(d.get("reconstruir")))
        return jsonify({"medidas": n})

    @app.get("/api/curva/antes")
    def curva_antes():
        """Los bonos de una familia como estaban hace `dias` dias: TIR y
        duration de bono_hist en la ultima rueda guardada hasta esa fecha.
        El ajuste lo hace el front, con el mismo modelo que la curva de
        hoy, para dibujar las dos juntas."""
        import bonos as BO
        from datetime import date as _d
        fam = (request.args.get("familia") or "").strip()
        try:
            dias = max(1, min(400, int(request.args.get("dias") or 30)))
        except ValueError:
            dias = 30
        hasta = (_d.today() - timedelta(days=dias)).isoformat()
        c = db.conn()
        # La ultima rueda con la serie completa: un dia a medio cargar
        # (solo el punto de hoy de algunas especies) no arma una curva.
        r = c.execute("SELECT fecha f FROM bono_hist WHERE fecha<=? AND "
                      "tir IS NOT NULL GROUP BY fecha HAVING COUNT(*) >= 10 "
                      "ORDER BY fecha DESC LIMIT 1", (hasta,)).fetchone()
        fecha = r["f"] if r else None
        if not fecha:
            return jsonify({"fecha": None, "puntos": []})
        try:
            cfg, _ = BO.cargar()
            esp = BO.especies()
        except Exception as e:
            return jsonify({"error": str(e)}), 500
        puntos = []
        for row in c.execute("SELECT simbolo, tir, md FROM bono_hist WHERE "
                             "fecha=? AND tir IS NOT NULL AND md > 0", (fecha,)):
            info = esp.get(row["simbolo"])
            cr = cfg.get((info or {}).get("cronograma"))
            if not cr:
                continue
            try:
                f = BO._familia(cr, info, row["simbolo"])
            except Exception:
                continue
            if f == fam:
                puntos.append({"simbolo": row["simbolo"], "tir": row["tir"],
                               "md": row["md"]})
        return jsonify({"fecha": fecha, "puntos": puntos})

    @app.get("/api/calendario")
    def calendario_listar():
        import calendario as CAL
        from datetime import date as _d
        try:
            anio = int(request.args.get("anio") or _d.today().year)
        except ValueError:
            anio = _d.today().year
        return jsonify(CAL.listar(anio))

    @app.post("/api/calendario/actualizar")
    def calendario_actualizar():
        """Baja el calendario ahora, sin esperar al refresco mensual. Para
        un feriado decretado con pocos dias de anticipacion."""
        import calendario as CAL
        try:
            return jsonify(CAL.actualizar(forzar=True))
        except Exception as e:
            return jsonify({"hecho": False, "errores": [str(e)[:200]]}), 502

    @app.get("/api/historico/progreso")
    def historico_progreso():
        return jsonify({"progreso": dict(H.progreso), "huecos": H.huecos(),
                        "estado": H.resumen()})

    @app.get("/api/base/descargar")
    def base_descargar():
        """La base entera, copiada con la API de backup de SQLite."""
        import os as _os
        try:
            ruta = db.copia_temporal()
            with open(ruta, "rb") as fh:
                datos = fh.read()
            _os.remove(ruta)
        except Exception as e:
            return jsonify({"error": str(e)}), 500
        nombre = "ratios-%s.db" % datetime.now().date().isoformat()
        return app.response_class(
            datos, mimetype="application/vnd.sqlite3",
            headers={"Content-Disposition": "attachment; filename=" + nombre})

    # -- actualizar la app y restaurar la base (add-on local) ------------

    @app.get("/api/app/estado")
    def app_estado():
        import actualizar as AC
        d = AC.estado()
        d["version"] = _version()
        return jsonify(d)

    @app.post("/api/app/revisar")
    def app_revisar():
        """Vista previa del zip: version y cambios, sin tocar nada."""
        import actualizar as AC
        f = request.files.get("archivo")
        if not f:
            return jsonify({"error": "Falta el archivo."}), 400
        try:
            return jsonify(AC.revisar(f.read(), _version()))
        except ValueError as e:
            return jsonify({"error": str(e)}), 400

    @app.post("/api/app/actualizar")
    def app_actualizar():
        """Sube el zip, lo copia sobre el add-on local y pide al Supervisor
        que lo reconstruya. La app se reinicia sola."""
        import actualizar as AC
        f = request.files.get("archivo")
        if not f:
            return jsonify({"error": "Falta el archivo."}), 400
        try:
            return jsonify(AC.actualizar(f.read(), _version()))
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        except RuntimeError as e:
            return jsonify({"error": str(e)}), 409
        except Exception as e:
            log.exception("actualizar")
            return jsonify({"error": str(e)}), 500

    @app.post("/api/base/restaurar")
    def base_restaurar():
        """Sube una base (la bajada con "Descargar base") y reinicia la app
        para usarla. La actual queda guardada al lado."""
        import actualizar as AC
        f = request.files.get("archivo")
        if not f:
            return jsonify({"error": "Falta el archivo."}), 400
        try:
            r = AC.preparar_restauracion(f.read())
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        AC.reiniciar()
        return jsonify(dict(r, ok=True))

    @app.get("/api/bcra/variables")
    def bcra_variables():
        """El listado de variables monetarias del BCRA, para buscar IDs."""
        import cer as _cer
        import red
        urls = ["https://api.bcra.gob.ar/estadisticas/v4.0/Monetarias",
                "https://api.bcra.gob.ar/estadisticas/v3.0/monetarias"]
        ultimo = None
        for verify in (True, False):
            for url in urls:
                try:
                    r = red.get(url, "bcra_variables", headers=_cer.CABECERAS,
                                timeout=30, verify=verify)
                    if r.status_code != 200:
                        ultimo = "%s -> HTTP %s" % (url, r.status_code)
                        continue
                    d = r.json() or {}
                    lista = d.get("results") or d.get("resultados") or []
                    out = [{"id": x.get("idVariable"),
                            "descripcion": (x.get("descripcion") or "").strip(),
                            "unidad": x.get("unidadExpresion"),
                            "fecha": x.get("ultFechaInformada") or x.get("fecha"),
                            "valor": x.get("ultValorInformado") if "ultValorInformado" in x
                            else x.get("valor")}
                           for x in lista if isinstance(x, dict)]
                    return jsonify({"variables": out, "fuente": url})
                except Exception as e:
                    ultimo = "%s -> %s" % (url, str(e)[:160])
        return jsonify({"error": ultimo or "sin respuesta"}), 502

    @app.post("/api/tamar/probar")
    def tamar_probar():
        """Fuerza una consulta de la TAMAR y muestra los duales."""
        from datetime import date as _d, timedelta as _t
        import tamar as TA
        import dual as DU
        TA.reintentar_ya()
        hoy = _d.today()
        n = TA.descargar((hoy - _t(days=30)).isoformat(), hoy.isoformat())
        est = TA.resumen()
        bonos_cfg, _ = BO.cargar()
        det = []
        for tk, cfg in bonos_cfg.items():
            if not DU.es_dual(cfg):
                continue
            try:
                r = DU.calcular(cfg, hoy)
            except Exception as e:
                r = None
                det.append("%s: %s" % (tk, e))
                continue
            if r is None:
                det.append("%s: sin TAMAR" % tk)
            else:
                det.append("%s: TAMAR prom %.2f%% (%d publ. + %d proy.) "
                           "-> VPV %.2f, gana %s" % (
                               tk, r["tamar_promedio"], r["tamar_publicados"],
                               r["tamar_proyectados"], r["vpv"], r["gana"]))
        return jsonify({"dias_traidos": n, "vigente": TA.vigente(),
                        "serie": 44, "error": TA.ultimo_error,
                        "respuesta": TA.ultima_respuesta,
                        "rango": "%s a %s (%s días)" % (
                            est["desde"], est["hasta"], est["dias"])
                        if est["dias"] else None,
                        "bonos": det})

    @app.get("/api/explorar/fotos")
    def explorar_fotos():
        return jsonify({"fotos": db.fotos(),
                        "sin_tenencia": db.brokers_sin_tenencia()})

    @app.post("/api/explorar/borrar-broker")
    def explorar_borrar_broker():
        broker = (request.get_json(silent=True) or {}).get("broker")
        if not broker:
            return jsonify({"ok": False, "mensaje": "Falta el broker."}), 400
        try:
            borradas = db.borrar_broker(broker)
        except ValueError as e:
            return jsonify({"ok": False, "mensaje": str(e)}), 409
        return jsonify({"ok": True, "borradas": borradas})

    @app.get("/api/explorar/foto")
    def explorar_foto():
        b = request.args.get("broker") or ""
        ts = request.args.get("ts") or ""
        return jsonify(db.foto_detalle(b, ts))

    @app.post("/api/historico/mep")
    def historico_mep():
        """Reconstruye la serie del MEP hacia atras.

        Solo el precio de las dos puntas del par: para el MEP no hace
        falta la TIR, que es lo que obliga a `reconstruir` a saltear los
        hard dollar que cotizan en pesos. Sin esto no se puede medir en
        dolares ninguna compra anterior al inicio de la serie.
        """
        d = request.get_json(silent=True) or {}
        desde = (d.get("desde") or "").strip() or None
        hasta = (d.get("hasta") or "").strip() or None
        par = [monitor.cfg.get("mep_par_pesos") or "AL30",
               monitor.cfg.get("mep_par_usd") or "AL30D"]
        try:
            with monitor.iol.como("boton"):
                r = H.reconstruir_precios(monitor.iol, par, desde, hasta)
        except Exception as e:
            log.warning("serie del mep: %s", e)
            return jsonify({"error": str(e)}), 500
        # Desde cuando se puede medir en dolares despues de esto.
        r["mep_desde"] = None
        try:
            comunes = sorted(
                {x["fecha"] for x in H.serie(par[0])}
                & {x["fecha"] for x in H.serie(par[1])})
            r["mep_desde"] = comunes[0] if comunes else None
            r["dias"] = len(comunes)
        except Exception as e:
            log.debug("cobertura del mep: %s", e)
        return jsonify(r)

    @app.get("/api/posicion/exportar")
    def exportar_posicion():
        try:
            return jsonify(respaldo.exportar_posicion())
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.post("/api/posicion/importar")
    def importar_posicion():
        d = request.get_json(silent=True) or {}
        try:
            r = respaldo.importar_posicion(
                d.get("datos"), bool(d.get("reemplazar")))
        except Exception as e:
            return jsonify({"error": str(e)}), 400
        return jsonify(r)

    @app.get("/api/notificaciones/diagnostico")
    def notif_diag():
        return jsonify(monitor.notif.diagnostico())

    @app.post("/api/notificaciones/probar")
    def notif_probar():
        return jsonify(monitor.notif.probar())

    @app.get("/api/alertas")
    def alertas():
        filas = db.alertas_recientes(40)
        return jsonify([_fila(f, "id", "ts", "alias", "tipo", "ratio",
                              "nivel", "mensaje", "p_num", "p_den",
                              "qc_num", "qv_num", "qc_den", "qv_den")
                        for f in filas])

    # -- consumo ------------------------------------------------------

    @app.get("/api/requests")
    def requests_stats():
        return jsonify(db.resumen_requests(30))

    @app.post("/api/requests/log/borrar")
    def requests_log_borrar():
        return jsonify({"borradas": db.borrar_api_log()})

    @app.get("/api/requests/log")
    def requests_log():
        return jsonify({
            "resumen": db.api_log_resumen(int(request.args.get("dias", 7))),
            "ultimas": db.api_log(int(request.args.get("limite", 200)),
                                  ruta=request.args.get("ruta") or None),
            "retencion_dias": db.RETENCION_API_LOG,
        })

    # -- exploracion --------------------------------------------------

    # La lista de instrumentos y la de paneles son catalogo: cambian
    # cuando BYMA agrega o saca un panel, no todos los dias. Pedirlas en
    # cada visita a Explorar gastaba dos requests por vez.
    HORAS_CATALOGO = 24 * 7

    # Los que acepta orleans. No coinciden con los nombres de los
    # instrumentos del endpoint viejo.
    INSTRUMENTOS_ORLEANS = ["titulosPublicos", "letras", "acciones",
                            "cedears", "opciones", "obligacionesNegociables",
                            "cauciones", "aDRs", "cHPD", "futuros"]

    @app.get("/api/explorar/instrumentos")
    def ex_instrumentos():
        """Los de orleans, que es la fuente que usa el ciclo.

        La lista es fija: no hay endpoint que la devuelva, sale del
        contrato de la API.
        """
        return jsonify(list(INSTRUMENTOS_ORLEANS))

    @app.get("/api/explorar/paneles")
    def ex_paneles():
        """Orleans no tiene paneles: tiene un filtro."""
        return jsonify(["Operables", "Todos"])

    @app.post("/api/explorar/recargar-catalogo")
    def ex_recargar():
        return jsonify({"borradas": db.cache_borrar("")})

    @app.get("/api/explorar/panel")
    def ex_panel():
        pais = request.args.get("pais", "argentina")
        instrumento = request.args.get("instrumento", "Bonos")
        panel = request.args.get("panel", "")
        # "panel" ahora es el filtro de orleans: Operables o Todos. Los
        # paneles viejos quedaron sin uso, asi que el explorador mira la
        # misma fuente que el ciclo.
        filtro = panel or "Operables"
        try:
            with monitor.iol.como("pestania"):
                d = monitor.iol.panel_orleans(instrumento, pais, filtro)
        except IOLError as e:
            return jsonify({"error": str(e)}), 502

        titulos = (d or {}).get("titulos") or []
        filas = []
        con_puntas = 0
        for t in titulos:
            p = t.get("puntas") or {}
            if isinstance(p, list):
                p = p[0] if p else {}
            compra = p.get("precioCompra") or 0
            venta = p.get("precioVenta") or 0
            if compra or venta:
                con_puntas += 1
            filas.append({
                "simbolo": t.get("simbolo"),
                "ultimo": t.get("ultimoPrecio") or 0,
                "compra": compra, "venta": venta,
                "cant_compra": p.get("cantidadCompra") or 0,
                "cant_venta": p.get("cantidadVenta") or 0,
                "moneda": t.get("moneda") or "",
                "plazo": t.get("plazo") or "",
                "fecha": t.get("fecha") or "",
                "lote": t.get("lote"),
                "descripcion": t.get("descripcion") or "",
            })
        filas.sort(key=lambda f: f["simbolo"] or "")
        simbolos = [f["simbolo"] or "" for f in filas]
        return jsonify({
            "panel": filtro, "instrumento": instrumento,
            "total": len(filas), "con_puntas": con_puntas,
            "especies_d": [s for s in simbolos if s.endswith("D")],
            "especies_c": [s for s in simbolos if s.endswith("C")],
            "monedas": sorted({f["moneda"] for f in filas if f["moneda"]}),
            "plazos": sorted({f["plazo"] for f in filas if f["plazo"]}),
            "titulos": filas,
            "muestra_cruda": titulos[0] if titulos else None,
        })

    @app.get("/api/explorar/raw")
    def ex_raw():
        path = (request.args.get("path") or "").strip()
        if not path:
            return jsonify({"error": "Escribí una ruta."}), 400
        prohibido = ("operar", "comprar", "vender", "cancelar", "token")
        if any(p in path.lower() for p in prohibido):
            return jsonify({"error": "Esta pestaña es solo de lectura."}), 403
        try:
            return jsonify({"path": path, "respuesta": monitor.iol.get(path)})
        except IOLError as e:
            return jsonify({"error": str(e)}), 502

    return app


# -- auxiliares -------------------------------------------------------

def _version():
    """Lee la versión del config.yaml del add-on: una sola fuente de verdad."""
    import os
    candidatas = [
        "/config.yaml",                                    # copiado por el Dockerfile
        os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.yaml"),
    ]
    for ruta in candidatas:
        try:
            with open(ruta, encoding="utf-8") as f:
                for linea in f:
                    if linea.startswith("version:"):
                        return linea.split(":", 1)[1].strip().strip('"\'')
        except Exception:
            continue
    return ""


def _recordar_par(num, den, mercado, plazo):
    import json
    try:
        prev = json.loads(db.get_estado("pares_usados") or "[]")
    except ValueError:
        prev = []
    entrada = {"num": num, "den": den, "mercado": mercado, "plazo": plazo}
    prev = [p for p in prev
            if not (p.get("num") == num and p.get("den") == den)]
    prev.insert(0, entrada)
    db.set_estado("pares_usados", json.dumps(prev[:20]))


def _pares_recientes():
    import json
    try:
        return json.loads(db.get_estado("pares_usados") or "[]")
    except ValueError:
        return []


def _tickers_conocidos():
    filas = db.conn().execute(
        "SELECT DISTINCT simbolo FROM cierres ORDER BY simbolo").fetchall()
    return [f["simbolo"] for f in filas]


def _traer_historico(monitor, mercado, simbolo, dias):
    hasta = datetime.now().date()
    desde = hasta - timedelta(days=max(dias, 400))
    try:
        with monitor.iol.como("pestania"):
            datos = monitor.iol.serie(mercado, simbolo, desde.isoformat(),
                                      hasta.isoformat())
    except IOLError as e:
        log.warning("historico %s: %s", simbolo, e)
        return
    filas = []
    for p in datos or []:
        f = str(p.get("fechaHora") or "")[:10]
        c = p.get("ultimoPrecio") or p.get("cierreAnterior")
        try:
            c = float(c)
        except (TypeError, ValueError):
            continue
        if f and c > 0:
            filas.append((f, c))
    if filas:
        db.guardar_cierres(simbolo, filas)


def _fila(f, *campos):
    """Lee solo las columnas que existan: tolera bases de versiones viejas."""
    try:
        presentes = set(f.keys())
    except Exception:
        presentes = set()
    return {c: (f[c] if c in presentes else None) for c in campos}


def _p(p):
    return {k: p.get(k) for k in
            ("ultimo", "compra", "venta", "ref", "variacion",
             "vol_compra", "vol_venta")}


def _limpiar(f):
    if not f:
        return {}
    out = {k: f.get(k) for k in
           ("id", "alias", "num", "den", "ratio", "zona", "resistencia", "soporte",
            "z", "ts", "alertas", "error", "alerta_id", "origen", "cerca")}
    est = f.get("est") or {}
    out["est"] = {k: est.get(k) for k in
                  ("n", "media", "desvio", "min", "max", "fuente", "aviso")}
    for lado in ("p_num", "p_den"):
        if f.get(lado):
            out[lado] = _p(f[lado])
    return out
